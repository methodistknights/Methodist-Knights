import { useState } from "react";
import Layout from "@/components/Layout";
import Seo from "@/components/Seo";
import SectionHeader from "@/components/SectionHeader";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X } from "lucide-react";
import hero1 from "@/assets/hero-1.jpg";
import hero2 from "@/assets/hero-2.jpg";
import hero3 from "@/assets/hero-3.jpg";
import hero4 from "@/assets/hero-4.jpg";
import hero5 from "@/assets/hero-5.jpg";
import aboutImg from "@/assets/about.jpg";
import ladiesImg from "@/assets/ladies.jpg";
import nexcoImg from "@/assets/nexco.jpg";

const images = [
  { src: hero1, alt: "Knights Assembly" },
  { src: hero2, alt: "Knights Ceremony" },
  { src: hero3, alt: "Knights in Church" },
  { src: hero4, alt: "Knights Standing" },
  { src: hero5, alt: "Ladies of Knights" },
  { src: aboutImg, alt: "Council Meeting" },
  { src: ladiesImg, alt: "Ladies Assembly" },
  { src: nexcoImg, alt: "NEXCO Meeting" },
];

const Gallery = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const active = activeIndex !== null ? images[activeIndex] : null;

  return (
    <Layout>
      <Seo
        title="Gallery — Council of Knights MCN"
        description="Photo gallery from meetings, conferences, and activities of the Council of Knights, Methodist Church Nigeria."
        path="/gallery"
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Council of Knights Gallery",
        }}
      />
      <section className="relative h-64 md:h-72 gradient-wine-purple flex items-center justify-center">
        <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground">Gallery</h1>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <SectionHeader title="Photo Gallery" subtitle="Tap an image to view it full size" />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {images.map((img, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setActiveIndex(i)}
                className="group relative overflow-hidden rounded-xl aspect-square cursor-zoom-in focus:outline-none focus:ring-2 focus:ring-gold"
                aria-label={`View ${img.alt} full size`}
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-wine-dark/0 group-hover:bg-wine-dark/40 transition-colors flex items-end p-4">
                  <p className="text-primary-foreground font-medium text-sm opacity-0 group-hover:opacity-100 transition-opacity">
                    {img.alt}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      <Dialog open={active !== null} onOpenChange={(open) => !open && setActiveIndex(null)}>
        <DialogContent className="max-w-[95vw] w-fit p-0 bg-transparent border-0 shadow-none [&>button]:hidden">
          {active && (
            <div className="relative">
              <button
                type="button"
                onClick={() => setActiveIndex(null)}
                aria-label="Close"
                className="absolute -top-3 -right-3 z-10 w-10 h-10 rounded-full bg-background text-foreground shadow-lg flex items-center justify-center hover:bg-gold transition-colors"
              >
                <X size={20} />
              </button>
              <img
                src={active.src}
                alt={active.alt}
                className="max-h-[90vh] max-w-[95vw] w-auto h-auto object-contain rounded-lg"
              />
              <p className="mt-3 text-center text-primary-foreground bg-wine-dark/70 rounded-md py-2 px-3 text-sm font-medium">
                {active.alt}
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default Gallery;
