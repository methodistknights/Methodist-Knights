import Layout from "@/components/Layout";
import Seo from "@/components/Seo";
import SectionHeader from "@/components/SectionHeader";
import ladiesImg from "@/assets/ladies-hero.png";

const Ladies = () => {
  return (
    <Layout>
      <Seo
        title="Ladies of Knights — Council of Knights MCN"
        description="The Ladies of Knights Assembly: the spouses of the Knights, led by the National Chairperson and Anchor Ladies at chapter level."
        path="/ladies"
      />
      <section className="relative h-64 md:h-80 overflow-hidden">
        <img src={ladiesImg} alt="Ladies of Knights" className="w-full h-full object-cover" />
        <div className="absolute inset-0 gradient-wine-purple opacity-80" />
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground">Ladies of Knights</h1>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <SectionHeader title="Ladies of Knights Assembly" subtitle="Assembly of the Wives of the Knights" />
          <div className="flex justify-center mb-8">
            <img src={ladiesImg} alt="Ladies of Knights" className="rounded-2xl shadow-xl w-full max-w-2xl object-cover aspect-[4/3]" />
          </div>
          <div className="bg-cream rounded-2xl p-8 border border-border mb-12">
            <p className="text-muted-foreground leading-relaxed text-lg">
              This is an Assembly of the wives (spouses) of the Knights. The Assembly is governed by The National Chairperson and her team at the national level while the Archdioceses (or Chapters) are run by the ANCHOR LADIES.
            </p>
          </div>

          <SectionHeader title="Ladies of Knights National Executives" subtitle="Coming soon — executive team details will be added" />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-background rounded-xl border border-border p-6 text-center opacity-60">
                <div className="w-20 h-20 rounded-full bg-muted mx-auto mb-4" />
                <p className="text-muted-foreground text-sm">Details to be added</p>
              </div>
            ))}
          </div>

          <SectionHeader title="Chapter Chairmen Ladies of Knights" subtitle="Anchor Ladies across chapters — details coming soon" />
        </div>
      </section>
    </Layout>
  );
};

export default Ladies;
