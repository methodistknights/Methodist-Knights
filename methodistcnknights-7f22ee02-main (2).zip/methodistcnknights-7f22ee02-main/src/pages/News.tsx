import Layout from "@/components/Layout";
import Seo from "@/components/Seo";
import SectionHeader from "@/components/SectionHeader";

const News = () => {
  return (
    <Layout>
      <Seo
        title="News — Council of Knights MCN"
        description="Latest announcements, events, and updates from the Council of Knights of John Wesley and Charles Wesley, Methodist Church Nigeria."
        path="/news"
      />
      <section className="relative h-64 md:h-72 gradient-wine-purple flex items-center justify-center">
        <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground">News</h1>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <SectionHeader title="Latest News" subtitle="Stay updated with the Council of Knights" />
          <div className="text-center py-16 text-muted-foreground">
            <p className="text-lg">News articles will be published here soon.</p>
            <p className="text-sm mt-2">Check back for updates from the Council of Knights.</p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default News;
