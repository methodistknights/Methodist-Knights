import { leadershipPortraits as portraits } from "@/data/leadershipPortraits";
import Layout from "@/components/Layout";
import Seo from "@/components/Seo";
import SectionHeader from "@/components/SectionHeader";
import nexcoImg from "@/assets/nexco-hero.png";
import { Phone, MessageCircle } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

// Member photos
import victorEtefiaImg from "@/assets/members/victor-etefia.jpg";
import deleWickliffeImg from "@/assets/members/dele-wickliffe.jpg";
import fridayEluwaImg from "@/assets/members/friday-eluwa.jpg";
import adebolaOgunsanwoImg from "@/assets/members/adebola-ogunsanwo.jpg";
import ifeanyiOkechukwuImg from "@/assets/members/ifeanyi-okechukwu.jpg";
import emekaOhaeriImg from "@/assets/members/emeka-ohaeri.jpg";
import justiceEssangImg from "@/assets/members/justice-essang.jpg";

// Chapter Chairman photos
import fridayNwankwoImg from "@/assets/members/friday-nwankwo.jpg";
import adegbengaAdebusuyiImg from "@/assets/members/adegbenga-adebusuyi.jpg";
import kayodeDosunmuImg from "@/assets/members/kayode-dosunmu.jpg";
import udoyiuUdoyiuImg from "@/assets/members/udoyiu-udoyiu.jpg";
import bankoleOsoImg from "@/assets/members/bankole-oso.jpg";
import luckyAkabuikeImg from "@/assets/members/lucky-akabuike.jpg";
import ayorindesThomasImg from "@/assets/members/ayorinde-thomas.jpg";
import lazarusAniImg from "@/assets/members/lazarus-ani.jpg";
import isaiahUwakweImg from "@/assets/members/isaiah-uwakwe.jpg";
import olaniyiOlatidoImg from "@/assets/members/olaniyi-olatido.jpg";
import rasheedOyesolaImg from "@/assets/members/rasheed-oyesola.jpg";
import adetopeTychusImg from "@/assets/members/lagos/adetope-tychus.png";
import ekpenyongEkpenyongImg from "@/assets/members/calabar/ekpenyong-ekpenyong.jpg";
import elishaYesufuImg from "@/assets/members/benue/elisha-yesufu.jpg";
import logoImg from "@/assets/logo.png";

const nexcoMembers = [
  { sn: 1, name: "Sir Victor Etefia-KJW", position: "National President", phone: "08035524003", image: portraits["victor-etefia"] },
  { sn: 2, name: "Sir Dele Wickliffe", position: "Vice President", phone: "08033166610", image: portraits["dele-wickliffe"] },
  { sn: 3, name: "Sir Friday Eluwa KJW, Ph.D", position: "Nat. Secretary", phone: "08033053712", image: portraits["friday-eluwa"] },
  { sn: 4, name: "Sir Emmanuel S. Audu KJW", position: "Nat. Asst. Sec", phone: "08053914467", image: portraits["emmanuel-audu"] },
  { sn: 5, name: "Sir Barr. Friday Ekpety KJW", position: "Nat. Treasurer", phone: "08023131366", image: portraits["friday-ekpety"] },
  { sn: 6, name: "Sir Prof. Akobundu Ugah-KJW", position: "Nat. Fin. Sec", phone: "08068181279", image: portraits["akobundu-ugah"] },
  { sn: 7, name: "Sir Dr. Emeka Ohaeri KJW", position: "Nat. PRO", phone: "08034957064", image: portraits["emeka-ohaeri"] },
  { sn: 8, name: "Sir Inwon L. Fingesi KJW", position: "Nat. Auditor", phone: "08033958041", image: portraits["inwon-fingesi"] },
  { sn: 9, name: "Sir Ide Ifeanyi Okechukwu-KJW", position: "Ex-Officio", phone: "08035501797", image: portraits["ifeanyi-okechukwu"] },
  { sn: 10, name: "Sir. Justice Umoekoyo Essang", position: "Ex-Officio", phone: "08130080935", image: portraits["umoekoyo-essang"] },
  { sn: 11, name: "Sir Bola Ogunsanwo KJW", position: "Ex-Officio", phone: "08032417142", image: portraits["bola-ogunsanwo"] },
];

const chapterChairmen = [
  { chapter: "Aba", name: "Sir Friday Nwankwo-KJW", phone: "08037822821", image: portraits["aba-friday-nwankwo"] },
  { chapter: "Abuja", name: "Sir Samuel Osahon-KJW", phone: "08035904137", image: portraits["abuja-samuel-osahon"] },
  { chapter: "Anambra", name: "Sir Akaeme Ifeanyi Christian-KJW", phone: "08033270890", image: portraits["anambra-ifeanyi-akaeme"] },
  { chapter: "Benue", name: "Sir Elisha Yesufu-KJW", phone: "08022959833", image: portraits["benue-elisha-yesufu"] },
  { chapter: "Calabar", name: "Sir Engr. Ekpenyong Ekpenyong-KJW", phone: "08037080960", image: portraits["calabar-ekpenyong-ekpenyong"] },
  { chapter: "Ebonyi", name: "Sir Barr. Monday Odoh-KJW", phone: "08037727047", image: portraits["ebonyi-monday-odoh"] },
  { chapter: "Enugu", name: "Sir Lazarus Ani-KCW", phone: "08052238127", image: portraits["enugu-lazarus-ani"] },
  { chapter: "Ibadan", name: "Sir John Kayode Dosunmu-KJW", phone: "08062918638", image: portraits["ibadan-kayode-dosunmu"] },
  { chapter: "Ifaki", name: "Sir Bankole Foluso Oso KJW", phone: "08035060755", image: portraits["ifaki-bankole-oso"] },
  { chapter: "Igbobini", name: "Sir Oyewumi Akinmoju-KJW", phone: "08066504331", image: portraits["igbobini-oyewumi-akinmoju"] },
  { chapter: "Ikot-Ekpene", name: "Sir Prof. Idoreyin Umoh-KJW", phone: "08036743886", image: portraits["ikot-ekpene-idoreyin-umoh"] },
  { chapter: "Ilesa", name: "Sir Adegbenga Adebusuyi-KJW", phone: "08034012560", image: portraits["ilesa-adegbenga-adebusuyi"] },
  { chapter: "Kaduna", name: "Sir Rasheed Oyeshola KJW", phone: "08173082851", image: portraits["kaduna-rasheed-oyeshola"] },
  { chapter: "Lagos", name: "Dame Adetope Tychus-KJW", phone: "08033084362", image: portraits["lagos-adetope-tychus"] },
  { chapter: "Lagos Mainland", name: "Sir Ayorinde Thomas-KJW", phone: "08033193623", image: portraits["lagos-mainland-ayorinde-thomas"] },
  { chapter: "Okigwe", name: "Sir Monday Udeogu-KJW", phone: "08038865956", image: portraits["okigwe-monday-udeogu"] },
  { chapter: "Oron", name: "Sir Esang Nsa Bassey-KJW", phone: "07061827795", image: portraits["oron-esang-nsa-bassey"] },
  { chapter: "Portharcout", name: "Sir Prof. Steve Ogamba-KJW", phone: "08022908427", image: portraits["portharcourt-steve-ogamba"] },
  { chapter: "RIYE", name: "Sir Niyi Olatidoye-KJW", phone: "08033351744", image: portraits["riye-niyi-olatidoye"] },
  { chapter: "Umuahia", name: "Sir Comr. Lucky Akabuike-KJW", phone: "07060930888", image: portraits["umuahia-lucky-akabuike"] },
  { chapter: "Uyo", name: "Sir Dr. Udoyiu Udoyiu", phone: "08033733963", image: portraits["uyo-udoyiu-udoyiu"] },
];

const getInitials = (name: string) => {
  const cleaned = name.replace(/^(Sir|Dame)\.?\s*/i, "").replace(/\s*(KJW|KCW|Ph\.?D|Prof\.|Dr\.|Barr\.|Engr\.|Comr\.|Justice)\.?\s*/gi, "");
  const parts = cleaned.trim().split(/\s+/);
  return parts.length >= 2 ? `${parts[0][0]}${parts[parts.length - 1][0]}` : parts[0]?.[0] || "?";
};

interface TeamCardProps {
  name: string;
  title: string;
  phone: string;
  image?: string;
}

const TeamCard = ({ name, title, phone, image }: TeamCardProps) => (
  <div className="rounded-2xl overflow-hidden bg-background border border-border shadow-sm hover:shadow-xl transition-all duration-300 group">
    <div className="aspect-[3/4] w-full overflow-hidden bg-muted">
      {image ? (
        <img src={image} alt={name} className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300" />
      ) : (
        <div className="w-full h-full bg-muted flex items-center justify-center p-6">
          <img src={logoImg} alt="Council of Knights logo" className="w-full h-full object-contain opacity-90" />
        </div>
      )}
    </div>
    <div className="p-4">
      <h3 className="text-foreground text-sm leading-tight uppercase" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 900 }}>
        {name}
      </h3>
      <p className="text-wine text-xs mt-1 uppercase" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
        {title}
      </p>
      <div className="mt-2 flex items-center gap-3">
        <a
          href={`tel:${phone}`}
          className="inline-flex items-center gap-1 text-muted-foreground text-xs hover:text-wine transition-colors"
        >
          <Phone size={13} />
          {phone}
        </a>
        {phone && (
          <a
            href={`https://wa.me/${phone.replace(/\D/g, "").replace(/^0/, "234")}`}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Chat on WhatsApp with ${name}`}
            className="inline-flex items-center gap-1 text-green-600 text-xs hover:text-green-800 transition-colors"
          >
            <MessageCircle size={13} />
            WhatsApp
          </a>
        )}
      </div>
    </div>
  </div>
);

const NexcoExco = () => {
  return (
    <Layout>
      <Seo
        title="NEXCO & EXCO — Council of Knights MCN"
        description="National Executive Committee and Executive Council leadership of the Council of Knights, Methodist Church Nigeria."
        path="/nexco-exco"
      />
      {/* Hero */}
      <section className="relative h-64 md:h-80 overflow-hidden">
        <img src={nexcoImg} alt="NEXCO & EXCO" className="w-full h-full object-cover" />
        <div className="absolute inset-0 gradient-wine-purple opacity-80" />
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground">NEXCO & EXCO</h1>
        </div>
      </section>

      {/* National Executive Carousel */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <SectionHeader title="National Executive Council" subtitle="Leadership of the Council of Knights" />
          <div className="px-8 md:px-12">
            <Carousel opts={{ align: "start", loop: true }} className="w-full">
              <CarouselContent className="-ml-4">
                {nexcoMembers.map((member) => (
                  <CarouselItem key={member.sn} className="pl-4 basis-full sm:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                    <TeamCard name={member.name} title={member.position} phone={member.phone} image={member.image} />
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="-left-4 md:-left-6" />
              <CarouselNext className="-right-4 md:-right-6" />
            </Carousel>
          </div>
        </div>
      </section>

      {/* Chapter Chairmen Carousel */}
      <section className="py-20 bg-cream">
        <div className="container mx-auto px-4">
          <SectionHeader title="Chapter Chairmen" subtitle="Leaders of the 21 Chapters across Nigeria" />
          <div className="px-8 md:px-12">
            <Carousel opts={{ align: "start", loop: true }} className="w-full">
              <CarouselContent className="-ml-4">
                {chapterChairmen.map((chair) => (
                  <CarouselItem key={chair.chapter} className="pl-4 basis-full sm:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                    <TeamCard name={chair.name} title={`${chair.chapter.toUpperCase()} CHAPTER CHAIRMAN`} phone={chair.phone} image={chair.image} />
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="-left-4 md:-left-6" />
              <CarouselNext className="-right-4 md:-right-6" />
            </Carousel>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default NexcoExco;
