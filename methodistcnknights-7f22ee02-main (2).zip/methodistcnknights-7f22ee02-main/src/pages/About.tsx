import Layout from "@/components/Layout";
import Seo from "@/components/Seo";

const objectives = [
  "To provide a forum for all Knights to interact, fellowship and discuss matters of common interest affecting Methodist Church Nigeria.",
  "To encourage members to practice the tenets for which Methodist Church Nigeria was founded.",
  "To support the Church, morally, spiritually and financially.",
  "To encourage members to imbibe true Christian spirit.",
  "Through the Conference, to present the Council's resolutions on issues that will assist the smooth running of the Church.",
  "To promote the spirit of Christian leadership in members' day to day activities.",
  "To intercede in disputes amongst members at all levels of the Church.",
  "To promote harmonious relationship by intervening in matters of interest between the Clergy and the Laity for the provision of Christian spiritual growth.",
];

const About = () => {
  return (
    <Layout>
      <Seo
        title="About — Council of Knights MCN"
        description="History, membership, officers, and objectives of the Council of Knights of John Wesley and Charles Wesley, Methodist Church Nigeria."
        path="/about"
      />
      {/* Hero Banner */}
      <section className="relative h-64 md:h-80 overflow-hidden">
        <img src="/images/about/about-hero.jpg" alt="About Us" className="w-full h-full object-cover" />
        <div className="absolute inset-0 gradient-wine-purple opacity-80" />
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground">About Us</h1>
        </div>
      </section>

      {/* About Content */}
      <section className="py-16 md:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">

            {/* About / Council of Knights - image centered at top, text below */}
            <div className="mb-16">
              <div className="flex justify-center mb-8">
                <img src="/images/about/about-hero.jpg" alt="Council of Knights" className="rounded-2xl shadow-lg w-full max-w-2xl object-cover" />
              </div>
              <p className="text-muted-foreground leading-relaxed mb-4">
                The Council of Knights of John Wesley and Charles Wesley is the highest Award which Methodist Church Nigeria confers on any member of the Laity for their contributions in the Church. Methodist Church Nigeria (whose governing body is the Conference), confers the title of Knighthood on deserving members of the Church from time to time. Such members are referred to as Knights of John Wesley (KJW) or Knights of Charles Wesley (KCW).
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                The Knights of John Wesley (KJW) and Charles Wesley (KCW) of Methodist Church Nigeria resolved to form themselves into an organization to promote understanding and unity among themselves and project the image and welfare of the Church. While a male Knight is referred to as 'Sir', the female Knight is referred to as a 'Dame'.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                The collection or assembly of Knights is known as the <strong className="text-foreground">COUNCIL OF KNIGHTS OF JOHN WESLEY AND CHARLES WESLEY, METHODIST CHURCH NIGERIA</strong>. Knights of John Wesley is conferred on those who have distinguished themselves teaching and other forms of charity, the Knights of Charles Wesley is conferred on those who specialized in song writing, singing or music.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                The Council has its official address as the Methodist Church Nigeria Headquarters, 21/22 Marina, Lagos, Nigeria.
              </p>
            </div>

            {/* Membership - image on left, text below */}
            <div className="mb-16">
              <h2 className="text-2xl font-bold text-gradient-wine mb-4 text-center">Membership</h2>
              <div className="flex justify-center mb-8">
                <img src="/images/about/membership.jpg" alt="Knights Membership" className="rounded-2xl shadow-lg w-full max-w-2xl object-cover" />
              </div>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Membership of the organization comprises all Knights of Methodist Church Nigeria, who have their names recorded in a membership register.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Membership is also arranged in Archdiocesan levels referred to as Chapters. Each Chapter represents an Archdiocese created by the Methodist Conference.
              </p>
            </div>

            {/* Officers of the Council - image on left, list on right */}
            <div className="mb-16">
              <h2 className="text-2xl font-bold text-gradient-wine mb-4 text-center">Officers of the Council</h2>
              <div className="flex justify-center mb-8">
                <img src="/images/about/officers.jpg" alt="Officers of the Council" className="rounded-2xl shadow-lg w-full max-w-2xl object-cover" />
              </div>
              <div className="text-muted-foreground leading-relaxed mb-4">
                <p className="mb-3">The officers of the Council are in two categories namely; the National Executive Committee and the Chapter Executives. The National Executive Committee comprises of the following:</p>
                <div className="bg-cream rounded-xl p-4 border border-border mb-4">
                  <div className="grid sm:grid-cols-2 gap-2">
                    {["National President", "National Vice President", "National Secretary", "National Assistant Secretary", "National Treasurer", "National Financial Secretary", "National Social/ Publicity Secretary", "National Auditor", "Any other office as may be determined"].map((role) => (
                      <div key={role} className="flex items-center gap-2 text-sm text-foreground">
                        <span className="w-2 h-2 rounded-full bg-gold shrink-0" />
                        {role}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-muted-foreground leading-relaxed mb-3">
                The Executives or Officers of the various Chapters are called CHAPTER EXECUTIVES. The immediate Past-President is an Ex-officio member of the Council. Where a Conference Lay President is a Knight, he/she shall be one of the Ex-officio members.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                The National Executive Officers and the Chapter Chairmen meet at a joint meeting referred to as the NATIONAL EXECUTIVE COMMITTEE (NEXCO) Meeting.
              </p>
            </div>

            {/* Ladies of Knights Assembly - image on left, text beside */}
            <div className="mb-16">
              <h2 className="text-2xl font-bold text-gradient-wine mb-4 text-center">Ladies of Knights Assembly</h2>
              <div className="flex justify-center mb-8">
                <img src="/images/about/ladies.jpg" alt="Ladies of Knights Assembly" className="rounded-2xl shadow-lg w-full max-w-2xl object-cover" />
              </div>
              <p className="text-muted-foreground leading-relaxed mb-4">
                This is an Assembly of the wives (spouses) of the Knights.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                The Assembly is governed by The National Chairperson and her team at the national level while the Archdioceses (or Chapters) are run by the ANCHOR LADIES.
              </p>
            </div>

            {/* Fellowships / Meetings - image at top, text below */}
            <div className="mb-16">
              <h2 className="text-2xl font-bold text-gradient-wine mb-4 text-center">Fellowships / Meetings</h2>
              <div className="flex justify-center mb-8">
                <img src="/images/about/fellowships.jpg" alt="Fellowships and Meetings" className="rounded-2xl shadow-lg w-full max-w-2xl object-cover" />
              </div>
              <p className="text-muted-foreground leading-relaxed">
                The Council meets three times in any given year (February and June for Quarterly Meetings and October for the Conference/ Annual General Meeting). While the Meetings of February and June are for the National and Chapter Executives, the October Meetings are used for the Conferences and Annual General Meeting.
              </p>
            </div>

            {/* Objectives - image at top, numbered list below */}
            <div>
              <h2 className="text-2xl font-bold text-gradient-wine mb-6 text-center">Objectives of the Council</h2>
              <div className="flex justify-center mb-8">
                <img src="/images/about/objectives.jpg" alt="Objectives of the Council" className="rounded-2xl shadow-lg w-full max-w-2xl object-cover" />
              </div>
              <div className="space-y-4">
                {objectives.map((obj, i) => (
                  <div key={i} className="flex gap-4 items-start">
                    <span className="w-8 h-8 rounded-full gradient-wine-purple flex items-center justify-center text-primary-foreground font-bold text-sm shrink-0">
                      {i + 1}
                    </span>
                    <p className="text-muted-foreground leading-relaxed pt-1">{obj}</p>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
