import { useParams, useSearchParams, Link } from "react-router-dom";
import Layout from "@/components/Layout";
import Seo from "@/components/Seo";
import SectionHeader from "@/components/SectionHeader";
import { chapterMembersData, type ChapterMember } from "@/data/chapterMembers";
import logoImg from "@/assets/logo.png";
import { Phone, MessageCircle, Gift, Award } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";


const chapters = [
  "Aba", "Abuja", "Anambra", "Benue", "Calabar", "Ebonyi", "Enugu",
  "Ibadan", "Ifaki", "Igbobini", "Ikot-Ekpene", "Ilesa", "Kaduna",
  "Lagos", "Lagos Mainland", "Okigwe", "Oron", "Portharcout", "RIYE",
  "Umuahia", "Uyo"
];

const getInitials = (name: string) => {
  const cleaned = name
    .replace(/^(SIR|DAME|CHIEF|HON\.|DR\.|PROF\.|BARR\.|ENGR\.|COMR\.|JUSTICE|PRINCE|PRINCESS|AMB\.|ROYAL HIGH CHIEF|BRIG\. GEN\. \(RTD\.\)|REAR ADMIRAL \(RTD\.\)|A\.I\.G\.|OTUNBA|OMOOBA|AARE|SIR \(ENGR\.\)|SIR HON\.|SIR HON\. DR\.|SIR HON\. DR\b)\.?\s*/gi, "")
    .replace(/\s*(KJW|KCW|Ph\.?D)\.?\s*/gi, "")
    .trim();
  const parts = cleaned.split(/\s+/);
  return parts.length >= 2 ? `${parts[0][0]}${parts[parts.length - 1][0]}` : parts[0]?.[0] || "?";
};

const MemberCard = ({ member, fitContain = false, fitTop = false }: { member: ChapterMember; fitContain?: boolean; fitTop?: boolean }) => {
  const resolvedImage = member.image;
  return (
  <div className="rounded-2xl overflow-hidden bg-background border border-border shadow-sm hover:shadow-xl transition-all duration-300 group">
    {/* Image area - more than half the card */}
    <div className={`aspect-[3/4] w-full overflow-hidden ${fitContain ? "bg-muted/40" : "bg-muted"}`}>
      {resolvedImage ? (
        <img
          src={resolvedImage}
          alt={member.name}
          className={`w-full h-full ${fitContain ? "object-contain" : "object-cover"} ${fitTop ? "object-top" : ""} group-hover:scale-105 transition-transform duration-300`}
        />
      ) : (
        <div className="w-full h-full bg-muted flex items-center justify-center p-6">
          <img src={logoImg} alt="Council of Knights logo" className="w-full h-full object-contain opacity-90" />
        </div>
      )}
    </div>
    {/* Info area */}
    <div className="p-4">
      <h3 className="text-foreground text-sm leading-tight uppercase" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 900 }}>
        {member.name}
      </h3>
      {member.position && (
        <p className="text-wine text-xs mt-1 uppercase" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          {member.position}
        </p>
      )}

      {/* Award badge */}
      <div className="mt-2">
        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
          member.award === "KCW" ? "bg-purple-100 text-purple-700" : "bg-wine/10 text-wine"
        }`}>
          <Award size={12} />
          {member.award}
        </span>
      </div>

      {/* Birthday */}
      {member.birthday && (
        <p className="text-muted-foreground text-xs mt-2 flex items-center gap-1">
          <Gift size={12} className="text-gold" />
          {member.birthday}
        </p>
      )}

      {/* Phone & WhatsApp */}
      {member.phone && (
        <div className="mt-2 space-y-1">
          {member.phone.split(/[,\/]/).map((p) => p.trim()).filter(Boolean).map((p) => {
            const digits = p.replace(/[^\d+]/g, "");
            const wa = digits.startsWith("+") ? digits.slice(1) : digits.replace(/^0/, "234");
            return (
              <div key={p} className="flex items-center gap-3">
                <a href={`tel:${digits}`} className="inline-flex items-center gap-1 text-muted-foreground text-xs hover:text-wine transition-colors">
                  <Phone size={13} />
                  {p}
                </a>
                <a
                  href={`https://wa.me/${wa}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Chat on WhatsApp with ${member.name}`}
                  className="inline-flex items-center gap-1 text-green-600 text-xs hover:text-green-800 transition-colors"
                >
                  <MessageCircle size={13} />
                  WhatsApp
                </a>
              </div>
            );
          })}
        </div>
      )}
    </div>
  </div>
);
};

const ChapterDetail = () => {
  const { chapterId } = useParams();
  const [searchParams] = useSearchParams();
  const chapter = chapterId ? chapterMembersData[chapterId] : null;
  const chapterName = chapters.find(c => c.toLowerCase().replace(/\s+/g, '-') === chapterId) || chapterId;

  const rawIndex = searchParams.get("m");
  const selectedIndex =
    chapter && rawIndex !== null && /^\d+$/.test(rawIndex) && Number(rawIndex) < chapter.members.length
      ? Number(rawIndex)
      : null;
  const selectedMember = selectedIndex !== null && chapter ? chapter.members[selectedIndex] : null;

  const fitTop = chapterId === "riye" || chapterId === "lagos" || chapterId === "lagos-mainland";
  const fitContain =
    chapterId === "kaduna" || chapterId === "portharcout" || chapterId === "enugu" || chapterId === "uyo" || chapterId === "okigwe" || chapterId === "igbobini" || chapterId === "umuahia";

  return (
    <Layout>
      <Seo
        title={`${chapterName} Chapter — Council of Knights MCN`}
        description={`Members and leadership of the ${chapterName} chapter of the Council of Knights, Methodist Church Nigeria.`}
        path={`/chapters/${chapterId ?? ""}`}
      />
      <section className="relative h-64 md:h-72 gradient-wine-purple flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground">{chapterName} Chapter</h1>
          <Link to="/chapters" className="text-gold mt-4 inline-block hover:underline text-sm">&larr; Back to all chapters</Link>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 max-w-6xl">
          {chapter ? (
            <>
              <SectionHeader
                title={`${chapter.name} Chapter Members`}
                subtitle={`${chapter.members.length} members • Chairman: ${chapter.members.find(m => m.position === "Chapter Chairman")?.name || "—"}`}
              />
              {selectedMember && (
                <div className="mb-12 flex flex-col items-center">
                  <p className="text-sm text-muted-foreground mb-3">Search result</p>
                  <div className="w-full max-w-xs ring-2 ring-gold rounded-2xl">
                    <MemberCard member={selectedMember} fitTop={fitTop} fitContain={fitContain || selectedMember.position === "Chapter Chairman"} />
                  </div>
                </div>
              )}
              <div className="px-8 md:px-12">
                <Carousel opts={{ align: "start", loop: true, startIndex: selectedIndex ?? 0 }} className="w-full">
                  <CarouselContent className="-ml-4">
                    {chapter.members.map((member, i) => (
                      <CarouselItem key={i} className="pl-4 basis-full sm:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                        <MemberCard member={member} fitTop={fitTop} fitContain={fitContain || member.position === "Chapter Chairman"} />
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  <CarouselPrevious className="-left-4 md:-left-6" />
                  <CarouselNext className="-right-4 md:-right-6" />
                </Carousel>
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <SectionHeader title={`${chapterName} Chapter`} subtitle="Member details will be populated soon" />
              <p className="text-muted-foreground">This chapter's member directory is being compiled.</p>
              <Link to="/chapters" className="inline-flex mt-6 px-6 py-3 gradient-wine-purple text-primary-foreground rounded-full font-medium hover:opacity-90 transition-opacity">
                View All Chapters
              </Link>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default ChapterDetail;
