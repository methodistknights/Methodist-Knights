import { Link } from "react-router-dom";
import Layout from "@/components/Layout";
import Seo from "@/components/Seo";
import SectionHeader from "@/components/SectionHeader";
import hero3 from "@/assets/hero-3.jpg";

const chapters = [
  "Aba", "Abuja", "Anambra", "Benue", "Calabar", "Ebonyi", "Enugu",
  "Ibadan", "Ifaki", "Igbobini", "Ikot-Ekpene", "Ilesa", "Kaduna",
  "Lagos", "Lagos Mainland", "Okigwe", "Oron", "Portharcout", "RIYE",
  "Umuahia", "Uyo"
];

const Chapters = () => {
  return (
    <Layout>
      <Seo
        title="Chapters — Council of Knights MCN"
        description="Browse the 21 archdiocesan chapters of the Council of Knights across Nigeria. Select a chapter to view its members and chairman."
        path="/chapters"
      />
      {/* Hero */}
      <section className="relative h-64 md:h-80 overflow-hidden">
        <img src={hero3} alt="Chapters" className="w-full h-full object-cover" />
        <div className="absolute inset-0 gradient-wine-purple opacity-80" />
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground">Our Chapters</h1>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <SectionHeader title="21 Chapters Across Nigeria" subtitle="Select a chapter to view its members" />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 max-w-5xl mx-auto">
            {chapters.map((chapter) => (
              <Link
                key={chapter}
                to={`/chapters/${chapter.toLowerCase().replace(/\s+/g, '-')}`}
                className="group p-6 text-center bg-background rounded-xl border-2 border-border hover:border-wine hover:shadow-lg transition-all"
              >
                <div className="w-12 h-12 rounded-full gradient-wine-purple mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <span className="text-primary-foreground font-bold">{chapter[0]}</span>
                </div>
                <p className="font-semibold text-foreground group-hover:text-wine transition-colors text-sm">{chapter}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Chapters;
