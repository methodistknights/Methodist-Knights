import { useState } from "react";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import Layout from "@/components/Layout";
import Seo from "@/components/Seo";
import SectionHeader from "@/components/SectionHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import contactHeroImg from "@/assets/contact-hero.jpg";

const Contact = () => {
  const { toast } = useToast();
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Message Sent", description: "Thank you for contacting us. We will respond soon." });
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <Layout>
      <Seo
        title="Contact — Council of Knights MCN"
        description="Get in touch with the Council of Knights of John Wesley and Charles Wesley, Methodist Church Nigeria."
        path="/contact"
      />
      <section className="relative h-64 md:h-72 overflow-hidden">
        <img src={contactHeroImg} alt="Contact Us" className="w-full h-full object-cover" />
        <div className="absolute inset-0 gradient-wine-purple opacity-80" />
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground">Contact Us</h1>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* Contact Info */}
            <div>
              <SectionHeader title="Get In Touch" />
              <div className="space-y-6">
                <div className="flex items-start gap-4 p-4 bg-cream rounded-xl">
                  <MapPin className="text-wine mt-1 shrink-0" />
                  <div>
                    <h4 className="font-semibold text-foreground">Address</h4>
                    <p className="text-muted-foreground text-sm">Methodist Church Nigeria, Wesley House, 21/22, Marina, Lagos, Nigeria</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-cream rounded-xl">
                  <Phone className="text-wine shrink-0" />
                  <div>
                    <h4 className="font-semibold text-foreground">Phone</h4>
                    <div className="flex flex-col gap-1 mt-1">
                      <a href="tel:08063253927" className="text-muted-foreground text-sm hover:text-wine transition-colors">08063253927</a>
                      <a href="tel:07082384046" className="text-muted-foreground text-sm hover:text-wine transition-colors">07082384046</a>
                      <a href="tel:08033166610" className="text-muted-foreground text-sm hover:text-wine transition-colors">08033166610</a>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-cream rounded-xl">
                  <Mail className="text-wine shrink-0" />
                  <div>
                    <h4 className="font-semibold text-foreground">Email</h4>
                    <a href="mailto:methodistknights@gmail.com" className="text-muted-foreground text-sm hover:text-wine transition-colors">
                      methodistknights@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex gap-3 flex-wrap">
                  <a href="https://wa.me/2348063253927" target="_blank" rel="noopener noreferrer" className="px-4 py-2 gradient-wine-purple text-primary-foreground rounded-full text-sm font-medium hover:opacity-90 transition-opacity">
                    WhatsApp 08063253927
                  </a>
                  <a href="https://wa.me/2347082384046" target="_blank" rel="noopener noreferrer" className="px-4 py-2 gradient-wine-purple text-primary-foreground rounded-full text-sm font-medium hover:opacity-90 transition-opacity">
                    WhatsApp 07082384046
                  </a>
                  <a href="https://wa.me/2348033166610" target="_blank" rel="noopener noreferrer" className="px-4 py-2 gradient-wine-purple text-primary-foreground rounded-full text-sm font-medium hover:opacity-90 transition-opacity">
                    WhatsApp 08033166610
                  </a>
                  <a href="mailto:methodistknights@gmail.com" className="px-4 py-2 gradient-gold text-foreground rounded-full text-sm font-medium hover:opacity-90 transition-opacity">
                    Send Email
                  </a>
                </div>

                <div className="mt-6 rounded-xl overflow-hidden border border-border">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.7!2d3.394!3d6.447!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNsKwMjYnNDkuMiJOIDPCsDIzJzM4LjQiRQ!5e0!3m2!1sen!2sng!4v1"
                    width="100%"
                    height="250"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    title="Our Location"
                  />
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <SectionHeader title="Send a Message" />
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input
                  placeholder="Your Name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  className="bg-cream border-border"
                />
                <Input
                  type="email"
                  placeholder="Your Email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                  className="bg-cream border-border"
                />
                <Textarea
                  placeholder="Your Message"
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  required
                  rows={6}
                  className="bg-cream border-border"
                />
                <Button type="submit" className="w-full gradient-wine-purple text-primary-foreground hover:opacity-90">
                  <Send size={16} className="mr-2" />
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Contact;
