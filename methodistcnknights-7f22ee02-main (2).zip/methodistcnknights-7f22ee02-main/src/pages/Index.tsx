import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { ChevronLeft, ChevronRight, Users, MapPin, Cake, Mail } from "lucide-react";
import Layout from "@/components/Layout";
import Seo from "@/components/Seo";
import SectionHeader from "@/components/SectionHeader";
import hero1 from "@/assets/hero-1.jpg";
import hero2 from "@/assets/hero-2.jpg";
import hero3 from "@/assets/hero-3.jpg";
import hero4 from "@/assets/hero-4.jpg";
import hero5 from "@/assets/hero-5.jpg";
import aboutImg from "@/assets/about.jpg";
import ladiesImg from "@/assets/ladies-hero.png";
import nexcoHeroImg from "@/assets/nexco-hero.png";
import contactHeroImg from "@/assets/contact-hero.jpg";

const heroSlides = [
  { img: hero1, caption: "Chosen To Defend" },
  { img: hero2, caption: "Knights of John Wesley" },
  { img: hero3, caption: "United in Faith & Service" },
  { img: hero4, caption: "Standing in Honor" },
  { img: hero5, caption: "Ladies of Knights Assembly" },
];

const chaptersList = [
  "Aba", "Abuja", "Anambra", "Benue", "Calabar", "Ebonyi", "Enugu",
  "Ibadan", "Ifaki", "Igbobini", "Ikot-Ekpene", "Ilesa", "Kaduna",
  "Lagos", "Lagos Mainland", "Okigwe", "Oron", "Portharcout", "RIYE",
  "Umuahia", "Uyo"
];

const nexcoMembers = [
  { name: "Sir Victor Etefia-KJW", position: "National President", phone: "08035524003" },
  { name: "Sir Dele Wickliffe", position: "Vice President", phone: "08033166610" },
  { name: "Sir Friday Eluwa KJW, Ph.D", position: "Nat. Secretary", phone: "08033053712" },
];

// Birthday checker helper
const getTodayBirthdayKnights = () => {
  const today = new Date();
  const day = today.getDate();
  const month = today.toLocaleString('en', { month: 'long' }).toUpperCase();
  // Demo birthday member
  return [];
};

const useCountUp = (end: number, duration = 2000) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const startTime = performance.now();
          const animate = (now: number) => {
            const progress = Math.min((now - startTime) / duration, 1);
            setCount(Math.floor(progress * end));
            if (progress < 1) requestAnimationFrame(animate);
          };
          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [end, duration]);

  return { count, ref };
};

const Index = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const birthdayKnights = getTodayBirthdayKnights();
  const members = useCountUp(700);
  const chapters = useCountUp(21);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length);

  return (
    <Layout>
      <Seo
        title="Council of Knights MCN — Chosen To Defend"
        description="Council of Knights of John Wesley and Charles Wesley, Methodist Church Nigeria. 21 chapters across Nigeria united in faith, service, and leadership."
        path="/"
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "Council of Knights MCN",
          url: "https://methodistcnknights.lovable.app",
        }}
      />
      {/* Hero Slider */}
      <section className="relative h-[70vh] md:h-[85vh] overflow-hidden">
        {heroSlides.map((slide, i) => (
          <div
            key={i}
            className={`absolute inset-0 transition-opacity duration-1000 ${i === currentSlide ? "opacity-100" : "opacity-0"}`}
          >
            <img
              src={slide.img}
              alt={slide.caption}
              className="w-full h-full object-cover"
              loading={i === 0 ? "eager" : "lazy"}
              fetchPriority={i === 0 ? "high" : "auto"}
              decoding={i === 0 ? "sync" : "async"}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-wine-dark/90 via-wine-dark/40 to-transparent" />
          </div>
        ))}
        <div className="absolute inset-0 flex items-center justify-center text-center px-4">
          <div className="animate-fade-in">
            <p className="text-gold font-semibold text-sm md:text-base tracking-[0.3em] uppercase mb-4">
              Welcome to the Council of Knights
            </p>
            <h1 className="text-4xl md:text-6xl lg:text-8xl font-black text-primary-foreground mb-6 leading-tight tracking-tight drop-shadow-2xl">
              {heroSlides[currentSlide].caption}
            </h1>
            <p className="text-gold text-xl md:text-2xl font-bold tracking-widest uppercase">
              "Chosen To Defend"
            </p>
            <p className="text-primary-foreground/80 text-lg md:text-xl max-w-xl mx-auto mt-6 mb-8">
              Knights of John Wesley & Charles Wesley, Methodist Church Nigeria
            </p>
            <div className="flex gap-4 justify-center">
              <Link to="/about" className="px-8 py-3 gradient-gold text-foreground font-semibold rounded-full hover:opacity-90 transition-opacity">
                Learn More
              </Link>
              <Link to="/contact" className="px-8 py-3 border-2 border-gold text-gold font-semibold rounded-full hover:bg-gold/10 transition-colors">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
        <button onClick={prevSlide} className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center text-primary-foreground hover:bg-gold/20 transition-colors backdrop-blur-sm">
          <ChevronLeft size={20} />
        </button>
        <button onClick={nextSlide} className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center text-primary-foreground hover:bg-gold/20 transition-colors backdrop-blur-sm">
          <ChevronRight size={20} />
        </button>
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
          {heroSlides.map((_, i) => (
            <button key={i} onClick={() => setCurrentSlide(i)} className={`w-2.5 h-2.5 rounded-full transition-all ${i === currentSlide ? "bg-gold w-8" : "bg-primary-foreground/40"}`} />
          ))}
        </div>
      </section>

      {/* Birthday Banner */}
      {birthdayKnights.length > 0 && (
        <section className="bg-gold/10 border-y border-gold/30 py-4">
          <div className="container mx-auto px-4 flex items-center gap-3 justify-center">
            <Cake className="text-gold" size={24} />
            <p className="text-foreground font-medium">Happy Birthday to our Knight(s) today!</p>
          </div>
        </section>
      )}

      {/* Stats */}
      <section className="py-16 bg-cream">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 gap-6 max-w-lg mx-auto">
            <div ref={members.ref} className="text-center p-6 bg-background rounded-xl shadow-sm border border-border">
              <Users className="mx-auto text-wine mb-3" size={32} />
              <p className="text-3xl font-bold text-gradient-wine">{members.count}+</p>
              <p className="text-muted-foreground text-sm mt-1">Members</p>
            </div>
            <div ref={chapters.ref} className="text-center p-6 bg-background rounded-xl shadow-sm border border-border">
              <MapPin className="mx-auto text-wine mb-3" size={32} />
              <p className="text-3xl font-bold text-gradient-wine">{chapters.count}</p>
              <p className="text-muted-foreground text-sm mt-1">Chapters</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img src={aboutImg} alt="About Council of Knights" className="rounded-2xl shadow-xl w-full object-cover aspect-[4/3]" />
              <div className="absolute -bottom-4 -right-4 w-24 h-24 gradient-gold rounded-2xl -z-10" />
            </div>
            <div>
              <SectionHeader title="About Us" subtitle="" />
              <p className="text-muted-foreground leading-relaxed mb-4">
                The Council of Knights of John Wesley and Charles Wesley is the highest Award which Methodist Church Nigeria confers on any member of the Laity for their contributions in the Church.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-6">
                While a male Knight is referred to as 'Sir', the female Knight is referred to as a 'Dame'. The collection or assembly of Knights is known as the Council of Knights.
              </p>
              <Link to="/about" className="inline-flex px-6 py-3 gradient-wine-purple text-primary-foreground font-semibold rounded-full hover:opacity-90 transition-opacity">
                Read More
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* NEXCO Preview */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={nexcoHeroImg} alt="NEXCO" className="w-full h-full object-cover" />
          <div className="absolute inset-0 gradient-wine-purple opacity-90" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <SectionHeader title="National Executive Council" subtitle="Leadership of the Council of Knights" light />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {nexcoMembers.map((member, i) => (
              <div key={i} className="bg-primary-foreground/10 backdrop-blur-sm rounded-xl p-6 text-center border border-primary-foreground/10">
                <div className="w-20 h-20 rounded-full gradient-gold mx-auto mb-4 flex items-center justify-center text-foreground font-bold text-xl">
                  {member.name.split(" ")[1]?.[0] || "K"}
                </div>
                <h3 className="font-bold text-gold text-lg">{member.name}</h3>
                <p className="text-primary-foreground/70 text-sm mt-1">{member.position}</p>
                <a href={`tel:${member.phone}`} className="text-gold/80 text-sm mt-2 inline-block hover:text-gold transition-colors">
                  {member.phone}
                </a>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link to="/nexco-exco" className="inline-flex px-8 py-3 gradient-gold text-foreground font-semibold rounded-full hover:opacity-90 transition-opacity">
              View All Executives
            </Link>
          </div>
        </div>
      </section>

      {/* Ladies of Knights Preview */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <SectionHeader title="Ladies of Knights" />
              <p className="text-muted-foreground leading-relaxed mb-6">
                This is an Assembly of the wives (spouses) of the Knights. The Assembly is governed by The National Chairperson and her team at the national level while the Archdioceses (or Chapters) are run by the ANCHOR LADIES.
              </p>
              <Link to="/ladies" className="inline-flex px-6 py-3 gradient-wine-purple text-primary-foreground font-semibold rounded-full hover:opacity-90 transition-opacity">
                Learn More
              </Link>
            </div>
            <div className="order-1 md:order-2 relative">
              <img src={ladiesImg} alt="Ladies of Knights" className="rounded-2xl shadow-xl w-full object-cover aspect-[4/3]" />
              <div className="absolute -bottom-4 -left-4 w-24 h-24 gradient-wine-purple rounded-2xl -z-10 opacity-50" />
            </div>
          </div>
        </div>
      </section>

      {/* Chapters Preview */}
      <section className="py-20 bg-cream">
        <div className="container mx-auto px-4">
          <SectionHeader title="Our Chapters" subtitle="21 Chapters across Nigeria" />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3">
            {chaptersList.map((chapter) => (
              <Link
                key={chapter}
                to={`/chapters/${chapter.toLowerCase().replace(/\s+/g, '-')}`}
                className="p-3 text-center bg-background rounded-lg border border-border hover:border-wine hover:shadow-md transition-all font-medium text-sm text-foreground hover:text-wine"
              >
                {chapter}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Us Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={contactHeroImg} alt="Contact Us" className="w-full h-full object-cover" />
          <div className="absolute inset-0 gradient-wine-purple opacity-85" />
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <Mail className="mx-auto text-gold mb-4" size={40} />
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">Get In Touch</h2>
          <p className="text-primary-foreground/80 text-lg max-w-xl mx-auto mb-8">
            Have questions or want to learn more about the Council of Knights? We'd love to hear from you.
          </p>
          <Link to="/contact" className="inline-flex px-8 py-3 gradient-gold text-foreground font-semibold rounded-full hover:opacity-90 transition-opacity">
            Contact Us
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
