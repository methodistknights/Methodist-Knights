interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  light?: boolean;
}

const SectionHeader = ({ title, subtitle, light }: SectionHeaderProps) => (
  <div className="text-center mb-12">
    <h2 className={`text-3xl md:text-4xl font-bold mb-3 ${light ? "text-primary-foreground" : "text-gradient-wine"}`}>
      {title}
    </h2>
    {subtitle && (
      <p className={`text-lg max-w-2xl mx-auto ${light ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
        {subtitle}
      </p>
    )}
    <div className="w-20 h-1 gradient-gold mx-auto mt-4 rounded-full" />
  </div>
);

export default SectionHeader;
