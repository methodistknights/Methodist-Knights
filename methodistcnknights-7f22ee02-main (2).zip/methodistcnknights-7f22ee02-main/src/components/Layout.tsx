import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { Menu } from "lucide-react";
import { SidebarProvider, useSidebar } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import SearchBar from "./SearchBar";
import Footer from "./Footer";
import logo from "@/assets/logo.png";

const HamburgerTrigger = () => {
  const { toggleSidebar } = useSidebar();
  return (
    <button
      onClick={toggleSidebar}
      aria-label="Toggle navigation menu"
      className="inline-flex items-center justify-center h-10 w-10 rounded-md text-foreground hover:bg-muted transition-colors"
    >
      <Menu className="h-5 w-5" />
    </button>
  );
};

const Layout = ({ children }: { children: ReactNode }) => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />

        <div className="flex-1 flex flex-col min-w-0">
          {/* Top header bar */}
          <header className="sticky top-0 z-40 h-16 grid grid-cols-[auto_1fr_auto] items-center border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-4 gap-2">
            <HamburgerTrigger />
            <div className="flex justify-center">
              <Link
                to="/"
                aria-label="Council of Knights — Home"
                className="flex items-center gap-2 rounded-full hover:opacity-90 transition-opacity focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <img
                  src={logo}
                  alt="Council of Knights logo"
                  className="h-10 w-10 sm:h-12 sm:w-12 rounded-full border-2 border-gold object-cover shadow-sm"
                />
                <span className="hidden md:inline text-sm font-bold text-foreground tracking-wide">
                  Council of Knights
                </span>
              </Link>
            </div>
            <SearchBar />
          </header>

          <main className="flex-1">{children}</main>
          <Footer />
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Layout;
