import { Link } from "react-router-dom";
import { Mail, Phone, MapPin } from "lucide-react";
import logo from "@/assets/logo.png";

const Footer = () => {
  return (
    <footer className="bg-black text-primary-foreground">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <Link to="/" className="flex items-center gap-3 mb-4">
              <img src={logo} alt="Logo" className="h-16 w-16 rounded-full border-2 border-gold object-cover" />
            </Link>
            <h3 className="font-bold text-lg text-gold mb-2">Council of Knights</h3>
            <p className="text-sm opacity-80 leading-relaxed">
              Knights of John Wesley & Charles Wesley, Methodist Church Nigeria.
            </p>
            <p className="text-gold italic mt-3 font-semibold text-sm">"Chosen To Defend"</p>
          </div>

          <div>
            <h4 className="font-bold text-gold mb-4">Quick Links</h4>
            <div className="flex flex-col gap-2">
              {[
                { label: "Home", to: "/" },
                { label: "About Us", to: "/about" },
                { label: "NEXCO & EXCO", to: "/nexco-exco" },
                { label: "Chapters", to: "/chapters" },
                { label: "Contact", to: "/contact" },
              ].map((link) => (
                <Link key={link.to} to={link.to} className="text-sm opacity-80 hover:text-gold hover:opacity-100 transition-colors">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold text-gold mb-4">Contact Info</h4>
            <div className="flex flex-col gap-3 text-sm">
              <div className="flex items-start gap-2">
                <MapPin size={16} className="text-gold mt-1 shrink-0" />
                <span className="opacity-80">Methodist Church Nigeria, Wesley House, 21/22 Marina, Lagos, Nigeria</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone size={16} className="text-gold shrink-0" />
                <div className="flex flex-col gap-1">
                  <a href="tel:08063253927" className="opacity-80 hover:text-gold transition-colors">08063253927</a>
                  <a href="tel:07082384046" className="opacity-80 hover:text-gold transition-colors">07082384046</a>
                  <a href="tel:08033166610" className="opacity-80 hover:text-gold transition-colors">08033166610</a>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={16} className="text-gold shrink-0" />
                <a href="mailto:methodistknights@gmail.com" className="opacity-80 hover:text-gold transition-colors">methodistknights@gmail.com</a>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-gold mb-4">Connect With Us</h4>
            <div className="flex gap-3">
              {["2348063253927", "2347082384046", "2348033166610"].map((num) => (
                <a
                  key={num}
                  href={`https://wa.me/${num}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`WhatsApp 0${num.slice(3)}`}
                  className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-gold/20 transition-colors"
                >
                  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current text-gold">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </a>
              ))}
            </div>
            <div className="mt-6">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.7!2d3.394!3d6.447!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNsKwMjYnNDkuMiJOIDPCsDIzJzM4LjQiRQ!5e0!3m2!1sen!2sng!4v1"
                width="100%"
                height="120"
                style={{ border: 0, borderRadius: '8px', opacity: 0.8 }}
                allowFullScreen
                loading="lazy"
                title="Location"
              />
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 mt-12 pt-6 text-center text-sm opacity-60">
          <p>&copy; {new Date().getFullYear()} Council of Knights, Methodist Church Nigeria. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
