import { useState, useRef, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X } from "lucide-react";
import { searchAll, type SearchableItem } from "@/lib/searchIndex";

const categoryColors: Record<SearchableItem["category"], string> = {
  Page: "bg-primary/10 text-primary",
  Chapter: "bg-gold/20 text-gold-foreground",
  "NEXCO/EXCO": "bg-purple-500/15 text-purple-700 dark:text-purple-300",
  "Chapter Chairman": "bg-wine/15 text-wine",
  Member: "bg-muted text-muted-foreground",
  Birthday: "bg-pink-500/15 text-pink-700 dark:text-pink-300",
};

const SearchBar = () => {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const results = useMemo(() => searchAll(query, 40), [query]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setMobileOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleSelect = (path: string) => {
    navigate(path);
    setQuery("");
    setOpen(false);
    setMobileOpen(false);
  };

  return (
    <div ref={ref} className="relative">
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="sm:hidden p-2 text-muted-foreground hover:text-foreground transition-colors"
        aria-label="Search"
      >
        <Search size={20} />
      </button>

      {/* Desktop input - always visible */}
      <div className="hidden sm:flex items-center relative">
        <Search size={16} className="absolute left-3 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search names, chapters, birthdays..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          className="w-56 lg:w-80 pl-9 pr-8 py-2 text-sm rounded-full border border-border bg-muted/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
        />
        {query && (
          <button
            onClick={() => {
              setQuery("");
              setOpen(false);
            }}
            className="absolute right-3 text-muted-foreground hover:text-foreground"
            aria-label="Clear search"
          >
            <X size={14} />
          </button>
        )}
      </div>

      {/* Mobile expanded input */}
      {mobileOpen && (
        <div className="sm:hidden absolute right-0 top-12 w-[88vw] max-w-sm z-50">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search names, chapters, birthdays..."
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setOpen(true);
              }}
              autoFocus
              className="w-full pl-9 pr-8 py-2 text-sm rounded-full border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring shadow-lg"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                aria-label="Clear search"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Results dropdown */}
      {open && results.length > 0 && (
        <div className="absolute right-0 top-full mt-2 w-[88vw] max-w-md sm:w-96 bg-background border border-border rounded-xl shadow-xl z-50 max-h-96 overflow-y-auto">
          <div className="px-3 py-2 text-xs text-muted-foreground border-b border-border/50">
            {results.length} result{results.length === 1 ? "" : "s"}
          </div>
          {results.map((item, i) => (
            <button
              key={`${item.path}-${item.label}-${i}`}
              onClick={() => handleSelect(item.path)}
              className="w-full text-left px-4 py-3 text-sm hover:bg-muted transition-colors border-b border-border/50 last:border-0"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-foreground truncate">{item.label}</div>
                  {item.sublabel && (
                    <div className="text-xs text-muted-foreground truncate mt-0.5">{item.sublabel}</div>
                  )}
                </div>
                <span
                  className={`text-[10px] uppercase tracking-wide px-2 py-0.5 rounded-full whitespace-nowrap ${categoryColors[item.category]}`}
                >
                  {item.category}
                </span>
              </div>
            </button>
          ))}
        </div>
      )}

      {open && query.trim().length >= 1 && results.length === 0 && (
        <div className="absolute right-0 top-full mt-2 w-[88vw] max-w-md sm:w-96 bg-background border border-border rounded-xl shadow-xl z-50 p-4 text-sm text-muted-foreground text-center">
          No results found for "{query}"
        </div>
      )}
    </div>
  );
};

export default SearchBar;
