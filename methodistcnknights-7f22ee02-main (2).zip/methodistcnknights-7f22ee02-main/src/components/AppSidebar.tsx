import { Home, Info, Shield, Map, Heart, Newspaper, Image, Phone } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import logo from "@/assets/logo.png";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const navItems = [
  { title: "Home", url: "/", icon: Home },
  { title: "About", url: "/about", icon: Info },
  { title: "NEXCO & EXCO", url: "/nexco-exco", icon: Shield },
  { title: "Chapters", url: "/chapters", icon: Map },
  { title: "Ladies of Knights", url: "/ladies", icon: Heart },
  { title: "News", url: "/news", icon: Newspaper },
  { title: "Gallery", url: "/gallery", icon: Image },
  { title: "Contact", url: "/contact", icon: Phone },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <div className="gradient-wine-purple h-full flex flex-col">
        {/* Logo */}
        <div className="p-4 flex items-center gap-3 border-b border-white/10">
          <img
            src={logo}
            alt="Council of Knights Logo"
            className="h-10 w-10 rounded-full border-2 border-gold object-cover flex-shrink-0"
          />
          {!collapsed && (
            <div className="overflow-hidden">
              <p className="text-gold font-bold text-xs leading-tight whitespace-nowrap">Council of Knights</p>
              <p className="text-white/60 text-[10px] whitespace-nowrap">Methodist Church Nigeria</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <SidebarContent className="px-2 py-4">
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                {navItems.map((item) => {
                  const active = location.pathname === item.url;
                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton asChild tooltip={item.title}>
                        <Link
                          to={item.url}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                            active
                              ? "bg-gold/20 text-gold"
                              : "text-white/80 hover:text-gold hover:bg-white/5"
                          }`}
                        >
                          <item.icon className="h-4 w-4 flex-shrink-0" />
                          {!collapsed && <span>{item.title}</span>}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>

        {/* Footer motto */}
        {!collapsed && (
          <div className="mt-auto p-4 border-t border-white/10">
            <p className="text-gold/70 text-[10px] italic text-center">"Chosen To Defend"</p>
          </div>
        )}
      </div>
    </Sidebar>
  );
}
