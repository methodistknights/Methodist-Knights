import { chapterMembersData } from "@/data/chapterMembers";

export interface SearchableItem {
  label: string;
  sublabel?: string;
  path: string;
  keywords: string;
  category: "Page" | "Chapter" | "NEXCO/EXCO" | "Chapter Chairman" | "Member" | "Birthday";
}

interface IndexedItem extends SearchableItem {
  /** normalised searchable text */
  hay: string;
  /** unique word tokens from label + sublabel + keywords */
  tokens: string[];
  /** tokens from the label only (weighted higher) */
  labelTokens: string[];
  /** digits only (phone numbers) */
  digits: string;
  /** initials of the cleaned name, e.g. "vе" */
  initials: string;
}

/* ------------------------------------------------------------------ */
/* Text helpers                                                        */
/* ------------------------------------------------------------------ */

const HONORIFICS =
  /\b(sir|dame|chief|hon|dr|prof|barr|engr|comr|justice|prince|princess|amb|otunba|omooba|aare|evang|rev|mr|mrs|miss|high|royal|rtd|brig|gen|admiral|aig|kjw|kcw|phd)\b/g;

export const normalize = (s: string): string =>
  s
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const stripTitles = (s: string): string =>
  normalize(s).replace(HONORIFICS, " ").replace(/\s+/g, " ").trim();

const tokenize = (s: string): string[] => normalize(s).split(" ").filter(Boolean);

/** Damerau-ish Levenshtein with early exit */
const editDistance = (a: string, b: string, max: number): number => {
  if (a === b) return 0;
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    let best = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      const v = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      cur[j] = v;
      if (v < best) best = v;
    }
    if (best > max) return max + 1;
    prev = cur;
  }
  return prev[b.length];
};

/** consonant skeleton — catches "ekpenyon" vs "ekpenyong", "mohamed"/"muhammad" */
const skeleton = (s: string): string =>
  s
    .replace(/[aeiou]/g, "")
    .replace(/(.)\1+/g, "$1")
    .replace(/ph/g, "f")
    .replace(/ck/g, "k")
    .replace(/z/g, "s");

/** does token `t` appear in `word` as an ordered subsequence (typo/abbrev tolerant)? */
const isSubsequence = (t: string, word: string): boolean => {
  let i = 0;
  for (let j = 0; j < word.length && i < t.length; j++) if (word[j] === t[i]) i++;
  return i === t.length;
};

/* ------------------------------------------------------------------ */
/* Static entries                                                      */
/* ------------------------------------------------------------------ */

const pages: SearchableItem[] = [
  { label: "Home", path: "/", keywords: "home landing council of knights methodist church nigeria mcn start main", category: "Page" },
  { label: "About Us", path: "/about", keywords: "about history mission vision motto chosen to defend methodist church nigeria origin objectives who we are", category: "Page" },
  { label: "NEXCO & EXCO", path: "/nexco-exco", keywords: "nexco exco national executive council officers leadership president vice secretary treasurer pro auditor ex-officio chairmen", category: "Page" },
  { label: "Chapters", path: "/chapters", keywords: "chapters all branches states directory list", category: "Page" },
  { label: "Ladies of Knights", path: "/ladies", keywords: "ladies of knights women assembly dames lok", category: "Page" },
  { label: "News & Events", path: "/news", keywords: "news events updates announcements conference programme convention", category: "Page" },
  { label: "Gallery", path: "/gallery", keywords: "gallery photos images pictures album media", category: "Page" },
  { label: "Contact Us", path: "/contact", keywords: "contact email phone address whatsapp reach us enquiries location", category: "Page" },
];

const nexcoMembers: SearchableItem[] = [
  { label: "Sir Victor Etefia-KJW", sublabel: "National President", path: "/nexco-exco", keywords: "victor etefia president 08035524003", category: "NEXCO/EXCO" },
  { label: "Sir Dele Wickliffe", sublabel: "Vice President", path: "/nexco-exco", keywords: "dele wickliffe vice president 08033166610", category: "NEXCO/EXCO" },
  { label: "Sir Friday Eluwa KJW, Ph.D", sublabel: "National Secretary", path: "/nexco-exco", keywords: "friday eluwa secretary 08033053712", category: "NEXCO/EXCO" },
  { label: "Sir Emmanuel S. Audu KJW", sublabel: "Nat. Asst. Sec", path: "/nexco-exco", keywords: "emmanuel audu assistant secretary 08053914467", category: "NEXCO/EXCO" },
  { label: "Sir Barr. Friday Ekpety KJW", sublabel: "National Treasurer", path: "/nexco-exco", keywords: "friday ekpety treasurer 08023131366", category: "NEXCO/EXCO" },
  { label: "Sir Prof. Akobundu Ugah-KJW", sublabel: "Nat. Fin. Sec", path: "/nexco-exco", keywords: "akobundu ugah financial secretary 08068181279", category: "NEXCO/EXCO" },
  { label: "Sir Dr. Emeka Ohaeri KJW", sublabel: "National PRO", path: "/nexco-exco", keywords: "emeka ohaeri pro public relations 08034957064", category: "NEXCO/EXCO" },
  { label: "Sir Inwon L. Fingesi KJW", sublabel: "National Auditor", path: "/nexco-exco", keywords: "inwon fingesi auditor 08033958041", category: "NEXCO/EXCO" },
  { label: "Sir Ide Ifeanyi Okechukwu-KJW", sublabel: "Ex-Officio", path: "/nexco-exco", keywords: "ifeanyi okechukwu ex officio 08035501797", category: "NEXCO/EXCO" },
  { label: "Sir Justice Umoekoyo Essang", sublabel: "Ex-Officio", path: "/nexco-exco", keywords: "justice essang umoekoyo ex officio 08130080935", category: "NEXCO/EXCO" },
  { label: "Sir Bola Ogunsanwo KJW", sublabel: "Ex-Officio", path: "/nexco-exco", keywords: "bola ogunsanwo ex officio 08032417142", category: "NEXCO/EXCO" },
];

/** extra spellings people type for certain chapters */
const chapterAliases: Record<string, string> = {
  portharcout: "port harcourt portharcourt phc ph rivers",
  ilesa: "ilesha ilesa osun",
  riye: "riye ondo",
  "lagos-mainland": "lagos mainland yaba",
  "ikot-ekpene": "ikot ekpene akwa ibom",
  uyo: "uyo akwa ibom",
  aba: "aba abia",
  umuahia: "umuahia abia",
  okigwe: "okigwe imo",
  enugu: "enugu",
  abuja: "abuja fct",
  calabar: "calabar cross river",
  kaduna: "kaduna",
  benue: "benue makurdi",
  ibadan: "ibadan oyo",
  ifaki: "ifaki ekiti",
  igbobini: "igbobini ondo",
  anambra: "anambra onitsha awka",
  ebonyi: "ebonyi abakaliki",
  oron: "oron akwa ibom",
  lagos: "lagos",
};

/* ------------------------------------------------------------------ */
/* Build the index from chapter data                                   */
/* ------------------------------------------------------------------ */

const chapterPages: SearchableItem[] = [];
const chairmenItems: SearchableItem[] = [];
const memberItems: SearchableItem[] = [];
const birthdayItems: SearchableItem[] = [];

Object.entries(chapterMembersData).forEach(([slug, data]) => {
  const alias = chapterAliases[slug] ?? slug.replace(/-/g, " ");
  const chairman = data.members.find((m) => m.position === "Chapter Chairman");

  chapterPages.push({
    label: `${data.name} Chapter`,
    sublabel: chairman ? `Chairman: ${chairman.name}` : `${data.members.length} members`,
    path: `/chapters/${slug}`,
    keywords: `${data.name} chapter branch ${alias} ${chairman?.name ?? ""} ${chairman?.phone ?? ""}`,
    category: "Chapter",
  });

  data.members.forEach((m, idx) => {
    const isChairman = m.position === "Chapter Chairman";
    const base = `${m.name} ${data.name} ${alias} ${m.award} ${m.phone} ${m.whatsapp ?? ""} ${m.position ?? ""} ${m.birthday} ${stripTitles(m.name)}`;
    const memberPath = `/chapters/${slug}?m=${idx}`;

    if (isChairman) {
      chairmenItems.push({
        label: m.name,
        sublabel: `${data.name} Chapter Chairman`,
        path: memberPath,
        keywords: `${base} chairman chair head leader`,
        category: "Chapter Chairman",
      });
    } else {
      memberItems.push({
        label: m.name,
        sublabel: `${data.name} Chapter${m.position ? ` • ${m.position}` : ""} • ${m.award}`,
        path: memberPath,
        keywords: base,
        category: "Member",
      });
    }

    if (m.birthday && m.birthday.trim().length > 0) {
      birthdayItems.push({
        label: `${m.name} — ${m.birthday}`,
        sublabel: `Birthday • ${data.name} Chapter`,
        path: memberPath,
        keywords: `birthday born celebrant ${m.birthday} ${m.name} ${data.name} ${alias}`,
        category: "Birthday",
      });
    }
  });
});

export const searchIndex: SearchableItem[] = [
  ...pages,
  ...nexcoMembers,
  ...chapterPages,
  ...chairmenItems,
  ...memberItems,
  ...birthdayItems,
];

const indexed: IndexedItem[] = searchIndex.map((item) => {
  const labelClean = stripTitles(item.label);
  const hay = normalize(`${item.label} ${item.sublabel ?? ""} ${item.keywords}`);
  const tokenSet = new Set(hay.split(" ").filter(Boolean));
  const labelTokens = Array.from(new Set(tokenize(item.label).concat(labelClean.split(" ")))).filter(Boolean);
  return {
    ...item,
    hay,
    tokens: Array.from(tokenSet),
    labelTokens,
    digits: `${item.keywords} ${item.label}`.replace(/\D/g, ""),
    initials: labelClean
      .split(" ")
      .filter(Boolean)
      .map((w) => w[0])
      .join(""),
  };
});

/* ------------------------------------------------------------------ */
/* Scoring                                                             */
/* ------------------------------------------------------------------ */

const scoreToken = (t: string, item: IndexedItem): number => {
  let best = 0;
  const inLabel = (w: string) => item.labelTokens.includes(w);

  for (const w of item.tokens) {
    let s = 0;
    if (w === t) s = 100;
    else if (w.startsWith(t)) s = 80 - Math.min(20, w.length - t.length);
    else if (t.startsWith(w) && w.length >= 3) s = 60;
    else if (w.includes(t) && t.length >= 3) s = 55;
    else if (t.length >= 4) {
      const max = t.length >= 8 ? 2 : 1;
      const d = editDistance(t, w, max);
      if (d <= max) s = 50 - d * 10;
      else if (skeleton(t) && skeleton(t) === skeleton(w)) s = 40;
      else if (t.length >= 5 && isSubsequence(t, w) && w.length - t.length <= 3) s = 30;
    }
    if (s > 0 && inLabel(w)) s += 25;
    if (s > best) best = s;
  }

  // phrase / partial-word hit anywhere in the haystack
  if (best === 0 && t.length >= 3 && item.hay.includes(t)) best = 35;

  // initials match: "vе" -> Victor Etefia
  if (best === 0 && t.length >= 2 && t.length <= 4 && item.initials.startsWith(t)) best = 45;

  return best;
};

export function searchAll(query: string, limit = 30): SearchableItem[] {
  const raw = query.trim();
  if (raw.length < 1) return [];

  const q = normalize(raw);
  if (!q) return [];

  const tokens = q.split(" ").filter(Boolean);
  const digitQuery = raw.replace(/\D/g, "");

  const scored: { item: IndexedItem; score: number }[] = [];

  for (const item of indexed) {
    let total = 0;
    let matched = 0;

    for (const t of tokens) {
      const s = scoreToken(t, item);
      if (s > 0) {
        matched++;
        total += s;
      }
    }

    // phone / digit search
    if (digitQuery.length >= 3 && item.digits.includes(digitQuery)) {
      matched = tokens.length;
      total += 120;
    }

    if (matched === 0) continue;

    // require most tokens to match; single misses tolerated on long queries
    const required = tokens.length <= 2 ? tokens.length : Math.ceil(tokens.length * 0.6);
    if (matched < required) continue;

    // whole-phrase bonus
    if (item.hay.includes(q)) total += 60;
    if (normalize(item.label).startsWith(q)) total += 40;

    // slight category preference so pages/chapters float above raw duplicates
    const catBonus =
      item.category === "Page" ? 12 : item.category === "Chapter" ? 10 : item.category === "Chapter Chairman" ? 8 : item.category === "NEXCO/EXCO" ? 6 : 0;

    scored.push({ item, score: total * (matched / tokens.length) + catBonus });
  }

  scored.sort((a, b) => b.score - a.score || a.item.label.length - b.item.label.length);

  // de-duplicate identical label+path pairs (keeps birthday entries distinct)
  const seen = new Set<string>();
  const out: SearchableItem[] = [];
  for (const { item } of scored) {
    const key = `${item.category}|${item.label}|${item.path}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(item);
    if (out.length >= limit) break;
  }
  return out;
}
