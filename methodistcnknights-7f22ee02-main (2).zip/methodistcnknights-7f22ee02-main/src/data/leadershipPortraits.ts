// Portraits cropped from the supplied captioned leadership sheets.
// Keep these shared between the national leadership and chapter directories.
import portrait0 from "@/assets/leadership/aba-friday-nwankwo.jpg.asset.json";
import portrait1 from "@/assets/leadership/abuja-samuel-osahon.jpg.asset.json";
import portrait2 from "@/assets/leadership/akobundu-ugah.jpg.asset.json";
import portrait3 from "@/assets/leadership/anambra-ifeanyi-akaeme.jpg.asset.json";
import portrait4 from "@/assets/leadership/benue-elisha-yesufu.jpg.asset.json";
import portrait5 from "@/assets/leadership/bola-ogunsanwo.jpg.asset.json";
import portrait6 from "@/assets/leadership/calabar-ekpenyong-ekpenyong.jpg.asset.json";
import portrait7 from "@/assets/leadership/dele-wickliffe.jpg.asset.json";
import portrait8 from "@/assets/leadership/ebonyi-monday-odoh.jpg.asset.json";
import portrait9 from "@/assets/leadership/emeka-ohaeri.jpg.asset.json";
import portrait10 from "@/assets/leadership/emmanuel-audu.jpg.asset.json";
import portrait11 from "@/assets/leadership/enugu-lazarus-ani.jpg.asset.json";
import portrait12 from "@/assets/leadership/friday-ekpety.jpg.asset.json";
import portrait13 from "@/assets/leadership/friday-eluwa.jpg.asset.json";
import portrait14 from "@/assets/leadership/ibadan-kayode-dosunmu.jpg.asset.json";
import portrait15 from "@/assets/leadership/ifaki-bankole-oso.jpg.asset.json";
import portrait16 from "@/assets/leadership/ifeanyi-okechukwu.jpg.asset.json";
import portrait17 from "@/assets/leadership/igbobini-oyewumi-akinmoju.jpg.asset.json";
import portrait18 from "@/assets/leadership/ikot-ekpene-idoreyin-umoh.jpg.asset.json";
import portrait19 from "@/assets/leadership/ilesa-adegbenga-adebusuyi.jpg.asset.json";
import portrait20 from "@/assets/leadership/inwon-fingesi.jpg.asset.json";
import portrait21 from "@/assets/leadership/kaduna-rasheed-oyeshola.jpg.asset.json";
import portrait22 from "@/assets/leadership/lagos-adetope-tychus.jpg.asset.json";
import portrait23 from "@/assets/leadership/lagos-mainland-ayorinde-thomas.jpg.asset.json";
import portrait24 from "@/assets/leadership/okigwe-monday-udeogu.jpg.asset.json";
import portrait25 from "@/assets/leadership/oron-esang-nsa-bassey.jpg.asset.json";
import portrait26 from "@/assets/leadership/portharcourt-steve-ogamba.jpg.asset.json";
import portrait27 from "@/assets/leadership/riye-niyi-olatidoye.jpg.asset.json";
import portrait28 from "@/assets/leadership/umoekoyo-essang.jpg.asset.json";
import portrait29 from "@/assets/leadership/umuahia-lucky-akabuike.jpg.asset.json";
import portrait30 from "@/assets/leadership/uyo-udoyiu-udoyiu.jpg.asset.json";
import portrait31 from "@/assets/leadership/victor-etefia.jpg.asset.json";

export const leadershipPortraits = {
  "aba-friday-nwankwo": portrait0.url,
  "abuja-samuel-osahon": portrait1.url,
  "akobundu-ugah": portrait2.url,
  "anambra-ifeanyi-akaeme": portrait3.url,
  "benue-elisha-yesufu": portrait4.url,
  "bola-ogunsanwo": portrait5.url,
  "calabar-ekpenyong-ekpenyong": portrait6.url,
  "dele-wickliffe": portrait7.url,
  "ebonyi-monday-odoh": portrait8.url,
  "emeka-ohaeri": portrait9.url,
  "emmanuel-audu": portrait10.url,
  "enugu-lazarus-ani": portrait11.url,
  "friday-ekpety": portrait12.url,
  "friday-eluwa": portrait13.url,
  "ibadan-kayode-dosunmu": portrait14.url,
  "ifaki-bankole-oso": portrait15.url,
  "ifeanyi-okechukwu": portrait16.url,
  "igbobini-oyewumi-akinmoju": portrait17.url,
  "ikot-ekpene-idoreyin-umoh": portrait18.url,
  "ilesa-adegbenga-adebusuyi": portrait19.url,
  "inwon-fingesi": portrait20.url,
  "kaduna-rasheed-oyeshola": portrait21.url,
  "lagos-adetope-tychus": portrait22.url,
  "lagos-mainland-ayorinde-thomas": portrait23.url,
  "okigwe-monday-udeogu": portrait24.url,
  "oron-esang-nsa-bassey": portrait25.url,
  "portharcourt-steve-ogamba": portrait26.url,
  "riye-niyi-olatidoye": portrait27.url,
  "umoekoyo-essang": portrait28.url,
  "umuahia-lucky-akabuike": portrait29.url,
  "uyo-udoyiu-udoyiu": portrait30.url,
  "victor-etefia": portrait31.url,
} as const;
