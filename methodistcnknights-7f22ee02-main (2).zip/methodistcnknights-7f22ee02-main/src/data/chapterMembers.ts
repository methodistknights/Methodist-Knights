import { leadershipPortraits as portraits } from "@/data/leadershipPortraits";
import { chapterPortraits } from "@/data/chapterPortraits";
// Lagos chapter
import adetopeTychusImg from "@/assets/members/lagos/adetope-tychus.png";

// Kaduna chapter
import kadunaOnojaImg from "@/assets/members/kaduna/onoja-innocent-idoko.jpg";
import kadunaMbanasorImg from "@/assets/members/kaduna/mbanasor-monday-nna.jpg";
import kadunaBosahImg from "@/assets/members/kaduna/bosah-oluremi.jpg";
import kadunaOzoemenaImg from "@/assets/members/kaduna/ozoemena-hyacinth-madu.jpg";
import kadunaAdegboyeImg from "@/assets/members/kaduna/adegboye-rufus.jpg";
import kadunaOshuntoyeImg from "@/assets/members/kaduna/oshuntoye-olukemi.jpg";
import kadunaOgunnakeImg from "@/assets/members/kaduna/ogunnake-adeniyi-rechard.jpg";
import kadunaOlaniyanImg from "@/assets/members/kaduna/olaniyan-akintayo-joseph.jpg";
import kadunaUcheImg from "@/assets/members/kaduna/uche-okorie-austine.jpg";
import kadunaEzeImg from "@/assets/members/kaduna/eze-chukwuemeka-simeon.jpg";
import kadunaOgwucheImg from "@/assets/members/kaduna/ogwuche-john.jpg";
import kadunaOgbukaImg from "@/assets/members/kaduna/ogbuka-obioha.jpg";
import kadunaOgileImg from "@/assets/members/kaduna/ogile-simeon.jpg";

// Calabar chapter
import ewaAldertonImg from "@/assets/members/calabar/ewa-alderton.jpg";
import basseyIquoImg from "@/assets/members/calabar/bassey-iquo.jpg";
import basseyOquaImg from "@/assets/members/calabar/bassey-oqua.jpg";
import estherEkanemImg from "@/assets/members/calabar/esther-ekanem.jpg";
import asangansiEffiongImg from "@/assets/members/calabar/asangansi-effiong.jpg";

// Umuahia chapter
import ukpabiJohnnyImg from "@/assets/members/umuahia/ukpabi-johnny.jpg";
import princeNkumeImg from "@/assets/members/umuahia/prince-nkume.jpg";
import mbaPaulChikezieImg from "@/assets/members/umuahia/mba-paul-chikezie.jpg";

// Ikot-Ekpene chapter
import idoreyinUmohImg from "@/assets/members/ikot-ekpene/idoreyin-umoh.jpg";
import bartepehGodfreyImg from "@/assets/members/ikot-ekpene/bartepeh-godfrey.jpg";
import essienDavidImg from "@/assets/members/ikot-ekpene/essien-david.jpg";
import ebongVictorImg from "@/assets/members/ikot-ekpene/ebong-victor.jpg";
import umoenangAkpanImg from "@/assets/members/ikot-ekpene/umoenang-akpan.jpg";
import umoessienAniekanImg from "@/assets/members/ikot-ekpene/umoessien-aniekan.jpg";
import usoroOkonImg from "@/assets/members/ikot-ekpene/usoro-okon.jpg";
import akpanEmmanuelImg from "@/assets/members/ikot-ekpene/akpan-emmanuel.jpg";
import akpabioUkemeImg from "@/assets/members/ikot-ekpene/akpabio-ukeme.jpg";
import udohIsaacImg from "@/assets/members/ikot-ekpene/udoh-isaac.jpg";
import usenEkereJamesImg from "@/assets/members/ikot-ekpene/usen-ekere-james.jpg";
import ekongUsoroImg from "@/assets/members/ikot-ekpene/ekong-usoro.jpg";
import essiettAniesuaImg from "@/assets/members/ikot-ekpene/essiett-aniesua.jpg";
import obongawanEtteteImg from "@/assets/members/ikot-ekpene/obongawan-ettete.jpg";
import usoroErnestImg from "@/assets/members/ikot-ekpene/usoro-ernest.jpg";
import ebongSamuelImg from "@/assets/members/ikot-ekpene/ebong-samuel.jpg";

// Ibadan chapter
import omofioyeOyedeleImg from "@/assets/members/ibadan/omofioye-oyedele.jpg";
import segunAjekiigbaImg from "@/assets/members/ibadan/segun-ajekiigba.jpg";
import akanbiEmmanuelImg from "@/assets/members/ibadan/akanbi-emmanuel.jpg";
import ajagbeKolawoleImg from "@/assets/members/ibadan/ajagbe-kolawole.jpg";
import animasaunJosephImg from "@/assets/members/ibadan/animasaun-joseph.jpg";
import jubaStellaImg from "@/assets/members/ibadan/juba-stella.jpg";
import olarenwajuAbiolaImg from "@/assets/members/ibadan/olarenwaju-abiola.jpg";
import egbewumiTaiwoImg from "@/assets/members/ibadan/egbewumi-taiwo.jpg";
import okunlolaOlusegunImg from "@/assets/members/ibadan/okunlola-olusegun.jpg";

// Igbobini chapter
import akinmojuIyewumiImg from "@/assets/members/igbobini/akinmoju-iyewumi.jpg";
import akinmojuMartinsImg from "@/assets/members/igbobini/akinmoju-martins.jpg";
import adelakunAyodejiImg from "@/assets/members/igbobini/adelakun-ayodeji.jpg";
import mesaganDeborahImg from "@/assets/members/igbobini/mesagan-deborah.jpg";
import omogoroyeIgbekeleImg from "@/assets/members/igbobini/omogoroye-igbekele.jpg";
import olakunleMosesImg from "@/assets/members/igbobini/olakunle-moses.jpg";
import falonaRufusImg from "@/assets/members/igbobini/falona-rufus.jpg";
import obideyiSamuelImg from "@/assets/members/igbobini/obideyi-samuel.jpg";
import arowoyeleRobertImg from "@/assets/members/igbobini/arowoyele-robert.jpg";
import adetuyiSamuelImg from "@/assets/members/igbobini/adetuyi-samuel.jpg";

// Ikot-Ekpene chapter (additional)
import akpanUdoKierianImg from "@/assets/members/ikot-ekpene/akpan-udo-kierian.jpg";

// Lagos Mainland chapter
import ayorindeThomasImg from "@/assets/members/ayorinde-thomas.jpg";

// Portharcourt chapter
import phOsungwuOnyemaechiImg from "@/assets/members/portharcourt/osungwu-onyemaechi.jpg";
import phPueneFinorKeamiabaridoImg from "@/assets/members/portharcourt/puene-finor-keamiabarido.jpg";
import phOtikorSamuelSandersonImg from "@/assets/members/portharcourt/otikor-samuel-sanderson.jpg";
import phSaagweBrightenImg from "@/assets/members/portharcourt/saagwe-brighten.jpg";
import phSmithKehindeOladapoImg from "@/assets/members/portharcourt/smith-kehinde-oladapo.jpg";
import phTorbiraLezaasiImg from "@/assets/members/portharcourt/torbira-lezaasi.jpg";
import phUdealaOlekaImg from "@/assets/members/portharcourt/udeala-oleka.jpg";
import phUdohElijahImg from "@/assets/members/portharcourt/udoh-elijah.jpg";
import phUgochukwuNgoziImg from "@/assets/members/portharcourt/ugochukwu-ngozi.jpg";
import phUkpeAkpanImg from "@/assets/members/portharcourt/ukpe-akpan.jpg";
import phUmorenUmorenImg from "@/assets/members/portharcourt/umoren-umoren.jpg";
import phUwagaUzoukwuNelsonImg from "@/assets/members/portharcourt/uwaga-uzoukwu-nelson.jpg";
import phUnoNdekhedeheImg from "@/assets/members/portharcourt/uno-ndekhedehe.jpg";
import phVincentMichaelImg from "@/assets/members/portharcourt/vincent-michael.jpg";
import phPrinceAikuImg from "@/assets/members/portharcourt/prince-aiku.jpg";
import phWickliffeBandeleImg from "@/assets/members/portharcourt/wickliffe-bandele.jpg";
import phAbalubuAbelTorueImg from "@/assets/members/portharcourt/abalubu-abel-torue.jpg";
import phAbiikorJacksonMoneyImg from "@/assets/members/portharcourt/abiikor-jackson-money.jpg";
import phAlattaNdubuisiImg from "@/assets/members/portharcourt/alatta-ndubuisi.jpg";
import phApenuTorkaImg from "@/assets/members/portharcourt/apenu-torka.jpg";
import phAttihEyoAsuquoImg from "@/assets/members/portharcourt/attih-eyo-asuquo.jpg";
import phBadomDugdaleKpoobariImg from "@/assets/members/portharcourt/badom-dugdale-kpoobari.jpg";
import phBiibalooLegborsiImg from "@/assets/members/portharcourt/biibaloo-legborsi.jpg";
import phChukwuJamesImg from "@/assets/members/portharcourt/chukwu-james.jpg";
import phCokerJimmyNathanielImg from "@/assets/members/portharcourt/coker-jimmy-nathaniel.jpg";
import phDadioweiAmaitariImg from "@/assets/members/portharcourt/dadiowei-amaitari.jpg";
import phDeekueSamuelNameneImg from "@/assets/members/portharcourt/deekue-samuel-namene.jpg";
import phDekoNyimaConfidenceImg from "@/assets/members/portharcourt/deko-nyima-confidence.jpg";
import phDekorDumnameneRobinsonImg from "@/assets/members/portharcourt/dekor-dumnamene-robinson.jpg";
import phDickTambariImg from "@/assets/members/portharcourt/dick-tambari.jpg";
import phErebaPreciousKpoobariImg from "@/assets/members/portharcourt/ereba-precious-kpoobari.jpg";
import phEkpoSamuelImg from "@/assets/members/portharcourt/ekpo-samuel.jpg";
import phEtukereNuadamImg from "@/assets/members/portharcourt/etukere-nuadam.jpg";
import phEzeNwachukwuImg from "@/assets/members/portharcourt/eze-nwachukwu.jpg";
import phEzeriChukwuemekaImg from "@/assets/members/portharcourt/ezeri-chukwuemeka.jpg";
import phFridayInyangEtiowoImg from "@/assets/members/portharcourt/friday-inyang-etiowo.jpg";
import phGaawaMosesImg from "@/assets/members/portharcourt/gaawa-moses.jpg";
import phGbafahLemabariImg from "@/assets/members/portharcourt/gbafah-lemabari.jpg";
import phGbarageLegyoImg from "@/assets/members/portharcourt/gbarage-legyo.jpg";
import phGbarenehLesiDikeImg from "@/assets/members/portharcourt/gbareneh-lesi-dike.jpg";
import phGborogbosiLesiGabrielImg from "@/assets/members/portharcourt/gborogbosi-lesi-gabriel.jpg";
import phGiadomLeaduSamuelImg from "@/assets/members/portharcourt/giadom-leadu-samuel.jpg";
import phIbangaEmmanuelImg from "@/assets/members/portharcourt/ibanga-emmanuel.jpg";
import phIderiahFelixJosephImg from "@/assets/members/portharcourt/ideriah-felix-joseph.jpg";
import phIheomaNelsonImg from "@/assets/members/portharcourt/iheoma-nelson.jpg";
import phImaMarshalImg from "@/assets/members/portharcourt/ima-marshal.jpg";
import phKanyoneGbaranenImg from "@/assets/members/portharcourt/kanyone-gbaranen.jpg";
import phJosephLebariDumImg from "@/assets/members/portharcourt/joseph-lebari-dum.jpg";
import phKokiManillaImg from "@/assets/members/portharcourt/koki-manilla.jpg";
import phKonyaRoselineImg from "@/assets/members/portharcourt/konya-roseline.jpg";
import phKponiBarinemTenaadeImg from "@/assets/members/portharcourt/kponi-barinem-tenaade.jpg";
import phLeviApollosImg from "@/assets/members/portharcourt/levi-apollos.jpg";
import phMadukaHenryImg from "@/assets/members/portharcourt/maduka-henry.jpg";
import phMonsiGbodeNubariImg from "@/assets/members/portharcourt/monsi-gbode-nubari.jpg";
import phNeneChineduImg from "@/assets/members/portharcourt/nene-chinedu.jpg";
import phNgborPrinceImg from "@/assets/members/portharcourt/ngbor-prince.jpg";
import phNjokuOnyekwereImg from "@/assets/members/portharcourt/njoku-onyekwere.jpg";
import phNkorPhilipImg from "@/assets/members/portharcourt/nkor-philip.jpg";
import phNwankpaOyeeImg from "@/assets/members/portharcourt/nwankpa-oyee.jpg";
import phNnahDumborImg from "@/assets/members/portharcourt/nnah-dumbor.jpg";
import phEzeNwankwoImg from "@/assets/members/portharcourt/eze-nwankwo.jpg";
import phNwidadahLegborsiImg from "@/assets/members/portharcourt/nwidadah-legborsi.jpg";
import phNwinangSaturdayBaridaImg from "@/assets/members/portharcourt/nwinang-saturday-barida.jpg";
import phNzideeAdebueWilliamsImg from "@/assets/members/portharcourt/nzidee-adebue-williams.jpg";
import phNwosuagwuPeterImg from "@/assets/members/portharcourt/nwosuagwu-peter.jpg";
import phNuniehGbeneJoiImg from "@/assets/members/portharcourt/nunieh-gbene-joi.jpg";
import phOfoelueNkemImg from "@/assets/members/portharcourt/ofoelue-nkem.jpg";
import phOgambaAdinduImg from "@/assets/members/portharcourt/ogamba-adindu.jpg";
import phOmunakweMilicentImg from "@/assets/members/portharcourt/omunakwe-milicent.jpg";
import phOkerekeChukwumaImg from "@/assets/members/portharcourt/okereke-chukwuma.jpg";
import phOgichenEmmanuelPowerImg from "@/assets/members/portharcourt/ogichen-emmanuel-power.jpg";
import phOnonogbuSunnyImg from "@/assets/members/portharcourt/ononogbu-sunny.jpg";
import phUwakweIkechukwuImg from "@/assets/members/portharcourt/uwakwe-ikechukwu.jpg";
import phEkpenyongOrokImg from "@/assets/members/portharcourt/ekpenyong-orok.jpg";

// Ifaki chapter
import ifakiAderintoThomasAdebowaleImg from "@/assets/members/ifaki/aderinto-thomas-adebowale.jpg";
import ifakiAleminuEmmanuelOlugbengaImg from "@/assets/members/ifaki/aleminu-emmanuel-olugbenga.jpg";
import ifakiAlukoEmmanuelOlukayodeImg from "@/assets/members/ifaki/aluko-emmanuel-olukayode.jpg";
import ifakiArogundadeChristianahOlayideImg from "@/assets/members/ifaki/arogundade-christianah-olayide.jpg";
import ifakiAsiwajuFakoredeComfortImg from "@/assets/members/ifaki/asiwaju-fakorede-comfort.jpg";
import ifakiBolumoleMopelolaAdenikeImg from "@/assets/members/ifaki/bolumole-mopelola-adenike.jpg";
import ifakiChiefAjibewaSamuelImg from "@/assets/members/ifaki/chief-ajibewa-samuel.jpg";
import ifakiChiefOfereAdekanyeOlotuImg from "@/assets/members/ifaki/chief-ofere-adekanye-olotu.jpg";
import ifakiChiefOjoGabrielAyodeleImg from "@/assets/members/ifaki/chief-ojo-gabriel-ayodele.jpg";
import ifakiChiefOjoJosephKayodeImg from "@/assets/members/ifaki/chief-ojo-joseph-kayode.jpg";
import ifakiChiefOlajideAyodeleImg from "@/assets/members/ifaki/chief-olajide-ayodele.jpg";
import ifakiChiefOniOlusegunImg from "@/assets/members/ifaki/chief-oni-olusegun.jpg";
import ifakiChiefOsanyinlusiOlasanmiImg from "@/assets/members/ifaki/chief-osanyinlusi-olasanmi.jpg";
import ifakiChiefOsoBankoleFolusoImg from "@/assets/members/ifaki/chief-oso-bankole-foluso.jpg";
import ifakiElderOjoMofifoluwasoImg from "@/assets/members/ifaki/elder-ojo-mofifoluwaso.jpg";
import ifakiEngrDrBabarinsaFolorunsoImg from "@/assets/members/ifaki/engr-dr-babarinsa-folorunso.jpg";
import ifakiEvangBabarinsaFlorenceImg from "@/assets/members/ifaki/evang-babarinsa-florence.jpg";
import ifakiFakoredeSamsonImg from "@/assets/members/ifaki/fakorede-samson.jpg";
import ifakiFalanaEmmanuelSundayImg from "@/assets/members/ifaki/falana-emmanuel-sunday.jpg";
import ifakiFolaBolumoleOlayinkaImg from "@/assets/members/ifaki/fola-bolumole-olayinka.jpg";
import ifakiGbadeolaAyodejiImg from "@/assets/members/ifaki/gbadeola-ayodeji.jpg";
import ifakiHonAwodumilaImg from "@/assets/members/ifaki/hon-awodumila.jpg";
import ifakiJolaiyaAbrahamAdemolaImg from "@/assets/members/ifaki/jolaiya-abraham-ademola.jpg";
import ifakiJuliusFemiOliyideImg from "@/assets/members/ifaki/julius-femi-oliyide.jpg";
import ifakiOgunshakinAdebisiOlubukunolaImg from "@/assets/members/ifaki/ogunshakin-adebisi-olubukunola.jpg";
import ifakiOguntanaAlfredTaiwoImg from "@/assets/members/ifaki/oguntana-alfred-taiwo.jpg";
import ifakiOjoAbiodunImg from "@/assets/members/ifaki/ojo-abiodun.jpg";
import ifakiOlaleyeGabrielOlusholaImg from "@/assets/members/ifaki/olaleye-gabriel-olushola.jpg";
import ifakiOlubummoAkinbodeImg from "@/assets/members/ifaki/olubummo-akinbode.jpg";
import ifakiOmoleAyodeleImg from "@/assets/members/ifaki/omole-ayodele.jpg";
import ifakiOriloyeSundayImg from "@/assets/members/ifaki/oriloye-sunday.jpg";
import ifakiOyatoyePeterKayodeImg from "@/assets/members/ifaki/oyatoye-peter-kayode.jpg";
import ifakiPrinceEsanLanreImg from "@/assets/members/ifaki/prince-esan-lanre.jpg";
import ifakiPrinceFasikuDavidOmolayoImg from "@/assets/members/ifaki/prince-fasiku-david-omolayo.jpg";
import ifakiStephenJohnImg from "@/assets/members/ifaki/stephen-john.jpg";

// Ilesha chapter
import ileshaAdeniyiDeborahIyabowaleApekeImg from "@/assets/members/ilesha/adeniyi-deborah-iyabowale-apeke.jpg";
import ileshaAdeniyiJohnsonObafemiImg from "@/assets/members/ilesha/adeniyi-johnson-obafemi.jpg";
import ileshaAkinbadeOlutayoImg from "@/assets/members/ilesha/akinbade-olutayo.jpg";
import ileshaAsaoluToyinAdetoreraFeliciaImg from "@/assets/members/ilesha/asaolu-toyin-adetorera-felicia.jpg";
import ileshaAwosuluEmmanuelImg from "@/assets/members/ilesha/awosulu-emmanuel.jpg";
import ileshaBabalolaOjoGbengaImg from "@/assets/members/ilesha/babalola-ojo-gbenga.jpg";
import ileshaChiefAbiodunStellaEbunImg from "@/assets/members/ilesha/chief-abiodun-stella-ebun.jpg";
import ileshaChiefAkinleyeIsaacImg from "@/assets/members/ilesha/chief-akinleye-isaac.jpg";
import ileshaChiefAlukoOlatundeIsholaImg from "@/assets/members/ilesha/chief-aluko-olatunde-ishola.jpg";
import ileshaChiefBolajiOlatundeImg from "@/assets/members/ilesha/chief-bolaji-olatunde.jpg";
import ileshaChiefDrFolamiAdeoyeFlorenceImg from "@/assets/members/ilesha/chief-dr-folami-adeoye-florence.jpg";
import ileshaDrOpakuleSundayImg from "@/assets/members/ilesha/dr-opakule-sunday.jpg";
import ileshaDrSaseunClementAderemiImg from "@/assets/members/ilesha/dr-saseun-clement-aderemi.jpg";
import ileshaEngrFarinreIsaacImg from "@/assets/members/ilesha/engr-farinre-isaac.jpg";
import ileshaEngrFashadeAdebayoImg from "@/assets/members/ilesha/engr-fashade-adebayo.jpg";
import ileshaEngrOlamijuloBenjaminOlasunkanmiImg from "@/assets/members/ilesha/engr-olamijulo-benjamin-olasunkanmi.jpg";
import ileshaEngrOlojoOlufemiImg from "@/assets/members/ilesha/engr-olojo-olufemi.jpg";
import ileshaEngrOniDavidImg from "@/assets/members/ilesha/engr-oni-david.jpg";
import ileshaEvangBabarinsaFlorenceTitilayoImg from "@/assets/members/ilesha/evang-babarinsa-florence-titilayo.jpg";
import ileshaFadahunsiOladipoImg from "@/assets/members/ilesha/fadahunsi-oladipo.jpg";
import ileshaFadairoGabrielImg from "@/assets/members/ilesha/fadairo-gabriel.jpg";
import ileshaFarodoyeOlubunmiImg from "@/assets/members/ilesha/farodoye-olubunmi.jpg";
import ileshaHonLongeOlaosebikanImg from "@/assets/members/ilesha/hon-longe-olaosebikan.jpg";
import ileshaMorakinyoFestusOlusujiImg from "@/assets/members/ilesha/morakinyo-festus-olusuji.jpg";
import ileshaObaleyeOlayinkaEuniceImg from "@/assets/members/ilesha/obaleye-olayinka-eunice.jpg";
import ileshaOluwadairoOlabanjoImg from "@/assets/members/ilesha/oluwadairo-olabanjo.jpg";
import ileshaOmoniyiRebeccaOlufunkeImg from "@/assets/members/ilesha/omoniyi-rebecca-olufunke.jpg";
import ileshaOniVictoriaOreoluwaImg from "@/assets/members/ilesha/oni-victoria-oreoluwa.jpg";
import ileshaOsedahunsiJamesAdemolaSundayImg from "@/assets/members/ilesha/osedahunsi-james-ademola-sunday.jpg";
import ileshaOsundareOreoluwaImg from "@/assets/members/ilesha/osundare-oreoluwa.jpg";
import ileshaOyedejiMaryModupeImg from "@/assets/members/ilesha/oyedeji-mary-modupe.jpg";
import ileshaProfBolajiOloyedeImg from "@/assets/members/ilesha/prof-bolaji-oloyede.jpg";
import ileshaProfOnayadeAdedejiImg from "@/assets/members/ilesha/prof-onayade-adedeji.jpg";



// Calabar chairman
import ekpenyongEkpenyongImg from "@/assets/members/calabar/ekpenyong-ekpenyong.jpg";

// Benue chairman
import elishaYesufuImg from "@/assets/members/benue/elisha-yesufu.jpg";

// Kaduna chapter

// Portharcourt chapter

// RIYE chapter
import riyeMaraiyesaJacobImg from "@/assets/members/riye/maraiyesa-jacob.jpg";
import riyeAdeitanAdeyemiImg from "@/assets/members/riye/adeitan-adeyemi-w.jpg";
import riyeOdedeleTitilolaImg from "@/assets/members/riye/odedele-titilola.jpg";
import riyeSoyewoFeyisayoImg from "@/assets/members/riye/soyewo-feyisayo.jpg";
import riyeJemiriMosesImg from "@/assets/members/riye/jemiri-moses-olusola.jpg";
import riyeDawoduEbunolaImg from "@/assets/members/riye/dawodu-ebunola.jpg";
import riyeOlugbemiOmololaImg from "@/assets/members/riye/olugbemi-omolola-olubukola.jpg";
import riyeOgunboOlumideImg from "@/assets/members/riye/ogunbo-olumide.jpg";
import riyeOyesolaOlujareImg from "@/assets/members/riye/chief-oyesola-olujare.jpg";
import riyeOyegunleMuftauImg from "@/assets/members/riye/oyegunle-muftau.jpg";
import riyeAtinmoFastolaImg from "@/assets/members/riye/atinmo-fastola.jpg";
import riyeOnaekoFolasadeImg from "@/assets/members/riye/onaeko-folasade.jpg";
import riyeEdunTaiwoImg from "@/assets/members/riye/edun-taiwo.jpg";
import riyeAshayeJosephineImg from "@/assets/members/riye/ashaye-josephine-olabisi.jpg";
import riyeOredipeAyotundeImg from "@/assets/members/riye/oredipe-ayotunde-gbenga.jpg";
import riyeOgunfoworaOlugboyegaImg from "@/assets/members/riye/ogunfowora-olugboyega.jpg";
import riyeShomoyeJosephImg from "@/assets/members/riye/shomoye-joseph-adelani.jpg";
import riyeSomoyeOlaleyeImg from "@/assets/members/riye/somoye-olaleye-adio.jpg";
import riyeJacobsCharlesImg from "@/assets/members/riye/jacobs-charles-oluremi.jpg";
import riyeSoyomboSosinmiImg from "@/assets/members/riye/soyombo-sosinmi-olajide.jpg";
import riyeOgungbeMojisolaImg from "@/assets/members/riye/ogungbe-mojisola-oluyemisi.jpg";
import riyeOgungbeSamuelImg from "@/assets/members/riye/ogungbe-samuel-olugbemi.jpg";
import riyeOgunsanwoAdebolaImg from "@/assets/members/riye/ogunsanwo-adebola.jpg";
import riyeSoyeboStevensonImg from "@/assets/members/riye/soyebo-stevenson-babatunde-olufemi.jpg";
import riyeOloriAdesanyaImg from "@/assets/members/riye/olori-adesanya-adefolaranmi-oludayo.jpg";
import riyeAdeluolaCharlesImg from "@/assets/members/riye/adeluola-charles-olalekan.jpg";
import riyeAdeseunFehintolaImg from "@/assets/members/riye/adeseun-fehintola-oluyemisi.jpg";
import riyeOshidekoFestusImg from "@/assets/members/riye/oshideko-festus-opeoluwa.jpg";
import riyeOdofuwaOlubunmiImg from "@/assets/members/riye/odofuwa-olubunmi.jpg";
import riyeSonoyaMichaelImg from "@/assets/members/riye/sonoya-michael-olusegun.jpg";
import riyeSolesiDavidImg from "@/assets/members/riye/solesi-david-kolawole.jpg";
import riyeShodaEmmaImg from "@/assets/members/riye/shoda-emma.jpg";
import riyeShituRichardImg from "@/assets/members/riye/shitu-richard-adeyemi.jpg";
import riyeOsinoikiKolaImg from "@/assets/members/riye/osinoiki-kola.jpg";
import riyeLegunsenMacaulayImg from "@/assets/members/riye/legunsen-macaulay.jpg";
import riyeSonoikiAlfredImg from "@/assets/members/riye/sonoiki-alfred-oladeji.jpg";
import riyeBanjokoOlufemiImg from "@/assets/members/riye/banjoko-olufemi-ademola.jpg";
import riyeBaiyewuSundayImg from "@/assets/members/riye/baiyewu-sunday.jpg";
import riyeSamsonAdekoyaImg from "@/assets/members/riye/samson-adekoya-abass.jpg";
import riyeOshinTitlayoImg from "@/assets/members/riye/oshin-titlayo.jpg";
import riyeSoyomboMosesImg from "@/assets/members/riye/soyombo-moses.jpg";
import riyeOgunyoluAlbertImg from "@/assets/members/riye/ogunyolu-albert.jpg";
import riyeLegunsenDorisImg from "@/assets/members/riye/legunsen-doris.jpg";
import riyeEpegaObarinsolaImg from "@/assets/members/riye/epega-obarinsola.jpg";
import riyeOdulateIyabodeImg from "@/assets/members/riye/odulate-iyabode.jpg";
import riyeSonaikeFestusImg from "@/assets/members/riye/sonaike-festus.jpg";
import riyeOlapadeOlatokunboImg from "@/assets/members/riye/olapade-olatokunbo.jpg";
import riyeAshayeAdekolaImg from "@/assets/members/riye/ashaye-adekola.jpg";


// Aba chapter
import abaUdezeJosephImg from "@/assets/members/aba/udeze-joseph.jpg";
import abaOkechukwuIfeanyiImg from "@/assets/members/aba/okechukwu-ifeanyi.jpg";
import abaAkomasIgbozuruikeImg from "@/assets/members/aba/akomas-igbozuruike.jpg";
import abaOnyeaborEmmanuelImg from "@/assets/members/aba/onyeabor-emmanuel-joseph.jpg";
import abaMbakweJosiahImg from "@/assets/members/aba/mbakwe-josiah-nzenwata.jpg";
import abaNwankwoJosephOkerekeImg from "@/assets/members/aba/nwankwo-joseph-okereke.jpg";
import abaAjugaJohnImg from "@/assets/members/aba/ajuga-john.jpg";
import abaAgboChristianFridayImg from "@/assets/members/aba/agbo-christian-friday.jpg";
import abaNwankwoOrjiImg from "@/assets/members/aba/nwankwo-orji.jpg";
import abaOjiOkechukwuImg from "@/assets/members/aba/oji-okechukwu.jpg";
import abaIhejirikaUchechukwuImg from "@/assets/members/aba/ihejirika-uchechukwu.jpg";
import abaNdukweJohnsonImg from "@/assets/members/aba/ndukwe-johnson.jpg";
import abaNmajuChinyereImg from "@/assets/members/aba/nmaju-chinyere.jpg";
import abaNmajuOnuohaEmeImg from "@/assets/members/aba/nmaju-onuoha-eme.jpg";
import abaOnyeachuJonathanImg from "@/assets/members/aba/onyeachu-jonathan.jpg";
import abaNnajiPaulImg from "@/assets/members/aba/nnaji-paul-chijioke.jpg";
import abaOnyeoziriMaxwellImg from "@/assets/members/aba/onyeoziri-maxwell.jpg";
import abaDameOkechukwuNgoziImg from "@/assets/members/aba/dame-okechukwu-ngozi.jpg";
import abaDameJohnAjugaNkechiImg from "@/assets/members/aba/dame-john-ajuga-nkechi.jpg";
import abaChukwuJamesImg from "@/assets/members/aba/chukwu-james.jpg";
import abaAnyaChukwuImg from "@/assets/members/aba/anya-chukwu.jpg";
import abaDimgbaChintuaImg from "@/assets/members/aba/dimgba-chintua-gladstone.jpg";
import abaMmamAgbaiImg from "@/assets/members/aba/mmam-agbai-ikechukwu.jpg";
import abaNjokuRichardImg from "@/assets/members/aba/njoku-richard.jpg";
import abaRobertEmenikeImg from "@/assets/members/aba/robert-emenike-okoji.jpg";
import abaNwabajiOgbonnayaImg from "@/assets/members/aba/nwabaji-ogbonnaya.jpg";
import abaChukwuSundayImg from "@/assets/members/aba/chukwu-sunday.jpg";
import abaAguJeremiahImg from "@/assets/members/aba/agu-jeremiah.jpg";
import abaOgbonnayaIheanyiImg from "@/assets/members/aba/ogbonnaya-iheanyichukwu.jpg";
import abaChukwuEmmanuelImg from "@/assets/members/aba/chukwu-emmanuel-a.jpg";
import abaObasiObiomaImg from "@/assets/members/aba/obasi-obioma-philip-iroegbu.jpg";
import abaUgahAkobunduImg from "@/assets/members/aba/ugah-akobundu-dike.jpg";
import abaOnyegbulaIsaiahImg from "@/assets/members/aba/onyegbula-isaiah-chibuwa.jpg";
import abaOmeruaRoseImg from "@/assets/members/aba/omerua-rose-adaugo.jpg";
import abaOsonduPaulineImg from "@/assets/members/aba/osondu-pauline-ulunma.jpg";
import abaOkoroUmekweImg from "@/assets/members/aba/okoro-umekwe-ukachukwu.jpg";
import abaHrhOgbonnaImg from "@/assets/members/aba/hrh-ogbonna-raphael-ukachi.jpg";
import abaKennethEbilahImg from "@/assets/members/aba/kenneth-ebilah.jpg";
import abaOnyekwereHopeImg from "@/assets/members/aba/onyekwere-hope.jpg";

// Uyo chapter
import uyoOlanrewajuAbiolaImg from "@/assets/members/uyo/olanrewaju-abiola-david.jpg";
import uyoUbomEdemImg from "@/assets/members/uyo/ubom-edem.jpg";
import uyoUsangaEtieseImg from "@/assets/members/uyo/usanga-etiese.jpg";
import uyoAkpabioKingsleyImg from "@/assets/members/uyo/akpabio-kingsley.jpg";
import uyoUmohJimmyImg from "@/assets/members/uyo/umoh-jimmy.jpg";
import uyoAtaiEdemImg from "@/assets/members/uyo/atai-edem.jpg";
import uyoEtokGeorgeImg from "@/assets/members/uyo/etok-george.jpg";
import uyoEyambaAliceImg from "@/assets/members/uyo/eyamba-alice.jpg";
import uyoUdosenOkonImg from "@/assets/members/uyo/udosen-okon.jpg";
import uyoNtahEdemImg from "@/assets/members/uyo/ntah-edem.jpg";
import uyoBasseySundayImg from "@/assets/members/uyo/bassey-sunday-asuquo.jpg";
import uyoEkanemJohnImg from "@/assets/members/uyo/ekanem-john.jpg";
import uyoUkonyangMichaelImg from "@/assets/members/uyo/ukonyang-michael.jpg";
import uyoEkpenyongChristopherImg from "@/assets/members/uyo/ekpenyong-christopher.jpg";
import uyoUdohEmmanuelImg from "@/assets/members/uyo/udoh-emmanuel.jpg";
import uyoDameEkanemImg from "@/assets/members/uyo/dame-ekanem.jpg";
import uyoHarryJohnImg from "@/assets/members/uyo/harry-john.jpg";
import uyoUkpeIdongesitImg from "@/assets/members/uyo/ukpe-idongesit.jpg";
import uyoOkorieChibuzorImg from "@/assets/members/uyo/okorie-chibuzor.jpg";
import uyoEssienUwemedimohImg from "@/assets/members/uyo/essien-uwemedimoh.jpg";
import uyoEtukafiaNseabasiImg from "@/assets/members/uyo/etukafia-nseabasi.jpg";
import uyoEssiettAniesuaImg from "@/assets/members/uyo/essiett-aniesua.jpg";
import uyoUdofiaIfureuwemImg from "@/assets/members/uyo/udofia-ifureuwem.jpg";
import uyoInyangAkpanIdioImg from "@/assets/members/uyo/inyang-akpan-idio.jpg";

// Okigwe chapter
import okigweUdeoguMondayImg from "@/assets/members/okigwe/udeogu-monday.jpg";
import okigweObiFrancisImg from "@/assets/members/okigwe/obi-francis-chijioke.jpg";
import okigweIroesogbusiAbelImg from "@/assets/members/okigwe/iroesogbusi-abel.jpg";
import okigweNwokeEmmanuelImg from "@/assets/members/okigwe/nwoke-emmanuel.jpg";
import okigweOnyeaboReubenImg from "@/assets/members/okigwe/onyeabo-reuben.jpg";
import okigweMbaSundayImg from "@/assets/members/okigwe/mba-sunday-nwachukwu.jpg";
import okigweOdoemelemChinedumImg from "@/assets/members/okigwe/odoemelem-chinedum.jpg";
import okigweUcheAlbertImg from "@/assets/members/okigwe/uche-albert.jpg";
import okigweKanuChidiebereImg from "@/assets/members/okigwe/kanu-chidiebere.jpg";
import okigweEkeStanleyImg from "@/assets/members/okigwe/eke-stanley.jpg";
import okigweAguChibuezeImg from "@/assets/members/okigwe/agu-chibueze.jpg";
import okigweNwokoroEbereImg from "@/assets/members/okigwe/nwokoro-ebere.jpg";
import okigweNdubuisiUkachukwuImg from "@/assets/members/okigwe/ndubuisi-ukachukwu.jpg";
import okigweIbeajaEzeSundayImg from "@/assets/members/okigwe/ibeaja-eze-sunday.jpg";
import okigweObigweOkwudiriImg from "@/assets/members/okigwe/obigwe-okwudiri.jpg";
import okigweChibuezehLinusImg from "@/assets/members/okigwe/chibuezeh-linus.jpg";
import okigweIkpoUcheImg from "@/assets/members/okigwe/ikpo-uche.jpg";
import okigweOnyechereUchechukwuImg from "@/assets/members/okigwe/onyechere-uchechukwu.jpg";
import okigweAsiegbuHenryImg from "@/assets/members/okigwe/asiegbu-henry.jpg";
import okigweObiakaEzinwaImg from "@/assets/members/okigwe/obiaka-ezinwa-aaron.jpg";
import okigweEzeEugeneImg from "@/assets/members/okigwe/eze-eugene.jpg";
import okigweObijiakuGoddyImg from "@/assets/members/okigwe/obijiaku-goddy.jpg";
import okigweOnyearughaIkemefuleImg from "@/assets/members/okigwe/onyearugha-ikemefule.jpg";
import okigweOnyearughaIhuomaImg from "@/assets/members/okigwe/onyearugha-ihuoma.jpg";
import okigweEmeAmarachukwuImg from "@/assets/members/okigwe/eme-amarachukwu.jpg";
import okigweOfoegbuKennethImg from "@/assets/members/okigwe/ofoegbu-kenneth.jpg";
import okigweUgwaDennisImg from "@/assets/members/okigwe/ugwa-dennis.jpg";
import okigweIhereGodwinImg from "@/assets/members/okigwe/ihere-godwin.jpg";
import okigweAjalaVincentImg from "@/assets/members/okigwe/ajala-vincent.jpg";
import okigweOnwuchekwaGodswillImg from "@/assets/members/okigwe/onwuchekwa-godswill.jpg";
import okigweOjukwuErnestImg from "@/assets/members/okigwe/ojukwu-ernest.jpg";
import okigweOyoroNdubuisiImg from "@/assets/members/okigwe/oyoro-ndubuisi.jpg";
import okigweUkejeCharlesImg from "@/assets/members/okigwe/ukeje-charles.jpg";
import okigweEzeIkwulaguImg from "@/assets/members/okigwe/eze-ikwulagu.jpg";
import okigweChijiChibuikeImg from "@/assets/members/okigwe/chiji-chibuike.jpg";
import okigweUwaezuokeAmobiImg from "@/assets/members/okigwe/uwaezuoke-amobi.jpg";
import okigweNgwuChukwuemekaImg from "@/assets/members/okigwe/ngwu-chukwuemeka.jpg";

// Enugu chapter member images
import enuguElomJohnOkabeImg from "@/assets/members/enugu/elom-john-okabe.jpg";
import enuguAniaguDavidNgeneImg from "@/assets/members/enugu/aniagu-david-ngene.jpg";
import enuguNwobodoAbelOgbonnayaImg from "@/assets/members/enugu/nwobodo-abel-ogbonnaya.jpg";
import enuguOnyebuchiAzubuikeKanarioImg from "@/assets/members/enugu/onyebuchi-azubuike-kanario.jpg";
import enuguUcheJamesIfunanyaChukwuImg from "@/assets/members/enugu/uche-james-ifunanya-chukwu.jpg";
import enuguNnamaniChinenyePatriciaImg from "@/assets/members/enugu/nnamani-chinenye-patricia.jpg";
import enuguOkorieCharlesImg from "@/assets/members/enugu/okorie-charles.jpg";
import enuguAgboVictorOguejiofoImg from "@/assets/members/enugu/agbo-victor-oguejiofo.jpg";
import enuguAvahStephenImg from "@/assets/members/enugu/avah-stephen.jpg";
import enuguNwodoOnuImg from "@/assets/members/enugu/nwodo-onu.jpg";
import enuguAtuonwuNnannaVictorImg from "@/assets/members/enugu/atuonwu-nnanna-victor.jpg";
import enuguEdeOkaforImg from "@/assets/members/enugu/ede-okafor.jpg";
import enuguEzumahHumphreyImg from "@/assets/members/enugu/ezumah-humphrey.jpg";
import enuguAgwuEmekaEzekielImg from "@/assets/members/enugu/agwu-emeka-ezekiel.jpg";
import enuguOgbonnaChinonyeremJoeImg from "@/assets/members/enugu/ogbonna-chinonyerem-joe.jpg";
import enuguEjimsDiewaitOkechukwuImg from "@/assets/members/enugu/ejims-diewait-okechukwu.jpg";
import enuguOgbodoDonatusOkekeImg from "@/assets/members/enugu/ogbodo-donatus-okeke.jpg";
import enuguChukwuemerieEmmanuelIkechukwuImg from "@/assets/members/enugu/chukwuemerie-emmanuel-ikechukwu.jpg";
import enuguOselebeEzeImg from "@/assets/members/enugu/oselebe-eze.jpg";
import enuguAninweneEmmanuelOdionyenfeImg from "@/assets/members/enugu/aninwene-emmanuel-odionyenfe.jpg";
import enuguNwauloOnyekachiPromiseImg from "@/assets/members/enugu/nwaulo-onyekachi-promise.jpg";
import enuguOnuVincentUcheImg from "@/assets/members/enugu/onu-vincent-uche.jpg";
import enuguNwatuGodwinImg from "@/assets/members/enugu/nwatu-godwin.jpg";
import enuguAgboEmmanuelImg from "@/assets/members/enugu/agbo-emmanuel.jpg";
import enuguMbaDouglasIfeanyiImg from "@/assets/members/enugu/mba-douglas-ifeanyi.jpg";
import enuguOnahIkechukwuImg from "@/assets/members/enugu/onah-ikechukwu.jpg";
import enuguOnohJohnImg from "@/assets/members/enugu/onoh-john.jpg";
import enuguUbaObasikweNgozichukwuImg from "@/assets/members/enugu/uba-obasikwe-ngozichukwu.jpg";
import enuguOnweChukwukaImg from "@/assets/members/enugu/onwe-chukwuka.jpg";
import enuguOgbonnachukwuObiKennethImg from "@/assets/members/enugu/ogbonnachukwu-obi-kenneth.jpg";
import enuguAsiegbuUzoechiWillingtonImg from "@/assets/members/enugu/asiegbu-uzoechi-willington.jpg";
import enuguIkpegbuSundayOkechukwuImg from "@/assets/members/enugu/ikpegbu-sunday-okechukwu.jpg";
import enuguOkpehSundayImg from "@/assets/members/enugu/okpeh-sunday.jpg";
import enuguOkenwaAniAnthonyChukwukaImg from "@/assets/members/enugu/okenwa-ani-anthony-chukwuka.jpg";
import enuguOhaaChinyeakaImg from "@/assets/members/enugu/ohaa-chinyeaka.jpg";
import enuguNwabuezeAmechiAgahImg from "@/assets/members/enugu/nwabueze-amechi-agah.jpg";
import enuguMbadughaEkwebellemNwankwoImg from "@/assets/members/enugu/mbadugha-ekwebellem-nwankwo.jpg";
import enuguNwaforGodwinOkechukwuImg from "@/assets/members/enugu/nwafor-godwin-okechukwu.jpg";
import enuguEgboOguejiImg from "@/assets/members/enugu/egbo-ogueji.jpg";
import enuguAkaemeIfeanyiChristianImg from "@/assets/members/enugu/akaeme-ifeanyi-christian.jpg";
import enuguOruruoIfeomaImg from "@/assets/members/enugu/oruruo-ifeoma.jpg";
import enuguOsitaHumphreyImg from "@/assets/members/enugu/osita-humphrey.jpg";
import enuguNwokochaDicksonImg from "@/assets/members/enugu/nwokocha-dickson.jpg";
import enuguAniEmmanuelImg from "@/assets/members/enugu/ani-emmanuel.jpg";
import enuguNnamchiFidelisOgbuImg from "@/assets/members/enugu/nnamchi-fidelis-ogbu.jpg";
import enuguUkoroOnyemaechiBonifaceImg from "@/assets/members/enugu/ukoro-onyemaechi-boniface.jpg";
import enuguChukwukeziriUgogbuzuoMelfordEliasImg from "@/assets/members/enugu/chukwukeziri-ugogbuzuo-melford-elias.jpg";
import enuguUgwuodoJosephOkonkwoImg from "@/assets/members/enugu/ugwuodo-joseph-okonkwo.jpg";
import enuguOgbonnaEdwinImg from "@/assets/members/enugu/ogbonna-edwin.jpg";
import enuguNnejiJohnImg from "@/assets/members/enugu/nneji-john.jpg";
import enuguAnyaJosephIdikaImg from "@/assets/members/enugu/anya-joseph-idika.jpg";
import enuguNnamaniSampsonChikwenduImg from "@/assets/members/enugu/nnamani-sampson-chikwendu.jpg";
import enuguEzohEzonuOgbajieImg from "@/assets/members/enugu/ezoh-ezonu-ogbajie.jpg";
import enuguNnamaniNwabuezeImg from "@/assets/members/enugu/nnamani-nwabueze.jpg";
import enuguOgbodoDavidImg from "@/assets/members/enugu/ogbodo-david.jpg";




export interface ChapterMember {
  name: string;
  birthday: string;
  position?: string;
  award: "KJW" | "KCW";
  phone: string;
  whatsapp?: string;
  image?: string;
}

export interface ChapterData {
  name: string;
  members: ChapterMember[];
}

export const chapterMembersData: Record<string, ChapterData> = {
  abuja: {
    name: "Abuja",
    members: [
      { name: "SIR OSAHON SAMUEL OSAWARU", birthday: "12th December", award: "KJW", phone: "08035904137", position: "Chapter Chairman", image: portraits["abuja-samuel-osahon"] },
      { name: "SIR AUDU EMMANUEL SUNDAY", birthday: "9th September", award: "KJW", phone: "08033914467", image: "/images/abuja/member_2.jpg" },
      { name: "SIR BARR. EKPETY FRIDAY", birthday: "28th August", award: "KJW", phone: "08023131366", image: "/images/abuja/member_3.jpg" },
      { name: "SIR ESA ATTAH STEPHEN", birthday: "1st March", award: "KJW", phone: "08065749676", image: "/images/abuja/member_4.jpg" },
      { name: "DAME EMOEFE GRACE", birthday: "10th October", award: "KJW", phone: "08034502239", image: "/images/abuja/member_5.jpg" },
      { name: "SIR OKOIBU ANIEFON NYA", birthday: "23rd February", award: "KCW", phone: "08027839680", image: "/images/abuja/member_6.jpg" },
      { name: "SIR ALAGBAOSO KELECHI", birthday: "29th May", award: "KCW", phone: "08036020420", image: "/images/abuja/member_7.jpg" },
      { name: "SIR PROF. EKERENDU EDET", birthday: "7th June", award: "KJW", phone: "08033145232", image: "/images/abuja/member_8.jpg" },
      { name: "SIR OJI NWABUEZE", birthday: "9th January", award: "KJW", phone: "08034086804", image: "/images/abuja/member_9.jpg" },
      { name: "SIR OYEWANDE BOYE", birthday: "9th June", award: "KJW", phone: "08035967000", image: "/images/abuja/member_10.jpg" },
      { name: "SIR UGOCHUKWU ONYEMA", birthday: "9th November", award: "KJW", phone: "08034070064", image: "/images/abuja/member_11.jpg" },
      { name: "DAME KATE OKON", birthday: "25th November", award: "KJW", phone: "08033499751", image: "/images/abuja/member_12.jpg" },
      { name: "SIR ELENDU COLLINS", birthday: "11th January", award: "KJW", phone: "09072360408", image: "/images/abuja/member_13.jpg" },
      { name: "SIR ONYEDIKA MGBEOKWERE", birthday: "14th October", award: "KJW", phone: "08064922370", image: "/images/abuja/member_14.jpg" },
      { name: "SIR (AVM) KAYODE-BECKLEY JOHN ADENIYI", birthday: "30th April", award: "KJW", phone: "08175397548", whatsapp: "08059970810", image: "/images/abuja/member_15.jpg" },
      { name: "SIR OBEKPA OGBOJI JOSEPH", birthday: "12th April", award: "KJW", phone: "08033038023", image: "/images/abuja/member_16.jpg" },
      { name: "DAME ONYEBUCHI CHISARA", birthday: "27th November", award: "KJW", phone: "07088809352", image: "/images/abuja/member_17.jpg" },
      { name: "SIR ROBERTS OLUWAGBENGA EDWARD", birthday: "21st March", award: "KCW", phone: "08067586632", whatsapp: "08189205611", image: "/images/abuja/member_18.jpg" },
      { name: "SIR TIKOLO DUROJAIYEOLA", birthday: "11th January", award: "KJW", phone: "0809088322", image: "/images/abuja/member_19.jpg" },
      { name: "SIR ENEJO JONAH", birthday: "1st August", award: "KJW", phone: "08052282188", image: "/images/abuja/member_20.jpg" },
      { name: "SIR ODUYOYE OLA JACOB", birthday: "30th August", award: "KJW", phone: "08035675504", image: "/images/abuja/member_21.jpg" },
      { name: "SIR USEH UWEM", birthday: "22nd January", award: "KCW", phone: "08065714457", image: "/images/abuja/member_22.jpg" },
      { name: "DAME MOMOH OGHENE OCHUKO EILEEN", birthday: "18th August", award: "KJW", phone: "08033092914", image: "/images/abuja/member_23.jpg" },
      { name: "SIR DR. OGENYI OCHAPA", birthday: "21st July", award: "KJW", phone: "08035898498", image: "/images/abuja/member_24.jpg" },
      { name: "SIR SAMUEL OGBONNA EZELU", birthday: "15th October", award: "KJW", phone: "08033495538", image: "/images/abuja/member_25.jpg" },
      { name: "SIR OPOOSUN KAYODE", birthday: "16th September", award: "KJW", phone: "08033142975", image: "/images/abuja/member_26.jpg" },
      { name: "SIR DR. AGOMOH CHUKWUMA CHRISTIAN", birthday: "17th July", award: "KJW", phone: "08033311969", image: "/images/abuja/member_27.jpg" },
      { name: "DAME USMAN YEWANDE", birthday: "17th October", award: "KJW", phone: "08022920788", image: "/images/abuja/member_28.jpg" },
      { name: "SIR NWAFOR SUNDAY", birthday: "25th July", award: "KJW", phone: "08173300071", image: "/images/abuja/member_29.jpg" },
      { name: "SIR DR. AUBEE ERNEST", birthday: "10th August", award: "KJW", phone: "08062863719", image: "/images/abuja/member_30.jpg" },
      { name: "SIR NATHANIEL MODUPE LONGE", birthday: "17th February", award: "KJW", phone: "08033119311", image: "/images/abuja/member_31.jpg" },
      { name: "SIR CHUKWUDI SAMUEL AGWU", birthday: "3rd June", award: "KJW", phone: "08037862245", image: "/images/abuja/member_32.jpg" },
      { name: "DAME EUNICE ICHIKO OJOWU", birthday: "11th November", award: "KJW", phone: "08037021528", image: "/images/abuja/member_33.jpg" },
      { name: "DAME DR. JULIANA OLUFUNKE LAWSON", birthday: "1st July", award: "KJW", phone: "08033153339", image: "/images/abuja/member_34.jpg" },
      { name: "DAME ZUWAIRA BECKLEY", birthday: "24th May", award: "KJW", phone: "08033498105", image: "/images/abuja/member_35.jpg" },
      { name: "SIR ONWUKA UGOCHUKWU", birthday: "11th September", award: "KJW", phone: "08034769157", image: "/images/abuja/member_36.jpg" },
      { name: "SIR MADEIN ADELEKE", birthday: "24th June", award: "KJW", phone: "0823223642", image: "/images/abuja/member_37.jpg" },
      { name: "SIR SUNDAY EMMANUEL", birthday: "1st January", award: "KJW", phone: "08036153849", image: "/images/abuja/member_38.jpg" },
      { name: "SIR AWOJOBI AWOSOJI", birthday: "9th December", award: "KJW", phone: "08033335917", image: "/images/abuja/member_39.jpg" },
      { name: "SIR PETERS GBENGA", birthday: "7th January", award: "KJW", phone: "08033039280", image: "/images/abuja/member_40.jpg" },
      { name: "SIR AMASI OKON", birthday: "5th July", award: "KJW", phone: "08035858585", image: "/images/abuja/member_41.jpg" },
      { name: "SIR BARR. ORJI NELSON OKORONKWO", birthday: "15th January", award: "KJW", phone: "08037236997", image: "/images/abuja/member_42.jpg" },
      { name: "SIR JUSTICE ONNOGHEN WALTER SAMUEL NKANU", birthday: "22nd December", award: "KJW", phone: "08034743023", image: "/images/abuja/member_43.jpg" },
      { name: "DAME FADAIRO ESTHER ADEBAYO", birthday: "27th July", award: "KJW", phone: "08064320520", image: "/images/abuja/member_44.jpg" },
      { name: "DAME ADUWO KOFOWOROLA", birthday: "7th March", award: "KJW", phone: "07039031222", image: "/images/abuja/member_45.jpg" },
      { name: "SIR EFFIONG USEN", birthday: "24th March", award: "KJW", phone: "08033121038", image: "/images/abuja/member_46.jpg" },
      { name: "SIR OHAERI OSONDU JOSEPH", birthday: "3rd March", award: "KJW", phone: "08036792173", image: "/images/abuja/member_47.jpg" },
      { name: "SIR OFIE ADAMS SUNDAY", birthday: "12th August", award: "KJW", phone: "08035925684", image: "/images/abuja/member_48.jpg" },
      { name: "SIR AGWU JOHN PRECIOUS", birthday: "15th May", award: "KJW", phone: "07035443327", image: "/images/abuja/member_49.jpg" },
    ],
  },
  uyo: {
    name: "Uyo",
    members: [
      { name: "SIR UDOYIU UDOYIU", birthday: "9th September, 1968", award: "KJW", phone: "08033733963", position: "Chapter Chairman", image: portraits["uyo-udoyiu-udoyiu"] },
      { name: "SIR (HON. JUSTICE) ESSANG UMOEKOYO", birthday: "15th October, 1949", award: "KJW", phone: "08130080935" },
      { name: "SIR ENGR. OLANREWAJU ABIOLA DAVID", birthday: "", award: "KJW", phone: "", image: uyoOlanrewajuAbiolaImg },
      { name: "SIR UBOM EDEM", birthday: "25th June, 1942", award: "KJW", phone: "08035068519", image: uyoUbomEdemImg },
      { name: "SIR AKPABIO KINGSLEY ESSIEN", birthday: "", award: "KJW", phone: "08037070520", image: uyoAkpabioKingsleyImg },
      { name: "SIR UMOH JIMMY", birthday: "20th May, 1944", award: "KJW", phone: "08023521439", image: uyoUmohJimmyImg },
      { name: "SIR ATAI EDEM", birthday: "August, 1949", award: "KJW", phone: "08131269333", image: uyoAtaiEdemImg },
      { name: "SIR USANGA ETIESE", birthday: "12th November, 1949", award: "KCW", phone: "08061316655", image: uyoUsangaEtieseImg },
      { name: "SIR EYAMBA ALICE", birthday: "11th November, 1950", award: "KJW", phone: "08023744090", image: uyoEyambaAliceImg },
      { name: "SIR ETOK GEORGE", birthday: "22nd June, 1952", award: "KCW", phone: "08023632363", image: uyoEtokGeorgeImg },
      { name: "SIR UDOSEN OKON", birthday: "30th June, 1953", award: "KCW", phone: "08065645840", image: uyoUdosenOkonImg },
      { name: "SIR NTAH EDEM", birthday: "21st November, 1955", award: "KJW", phone: "08025746423", image: uyoNtahEdemImg },
      { name: "SIR BASSEY SUNDAY ASUQUO", birthday: "1st January, 1957", award: "KJW", phone: "08028775312", image: uyoBasseySundayImg },
      { name: "SIR EKANEM JOHN", birthday: "11th November, 1957", award: "KJW", phone: "07063275327", image: uyoEkanemJohnImg },
      { name: "SIR UDOH EMMANUEL", birthday: "9th March, 1958", award: "KJW", phone: "08023624566", image: uyoUdohEmmanuelImg },
      { name: "DAME EKANEM", birthday: "3rd March, 1961", award: "KJW", phone: "08120743796", image: uyoDameEkanemImg },
      { name: "SIR UKONYANG MICHAEL", birthday: "8th December, 1964", award: "KCW", phone: "07081213412", image: uyoUkonyangMichaelImg },
      { name: "SIR EKPENYONG CHRISTOPHER", birthday: "27th March, 1967", award: "KJW", phone: "08023347719", image: uyoEkpenyongChristopherImg },
      { name: "SIR IKE FLORENCE", birthday: "26th April, 1969", award: "KJW", phone: "08020568938" },
      { name: "SIR HARRY JOHN", birthday: "2nd June, 1970", award: "KJW", phone: "08023109947", image: uyoHarryJohnImg },
      { name: "SIR UKPE IDONGESIT", birthday: "2nd July, 1970", award: "KJW", phone: "08027404227", image: uyoUkpeIdongesitImg },
      { name: "SIR OKORIE CHIBUZOR BENJAMIN", birthday: "1972", award: "KJW", phone: "08023101253", image: uyoOkorieChibuzorImg },
      { name: "SIR ESSIEN UWEMEDIMOH", birthday: "8th January, 1991", award: "KCW", phone: "07082439316", image: uyoEssienUwemedimohImg },
      { name: "SIR DR. ETUKAFIA NSEABASI", birthday: "1st September, 1962", award: "KJW", phone: "08035529461", image: uyoEtukafiaNseabasiImg },
      { name: "SIR PROF. ESSIETT ANIESUA", birthday: "29th July, 1963", award: "KJW", phone: "08068400039", image: uyoEssiettAniesuaImg },
      { name: "SIR UDOFIA IFUREUWEM", birthday: "23rd April, 1963", award: "KJW", phone: "08032623024", image: uyoUdofiaIfureuwemImg },
      { name: "SIR INYANG AKPAN IDIO", birthday: "2nd July, 1951", award: "KJW", phone: "08163871178", image: uyoInyangAkpanIdioImg },

    ],
  },
  aba: {
    name: "Aba",
    members: [
      { name: "SIR NWANKWO FRIDAY EJIKEME", birthday: "31st August, 1956", award: "KJW", phone: "08037822821", position: "Chapter Chairman", image: portraits["aba-friday-nwankwo"] },
      { name: "SIR EKE SUNDAY OKOROAFOR", birthday: "30th October, 1950", award: "KJW", phone: "08057151520" },
      { name: "SIR OKORO JACOB", birthday: "1951", award: "KJW", phone: "08037058194" },
      { name: "SIR ONYEMA EMENIKE", birthday: "17th July, 1964", award: "KJW", phone: "08064363799" },
      { name: "DAME OGELLE NGOZI", birthday: "22nd March, 1949", award: "KJW", phone: "08109631117" },
      { name: "DAME IKEADIGH CHRISTIANA AMARACHI", birthday: "24th January, 1952", award: "KCW", phone: "08064866682" },
      { name: "SIR CHIEF UDEAGU IKECHUKWU MADUKA, JP", birthday: "10th February, 1956", award: "KJW", phone: "08033278890" },
      { name: "SIR ANIH SILVANUS", birthday: "13th September, 1958", award: "KJW", phone: "08036714433" },
      { name: "SIR OKON NKEREFI", birthday: "22nd May, 1968", award: "KJW", phone: "08034096639" },
      { name: "DAME DAVID MONICA N.", birthday: "4th May, 1971", award: "KJW", phone: "08033190542" },
      { name: "SIR OSOKA NDUKA", birthday: "16th May, 1975", award: "KJW", phone: "08037736025" },
      { name: "SIR OKORIE ONYEMAECHI", birthday: "10th March, 1970", award: "KJW", phone: "08033307282" },
      { name: "MADUKA UWAKWE", birthday: "30th July, 1961", award: "KJW", phone: "08033100133" },
      { name: "SIR AKAERUE CHRISTIAN IRODI", birthday: "5th May, 1959", award: "KJW", phone: "08034955276" },
      { name: "SIR EZIOKWU MOSES", birthday: "5th January, 1955", award: "KJW", phone: "08036473929" },
      { name: "SIR ISHEGH-NOR ORJE", birthday: "19th April, 1961", award: "KJW", phone: "08033415194" },
      { name: "DAME NKULO UZOMA UGONMA", birthday: "22nd August, 1977", award: "KCW", phone: "08036485285" },
      { name: "DAME DUROHA-IGWE FLORENCE IKWUOMA", birthday: "20th May, 1953", award: "KJW", phone: "08033257867" },
      { name: "SIR NWANKENTA AZUBUIKE EMMANUEL", birthday: "24th August, 1978", award: "KJW", phone: "08037963710" },
      { name: "SIR UDEOGU JOSEPH AKARUSI", birthday: "9th January, 1935", award: "KCW", phone: "08033912453" },
      { name: "SIR IJIOMA CHUKWUEMEKA IBEGBU", birthday: "23rd February, 1948", award: "KJW", phone: "08039722884" },
      { name: "SIR NDUKWE EMMANUEL ONUOHA", birthday: "24th November, 1956", award: "KJW", phone: "08033745910" },
      { name: "SIR UDEZE JOSEPH", birthday: "1st July, 1949", award: "KJW", phone: "08036715343", image: abaUdezeJosephImg },
      { name: "SIR OKECHUKWU IFEANYI", birthday: "18th June, 1962", award: "KJW", phone: "08035501797", image: abaOkechukwuIfeanyiImg },
      { name: "SIR AKOMAS IGBOZURUIKE NGBOROGWU", birthday: "14th September, 1942", award: "KJW", phone: "08036677645", image: abaAkomasIgbozuruikeImg },
      { name: "SIR ONYEABOR EMMANUEL JOSEPH", birthday: "8th July, 1957", award: "KCW", phone: "08033290566", image: abaOnyeaborEmmanuelImg },
      { name: "SIR MBAKWE JOSIAH NZENWATA", birthday: "16th November, 1942", award: "KCW", phone: "08037510009", image: abaMbakweJosiahImg },
      { name: "SIR NWANKWO JOSEPH OKEREKE", birthday: "27th May, 1946", award: "KJW", phone: "08055671921", image: abaNwankwoJosephOkerekeImg },
      { name: "SIR AJUGA JOHN", birthday: "20th August, 1962", award: "KJW", phone: "08033165557", image: abaAjugaJohnImg },
      { name: "SIR AGBO CHRISTIAN FRIDAY", birthday: "8th August, 1963", award: "KJW", phone: "08033150724", image: abaAgboChristianFridayImg },
      { name: "SIR NWANKWO ORJI", birthday: "9th November, 1956", award: "KJW", phone: "08080826181", image: abaNwankwoOrjiImg },
      { name: "SIR OJI OKECHUKWU", birthday: "24th August, 1952", award: "KJW", phone: "08097891428", image: abaOjiOkechukwuImg },
      { name: "SIR IHEJIRIKA UCHECHUKWU NWACHUKWU", birthday: "28th March, 1957", award: "KJW", phone: "08037046621", image: abaIhejirikaUchechukwuImg },
      { name: "SIR NDUKWE JOHNSON", birthday: "13th May, 1959", award: "KJW", phone: "08033767895", image: abaNdukweJohnsonImg },
      { name: "SIR (CHIEF, BARR.) NMAJU CHINYERE", birthday: "3rd January, 1950", award: "KJW", phone: "08036702925", image: abaNmajuChinyereImg },
      { name: "SIR NMAJU ONUOHA EME", birthday: "4th April, 1952", award: "KJW", phone: "07065167782", image: abaNmajuOnuohaEmeImg },
      { name: "SIR ONYEACHU JONATHAN", birthday: "20th August, 1945", award: "KJW", phone: "08037081836", image: abaOnyeachuJonathanImg },
      { name: "SIR NNAJI PAUL CHIJIOKE", birthday: "10th January, 1954", award: "KJW", phone: "08033437596", image: abaNnajiPaulImg },
      { name: "SIR ONYEOZIRI MAXWELL", birthday: "27th January, 1937", award: "KJW", phone: "08036709122", image: abaOnyeoziriMaxwellImg },
      { name: "DAME OKECHUKWU NGOZI", birthday: "12th October, 1966", award: "KJW", phone: "08033166733", image: abaDameOkechukwuNgoziImg },
      { name: "DAME JOHN AJUGA NKECHI", birthday: "31st December, 1973", award: "KJW", phone: "08033382288", image: abaDameJohnAjugaNkechiImg },
      { name: "SIR CHUKWU JAMES", birthday: "24th February, 1961", award: "KJW", phone: "08034493089", image: abaChukwuJamesImg },
      { name: "SIR ANYA CHUKWU", birthday: "12th April, 1962", award: "KJW", phone: "07034773175", image: abaAnyaChukwuImg },
      { name: "SIR DIMGBA CHINTUA GLADSTONE", birthday: "1st October, 1960", award: "KJW", phone: "07048889669", image: abaDimgbaChintuaImg },
      { name: "SIR MMAM AGBAI IKECHUKWU", birthday: "24th April, 1963", award: "KJW", phone: "08038780449", image: abaMmamAgbaiImg },
      { name: "SIR NJOKU RICHARD", birthday: "24th November, 1950", award: "KJW", phone: "08033403948", image: abaNjokuRichardImg },
      { name: "SIR ROBERT EMENIKE OKOJI", birthday: "24th October, 1959", award: "KJW", phone: "08032634526", image: abaRobertEmenikeImg },
      { name: "SIR NWABAJI OGBONNAYA", birthday: "15th August, 1954", award: "KJW", phone: "08064801617", image: abaNwabajiOgbonnayaImg },
      { name: "SIR CHUKWU SUNDAY", birthday: "20th July, 1963", award: "KJW", phone: "08036777772", image: abaChukwuSundayImg },
      { name: "SIR AGU JEREMIAH", birthday: "21st February, 1951", award: "KJW", phone: "08034149246", image: abaAguJeremiahImg },
      { name: "SIR OGBONNAYA IHEANYICHUKWU", birthday: "26th February, 1972", award: "KJW", phone: "08064585559", image: abaOgbonnayaIheanyiImg },
      { name: "SIR CHUKWU EMMANUEL A.", birthday: "1955", award: "KJW", phone: "08037154869", image: abaChukwuEmmanuelImg },
      { name: "SIR OBASI OBIOMA PHILIP IROEGBU", birthday: "20th March, 1957", award: "KJW", phone: "08035496231", image: abaObasiObiomaImg },
      { name: "SIR UGAH AKOBUNDU DIKE", birthday: "24th November, 1958", award: "KJW", phone: "08068181279", image: abaUgahAkobunduImg },
      { name: "SIR ONYEGBULA ISAIAH CHIBUWA", birthday: "4th May, 1945", award: "KJW", phone: "08165991668", image: abaOnyegbulaIsaiahImg },
      { name: "DAME OMERUA ROSE ADAUGO", birthday: "22nd November, 1949", award: "KJW", phone: "07030969485", image: abaOmeruaRoseImg },
      { name: "DAME OSONDU PAULINE ULUNMA", birthday: "5th August, 1963", award: "KJW", phone: "08034874966", image: abaOsonduPaulineImg },
      { name: "SIR OKORO UMEKWE UKACHUKWU", birthday: "10th October, 1958", award: "KJW", phone: "08063996424", image: abaOkoroUmekweImg },
      { name: "HRH. SIR OGBONNA RAPHAEL UKACHI", birthday: "12th June, 1942", award: "KJW", phone: "08033339143", image: abaHrhOgbonnaImg },
      { name: "SIR KENNETH EBILAH", birthday: "28th April, 1948", award: "KJW", phone: "08032716458", image: abaKennethEbilahImg },
      { name: "SIR ONYEKWERE HOPE", birthday: "24th March, 1943", award: "KJW", phone: "08036788477", image: abaOnyekwereHopeImg },

    ],
  },
  umuahia: {
    name: "Umuahia",
    members: [
      { name: "SIR COMR. LUCKY AKABUIKE", birthday: "", award: "KJW", phone: "07060930888", position: "Chapter Chairman", image: portraits["umuahia-lucky-akabuike"] },
      { name: "SIR HON. DR. MBA PAUL CHIKEZIE", birthday: "17th March", award: "KJW", phone: "08035087497", image: chapterPortraits["umuahia/mba-paul-chikezie"] },
      { name: "SIR PRINCE NKUME", birthday: "8th August", award: "KJW", phone: "08033460296", image: princeNkumeImg },
      { name: "SIR ROYAL HIGH CHIEF UKPABI JOHNNY NDUBUISI", birthday: "25th January", award: "KJW", phone: "08027825447", image: ukpabiJohnnyImg },
      { name: "SIR HIGH CHIEF AGOMOH CHUKWUKA (JP, FCIA)", birthday: "27th July, 1973", award: "KJW", phone: "08034947574", image: chapterPortraits["umuahia/agomoh-chukwuka"] },
      { name: "DAME OZOEMELAM JOY", birthday: "10th May, 1970", award: "KCW", phone: "08088874509", image: chapterPortraits["umuahia/ozoemelam-joy"] },
      { name: "SIR COMRADE EKWURIBE HOPE OKECHI", birthday: "8th August, 1965", award: "KCW", phone: "08067971964", image: chapterPortraits["umuahia/ekwuribe-hope-okechi"] },
      { name: "SIR ATULOMAH ANAB", birthday: "26th November, 1944", award: "KJW", phone: "07033803294", image: chapterPortraits["umuahia/atulomah-anab"] },
      { name: "SIR ROYAL HIGH CHIEF IGWE EMMANUEL", birthday: "25th December, 1945", award: "KJW", phone: "08034937493", image: chapterPortraits["umuahia/igwe-emmanuel"] },
      { name: "SIR NWAKANMA EMERSON", birthday: "12th February, 1960", award: "KJW", phone: "08037127955", image: chapterPortraits["umuahia/nwakanma-emerson"] },
      { name: "SIR ABARIKWU ONYEMA", birthday: "25th August, 1964", award: "KJW", phone: "08037777821", image: chapterPortraits["umuahia/abarikwu-onyema"] },
      { name: "SIR CHIEF ACHILEFU OKEAHIALAM", birthday: "4th April, 1952", award: "KCW", phone: "08063407854", image: chapterPortraits["umuahia/achilefu-okeahialam"] },
      { name: "SIR CHIEF ALIGHILI ONYEKACHI PRINCELY", birthday: "15th May, 1958", award: "KCW", phone: "08033629288", image: chapterPortraits["umuahia/alighili-onyekachi-princely"] },
      { name: "SIR ENGR. NDUKWE OKECHI", birthday: "10th June, 1942", award: "KJW", phone: "08037446786", image: chapterPortraits["umuahia/ndukwe-okechi"] },
      { name: "DAME UGOEZE ONUIGBO EUNICE", birthday: "1968", award: "KJW", phone: "08024371438", image: chapterPortraits["umuahia/ugoze-onuigbo-eunice"] },
      { name: "SIR HIGH CHIEF UZOHUO NDUBUISI", birthday: "16th March, 1953", award: "KJW", phone: "08069239557", image: chapterPortraits["umuahia/uzohuo-ndubuisi"] },
      { name: "SIR OJI OBISIKE", birthday: "30th January, 1958", award: "KJW", phone: "08055939881", image: chapterPortraits["umuahia/oji-obisike"] },
      { name: "SIR EZURUIKE IHEANACHO", birthday: "15th June, 1946", award: "KJW", phone: "", image: chapterPortraits["umuahia/ezuruike-iheanacho"] },
      { name: "SIR HRM. EZE OKPOKIRI ALLAN ONYENAUCHEYA", birthday: "25th November, 1947", award: "KJW", phone: "07038348844, 09127158114", image: chapterPortraits["umuahia/eze-okpokiri-allan-onyenaucheya"] },
      { name: "SIR HIGH CHIEF AMAJOH SAMUEL BRYANT CHIMEREZE", birthday: "28th January, 1945", award: "KJW", phone: "08034481994", image: chapterPortraits["umuahia/amajoh-samuel-bryant-chimereze"] },
      { name: "SIR UKAEGBU OBINNA", birthday: "26th April, 1959", award: "KJW", phone: "+18322822331", image: chapterPortraits["umuahia/ukaegbu-obinna"] },
      { name: "SIR ELDER NZEAKO SUNDAY UCHECHUKWU", birthday: "23rd February, 1947", award: "KJW", phone: "08034669973", image: chapterPortraits["umuahia/nzeako-sunday-uchechukwu"] },
      { name: "SIR PROF. NWOKOCHA UDO", birthday: "26th September, 1963", award: "KJW", phone: "08037771611", image: chapterPortraits["umuahia/nwokocha-udo"] },
      { name: "SIR CHIEF MBAKWE HUMPHREY", birthday: "5th June, 1945", award: "KJW", phone: "08033378277", image: chapterPortraits["umuahia/mbakwe-humphrey"] },
      { name: "SIR HIGH CHIEF DR. IBEBUNJOH CHINEDUM I.", birthday: "5th May, 1952", award: "KJW", phone: "08037019487", image: chapterPortraits["umuahia/ibebunjoh-chinedum"] },
      { name: "SIR HRM. NWOSU UZO", birthday: "15th March, 1953", award: "KJW", phone: "08033146799" },
      { name: "SIR CHIEF ANOZIE IKECHI", birthday: "13th November, 1949", award: "KCW", phone: "08036680967" },
      { name: "SIR CHIEF UWAOMA KELECHI OBINNA", birthday: "2nd June, 1975", award: "KJW", phone: "08035755415" },
      { name: "SIR CHIEF ONWUKWE AHAMEFULE", birthday: "10th November, 1947", award: "KCW", phone: "08030717694" },
      { name: "SIR CHIEF OKEUHIE VICTOR IHEMEREMADU", birthday: "1938", award: "KJW", phone: "09168440951" },
      { name: "SIR IHEUKWUMERE NKEMKA", birthday: "31st July, 1947", award: "KJW", phone: "08036708006" },
      { name: "SIR CHIEF OCHIABUTO MADUABUCHI SAMUEL", birthday: "19th September, 1953", award: "KJW", phone: "08034224292" },
      { name: "SIR DR. JANDEN CORPUT HANS", birthday: "27th September, 1958", award: "KJW", phone: "08022662558" },
      { name: "SIR DR. ROYAL HIGH CHIEF OKPARANTA EMMANUEL ONYEGBULE", birthday: "30th September, 1941", award: "KJW", phone: "08164653006" },
      { name: "SIR HIGH CHIEF ISIOCHA ONWUSONYE GODSWILL", birthday: "14th January, 1949", award: "KJW", phone: "08050780636, 07026499995" },
      { name: "SIR HIGH CHIEF OKONKOR OBINNAYA KENNETH", birthday: "12th December, 1958", award: "KCW", phone: "07039099209" },
      { name: "SIR CHIEF DR. OHAERI EMEKA", birthday: "10th March, 1959", award: "KCW", phone: "08034957064" },
    ],
  },
  lagos: {
    name: "Lagos",
    members: [
      { name: "DAME PRINCESS ADETOPE TYCHUS", birthday: "7th January", award: "KJW", phone: "08033084362", position: "Chapter Chairman", image: portraits["lagos-adetope-tychus"] },
      { name: "DAME OSHINOWO MODUPE", birthday: "6th April", award: "KJW", phone: "08033193623", image: chapterPortraits["lagos/dame-oshinowo-modupe"] },
      { name: "SIR OGUNLANA EBENEZER OLANREWAJU", birthday: "16th March", award: "KCW", phone: "08033032687", image: chapterPortraits["lagos/sir-ogunlana-ebenezer-olanrewaju"] },
      { name: "SIR KAMSON OLAYINKA OLUSOGA", birthday: "13th June", award: "KJW", phone: "08033012523", image: chapterPortraits["lagos/sir-kamson-olayinka-olusoga"] },
      { name: "SIR OGUNKOYA ABIODUN", birthday: "11th April", award: "KJW", phone: "08036060602", image: chapterPortraits["lagos/sir-ogunkoya-abiodun"] },
      { name: "DAME AWOSANYA STELLA", birthday: "6th April", award: "KJW", phone: "08033216800", image: chapterPortraits["lagos/dame-awosanya-stella"] },
      { name: "SIR OPELUSI ALBERT RANTI", birthday: "21st April", award: "KJW", phone: "08038194591", image: chapterPortraits["lagos/sir-opelusi-albert-ranti"] },
      { name: "DAME AYOOLA OLULANU ADEBISI", birthday: "19th November", award: "KJW", phone: "08033040600", image: chapterPortraits["lagos/dame-ayoola-olulanu-adebisi"] },
      { name: "DAME CARZIM SHOLA IYABO", birthday: "23rd November", award: "KJW", phone: "08033456780", image: chapterPortraits["lagos/dame-carzim-shola-iyabo"] },
      { name: "SIR CARZIM ABIMBOLA SYLVESTER", birthday: "28th July", award: "KJW", phone: "08033788387", image: chapterPortraits["lagos/sir-carzim-abimbola-sylvester"] },
      { name: "SIR OYENUSI EZEKIEL AKINOLA", birthday: "2nd December", award: "KJW", phone: "08023033781", image: chapterPortraits["lagos/sir-oyenusi-ezekiel-akinola"] },
      { name: "DAME CHIEF ANJOUS GRACE ORITSEJOLOMI", birthday: "19th August", award: "KJW", phone: "08033646596", image: chapterPortraits["lagos/dame-chief-anjous-grace-oritsejolomi"] },
      { name: "SIR DR. COKER FESTUS OLUMUYIWA", birthday: "23rd September", award: "KJW", phone: "08054111099", image: chapterPortraits["lagos/sir-dr-coker-festus-olumuyiwa"] },
      { name: "DAME OSUNNEYE OLABISI OLUFUNMILOLA", birthday: "28th August", award: "KJW", phone: "08035835845", image: chapterPortraits["lagos/dame-osunneye-olabisi-olufunmilola"] },
      { name: "DAME OKUNRINBOYE FRANCES OLUFUNMILAYO", birthday: "6th December", award: "KJW", phone: "08033061990, 09071202220", image: chapterPortraits["lagos/dame-okunrinboye-frances-olufunmilayo"] },
      { name: "DAME IKULALA-ALLEN STELLA OLUSOLA", birthday: "3rd December", award: "KCW", phone: "08033181397", image: chapterPortraits["lagos/dame-ikulala-allen-stella-olusola"] },
      { name: "ONAFOWOKAH ADEMOLA", birthday: "29th July", award: "KJW", phone: "08089884075", image: chapterPortraits["lagos/onafowokah-ademola"] },
      { name: "SIR SOBAMOWO BABATUNDE EMMANUEL", birthday: "23rd November", award: "KJW", phone: "08033226487", image: chapterPortraits["lagos/sir-sobamowo-babatunde-emmanuel"] },
      { name: "DAME SOYANNWO TAIWO ONIKEPE", birthday: "26th April", award: "KJW", phone: "08023125531", image: chapterPortraits["lagos/dame-soyannwo-taiwo-onikepe"] },
      { name: "DAME SIMPLICE GLADYS OLAJUMOKE", birthday: "30th April", award: "KJW", phone: "08023066449, 08060836811", image: chapterPortraits["lagos/dame-simplice-gladys-olajumoke"] },
      { name: "DAME OSILESI ADEYINKA", birthday: "30th April", award: "KJW", phone: "08033371270", image: chapterPortraits["lagos/dame-osilesi-adeyinka"] },
      { name: "SIR OGUNJUBOUN FREDERICK ILUYOMADE", birthday: "18th October", award: "KJW", phone: "08037228133", image: chapterPortraits["lagos/sir-ogunjuboun-frederick-iluyomade"] },
      { name: "SIR OYEDIPE ADEKUNLE", birthday: "25th February", award: "KCW", phone: "08099778665", image: chapterPortraits["lagos/sir-oyedipe-adekunle"] },
      { name: "SIR AKINSANYA EMMANUEL AKINWALE", birthday: "23rd September", award: "KJW", phone: "08022231460", image: chapterPortraits["lagos/sir-akinsanya-emmanuel-akinwale"] },
      { name: "SIR AKINTAYO ADETAYO", birthday: "3rd January", award: "KCW", phone: "08033049386", image: chapterPortraits["lagos/sir-akintayo-adetayo"] },
      { name: "DAME AKINYEMI DORCAS", birthday: "24th June", award: "KJW", phone: "08033263388", image: chapterPortraits["lagos/dame-akinyemi-dorcas"] },
      { name: "SIR OGUNJIMI TEJU", birthday: "7th April", award: "KJW", phone: "08033069784", image: chapterPortraits["lagos/sir-ogunjimi-teju"] },
      { name: "DAME KALEJAIYE ADEOLA IDOWU", birthday: "8th May", award: "KJW", phone: "08023158053", image: chapterPortraits["lagos/dame-kalejaiye-adeola-idowu"] },
      { name: "SIR ONYEUKWU OGUERI TEMPLE", birthday: "28th February", award: "KJW", phone: "08033193360", image: chapterPortraits["lagos/sir-onyeukwu-ogueri-temple"] },
      { name: "SIR SHODERU OMOKAYODE", birthday: "24th June", award: "KJW", phone: "08023088449, 08033232139", image: chapterPortraits["lagos/sir-shoderu-omokayode"] },
      { name: "SIR BENSON OLABISI", birthday: "6th July", award: "KJW", phone: "08034881456", image: chapterPortraits["lagos/sir-benson-olabisi"] },
      { name: "SIR ESAN ADEREMI", birthday: "25th August", award: "KJW", phone: "08037600888", image: chapterPortraits["lagos/sir-esan-aderemi"] },
      { name: "DAME SAGOE ABA OMOTUNDE", birthday: "13th February", award: "KJW", phone: "07087167266", image: chapterPortraits["lagos/dame-sagoe-aba-omotunde"] },
      { name: "SIR ANOFOWAKAN AYOKUNLE SALAKO", birthday: "9th August", award: "KJW", phone: "08023004667", image: chapterPortraits["lagos/sir-anofowakan-ayokunle-salako"] },
      { name: "SIR AJAYI AYODELE", birthday: "19th January", award: "KJW", phone: "08032091918", image: chapterPortraits["lagos/sir-ajayi-ayodele"] },
      { name: "SIR SUNMONI DAVID", birthday: "16th January", award: "KJW", phone: "08033215538", image: chapterPortraits["lagos/sir-sunmoni-david"] },
      { name: "SIR ODUNSI J. ALEX OLUWATOYIN", birthday: "10th October", award: "KJW", phone: "08023227689", image: chapterPortraits["lagos/sir-odunsi-j-alex-oluwatoyin"] },
      { name: "SIR OTUNBA ODULATE JOSEPH", birthday: "14th February", award: "KJW", phone: "08023534606, 08099786868" },
      { name: "DAME LATUNDE-LAWAL OLAJUMOKE ABIODUN", birthday: "19th December", award: "KJW", phone: "08033487066", image: chapterPortraits["lagos/dame-latunde-lawal-olajumoke-abiodun"] },
      { name: "DAME BANJOKO ADEOLA", birthday: "25th October", award: "KJW", phone: "08032505455", image: chapterPortraits["lagos/dame-banjoko-adeola"] },
      { name: "SIR OMOOBA ONAFOWAKAN OLUSOJI ALFRED", birthday: "24th March", award: "KCW", phone: "08033470131, 09022346434", image: chapterPortraits["lagos/sir-omooba-onafowakan-olusoji-alfred"] },
      { name: "SIR ENGR. CHIEF OSHINOWO OLADIMEJI", birthday: "29th October", award: "KJW", phone: "08023203877", image: chapterPortraits["lagos/sir-engr-chief-oshinowo-oladimeji"] },
      { name: "SIR ELESHO AYODELE OLUWOLE", birthday: "12th January", award: "KJW", phone: "08023088632, 08055223355", image: chapterPortraits["lagos/sir-elesho-ayodele-oluwole"] },
      { name: "SIR AKINTOLA SUNDAY OLAKUNLE", birthday: "22nd November", award: "KJW", phone: "09046807229", image: chapterPortraits["lagos/sir-akintola-sunday-olakunle"] },
      { name: "SIR CHIEF ONAKOYA OLATUNDE", birthday: "27th May", award: "KJW", phone: "08033234591", image: chapterPortraits["lagos/sir-chief-onakoya-olatunde"] },
      { name: "SIR THORPE ISAAC OLUSINA", birthday: "17th July", award: "KJW", phone: "08053046251", image: chapterPortraits["lagos/sir-thorpe-isaac-olusina"] },
      { name: "DAME SOLANKE SUSAN ISOKEN", birthday: "30th December", award: "KJW", phone: "08089354829, 447956157874", image: chapterPortraits["lagos/dame-solanke-susan-isoken"] },
      { name: "SIR DR. AUSTEN-PETERS ADEGBOYEGA OLUWAROTIMI", birthday: "28th May", award: "KJW", phone: "08036990000", image: chapterPortraits["lagos/sir-dr-austen-peters-adegboyega-oluwarotimi"] },
      { name: "DAME DR. AKINTOLA-OSHO OLUFUNBI", birthday: "11th May", award: "KJW", phone: "08140193978", image: chapterPortraits["lagos/dame-dr-akintola-osho-olufunbi"] },
      { name: "DAME WILLIAMS ADEBOLA", birthday: "15th January", award: "KJW", phone: "08022905605", image: chapterPortraits["lagos/dame-williams-adebola"] },
      { name: "SIR WILLIAMS ABAYOMI", birthday: "25th February", award: "KJW", phone: "08097775256", image: chapterPortraits["lagos/sir-williams-abayomi"] },
      { name: "SIR BRIG. GEN. (RTD.) BOSSMAN CHARLES", birthday: "28th January", award: "KCW", phone: "08124993277", image: chapterPortraits["lagos/sir-brig-gen-rtd-bossman-charles"] },
      { name: "SIR CHIEF ARIYO OLUWOLE", birthday: "6th February", award: "KJW", phone: "08090708655, 08026094514", image: chapterPortraits["lagos/sir-chief-ariyo-oluwole"] },
      { name: "DAME AWOSEDO COMFORT MODUPEFOLUWA OLUBUNMI", birthday: "16th May", award: "KJW", phone: "08033922688, 08165361564", image: chapterPortraits["lagos/dame-awosedo-comfort-modupefoluwa-olubunmi"] },
      { name: "SIR ENGR. FRAZIER SAMUEL BABASHOLA", birthday: "18th May", award: "KJW", phone: "08023201873", image: chapterPortraits["lagos/sir-engr-frazier-samuel-babashola"] },
      { name: "SIR REAR ADMIRAL (RTD.) JOSEPH OLADEINDE", birthday: "5th May", award: "KJW", phone: "08023344699, 08055166024", image: chapterPortraits["lagos/sir-rear-admiral-rtd-joseph-oladeinde"] },
      { name: "SIR OGUNSANYA DADA OLUTAYO", birthday: "23rd August", award: "KJW", phone: "08034582424", image: chapterPortraits["lagos/sir-ogunsanya-dada-olutayo"] },
      { name: "SIR FALOLA OLAKUNLE OLAOLUWA", birthday: "19th October", award: "KJW", phone: "08023003202", image: chapterPortraits["lagos/sir-falola-olakunle-olaoluwa"] },
      { name: "DAME ODUKALE MATILDA I.", birthday: "18th December", award: "KJW", phone: "08022238067", image: chapterPortraits["lagos/dame-odukale-matilda-i"] },
      { name: "SIR DR. INUIKIM ASUQUO", birthday: "10th July", award: "KJW", phone: "08033255901, 08094441036", image: chapterPortraits["lagos/sir-dr-inuikim-asuquo"] },
      { name: "SIR AJANAKU ADESEGUN", birthday: "9th May", award: "KJW", phone: "08033462989", image: chapterPortraits["lagos/sir-ajanaku-adesegun"] },
      { name: "SIR OGUNNIRAN OLUFEMI", birthday: "20th May", award: "KJW", phone: "08062393515", image: chapterPortraits["lagos/sir-ogunniran-olufemi"] },
      { name: "SIR LAMIDI AMBROSE SANNI", birthday: "18th March", award: "KJW", phone: "08023295964", image: chapterPortraits["lagos/sir-lamidi-ambrose-sanni"] },
      { name: "DAME DR. ANAMAH DOROTHY", birthday: "2nd December", award: "KJW", phone: "08033090950" },
      { name: "SIR PRINCE OLATERU-OLAGBEGI ADEYEMI", birthday: "19th June", award: "KJW", phone: "08022252992", image: chapterPortraits["lagos/sir-prince-olateru-olagbegi-adeyemi"] },
      { name: "SIR AWOBONA OLANIYI", birthday: "17th February", award: "KJW", phone: "08034550240", image: chapterPortraits["lagos/sir-awobona-olaniyi"] },
      { name: "SIR DR. PUDDICOMBE BABAJIDE JOHN", birthday: "30th December", award: "KJW", phone: "08023008118" },
      { name: "SIR OGUNYEMI GORIOLA", birthday: "2nd January", award: "KJW", phone: "08033078044, 08052221234" },
      { name: "SIR ALADEKOMO DEMOLA", birthday: "31st December", award: "KJW", phone: "08055544333" },
      { name: "SIR OLANIYAN OLUWATOSIN", birthday: "11th February", award: "KCW", phone: "08032480231", image: chapterPortraits["lagos/sir-olaniyan-oluwatosin"] },
      { name: "DAME PRINCESS ADETOPE TYCHUS", birthday: "7th January", award: "KJW", phone: "08033084362", position: "Chapter Chairman", image: portraits["lagos-adetope-tychus"] },
      { name: "SIR A.I.G. COLE CHARLES AKANDE", birthday: "12th May", award: "KJW", phone: "08033056965, 08023459998", image: chapterPortraits["lagos/sir-a-i-g-cole-charles-akande"] },
      { name: "DAME GEORGE IYABODE", birthday: "25th June", award: "KJW", phone: "08033026752", image: chapterPortraits["lagos/dame-george-iyabode"] },
      { name: "SIR GEORGE OLUSEGUN", birthday: "10th July", award: "KJW", phone: "08033013349", image: chapterPortraits["lagos/sir-george-olusegun"] },
      { name: "SIR COLE ANTHONY BOLA", birthday: "19th January", award: "KJW", phone: "08036669564", image: chapterPortraits["lagos/sir-cole-anthony-bola"] },
      { name: "DAME OLUFON ADEBISI ADEBOLA", birthday: "9th May", award: "KJW", phone: "08023024910", image: chapterPortraits["lagos/dame-olufon-adebisi-adebola"] },
      { name: "DAME GEORGE YEWANDE", birthday: "26th October", award: "KJW", phone: "08023061819", image: chapterPortraits["lagos/dame-george-yewande"] },
      { name: "DAME BARR. FADIPE ETHEL OLAMIDE", birthday: "4th February", award: "KJW", phone: "", image: chapterPortraits["lagos/dame-barr-fadipe-ethel-olamide"] },
      { name: "DAME AKAPO JUDITH YEWANDE", birthday: "14th March", award: "KJW", phone: "08023262306", image: chapterPortraits["lagos/dame-akapo-judith-yewande"] },
      { name: "DAME OMOTAYO MOJIRADE ASABI", birthday: "9th August", award: "KJW", phone: "08033744343", image: chapterPortraits["lagos/dame-omotayo-mojirade-asabi"] },
      { name: "SIR INUEKIM EYO", birthday: "4th April", award: "KJW", phone: "08033044944, 08124804978", image: chapterPortraits["lagos/sir-inuekim-eyo"] },
      { name: "SIR COKER FEYISETON", birthday: "13th March", award: "KJW", phone: "08033002695", image: chapterPortraits["lagos/sir-coker-feyiseton"] },
      { name: "DAME ODEKA OLATOMI IBIYEMI", birthday: "24th June", award: "KJW", phone: "08022232540", image: chapterPortraits["lagos/dame-odeka-olatomi-ibiyemi"] },
      { name: "DAME IGE SYLVIA TAIWO", birthday: "12th July", award: "KJW", phone: "08033050548", image: chapterPortraits["lagos/dame-ige-sylvia-taiwo"] },
      { name: "DAME OSUNNEYE OLUFUNMILOLA OLABISI", birthday: "28th August", award: "KJW", phone: "08035835845, 08074737748" },
      { name: "SIR ODOJUKAN ABIODUN", birthday: "26th December", award: "KJW", phone: "08022910876", image: chapterPortraits["lagos/sir-odojukan-abiodun"] },
      { name: "DAME PRINCESS ASIM-ITA GERALDINE", birthday: "24th August", award: "KJW", phone: "08023641583", image: chapterPortraits["lagos/dame-princess-asim-ita-geraldine"] },
      { name: "SIR OTOKI JOSEPH ABIODUN", birthday: "3rd January", award: "KJW", phone: "", image: chapterPortraits["lagos/sir-otoki-joseph-abiodun"] },
      { name: "SIR DR. IKETUBOSIN FAYEOFORI", birthday: "8th May", award: "KJW", phone: "08023125848", image: chapterPortraits["lagos/sir-dr-iketubosin-fayeofori"] },
    ],

  },
  ibadan: {
    name: "Ibadan",
    members: [
      { name: "SIR JOHN KAYODE DOSUNMU", birthday: "", award: "KJW", phone: "08062918638", position: "Chapter Chairman", image: portraits["ibadan-kayode-dosunmu"] },
      { name: "CHIEF SIR SEGUN AJEKIIGBA", birthday: "19th October", award: "KJW", phone: "08057741778", whatsapp: "08028247426", image: segunAjekiigbaImg },
      { name: "SIR (ENGR.) OLANRENWAJU ABIOLA DAVID", birthday: "26th April", award: "KJW", phone: "08023153666", image: olarenwajuAbiolaImg },
      { name: "HON. SIR AKANBI EMMANUEL ADEBAYO", birthday: "9th May", award: "KJW", phone: "08038373916", image: akanbiEmmanuelImg },
      { name: "AMB. SIR DR. AFOLABI GBADEBO", birthday: "30th January", award: "KJW", phone: "07063415739" },
      { name: "SIR AJGBE KOLAWOLE", birthday: "4th June", award: "KJW", phone: "08037868777", image: ajagbeKolawoleImg },
      { name: "SIR EGBEWUMI TAIWO SAMUEL", birthday: "3rd January", award: "KCW", phone: "08033731973", image: egbewumiTaiwoImg },
      { name: "SIR ANIMASAUN JOSEPH", birthday: "8th June", award: "KJW", phone: "08033661484", whatsapp: "08023264407", image: animasaunJosephImg },
      { name: "SIR OKUNLOLA OLUSEGUN", birthday: "30th October", award: "KJW", phone: "08036952593", image: okunlolaOlusegunImg },
      { name: "DAME THOMAS IBIRONKE", birthday: "23rd September", award: "KJW", phone: "08033267189" },
      { name: "DAME MAKINDE ELIZABETH", birthday: "26th June", award: "KJW", phone: "08037021165" },
      { name: "DAME JUBA STELLA OLUREMI", birthday: "4th April", award: "KJW", phone: "08033109441", image: jubaStellaImg },
      { name: "SIR OMOFIOYE OYEDELE ERNEST", birthday: "7th November", award: "KJW", phone: "08035904785", image: omofioyeOyedeleImg },
      { name: "SIR HON. JUSTICE ADENIJI BADEJO OLATEJU", birthday: "5th August", award: "KJW", phone: "08034309183", whatsapp: "08023273489" },
      { name: "SIR HON. AKINTOLA GEORGE OLUOKUN", birthday: "22nd April", award: "KJW", phone: "08033781709" },
      { name: "DAME ADEYEMI AYOTUNDE", birthday: "17th December", award: "KJW", phone: "08035394717" },
      { name: "SIR PROF. AROWOJOLU AYODELE OLATUNJI", birthday: "27th July", award: "KJW", phone: "08033979478" },
      { name: "SIR DR. OLUMEKO OLAJIDE", birthday: "17th December", award: "KJW", phone: "08033293635" },
      { name: "SIR PROF. FAWOLE OLATUNDE", birthday: "9th November", award: "KJW", phone: "08033507430" },
      { name: "SIR BARR. OLANIPEKUN OLAYINKA MICHAEL", birthday: "14th February", award: "KJW", phone: "08033114395", whatsapp: "08091520644" },
      { name: "SIR OJO JACOB OYEBAMIJI OGBOMOSO", birthday: "21st June", award: "KJW", phone: "08032376607" },
      { name: "SIR PROF. ADEKOLA ADETOYESE ADEKOLA", birthday: "10th June", award: "KJW", phone: "08034080951" },
      { name: "SIR ADEFEMI NOAH", birthday: "14th April", award: "KJW", phone: "08060334836" },
      { name: "SIR ENGR. AYANDELE EZEKIEL AYANBANJI", birthday: "16th May", award: "KJW", phone: "08033524875" },
      { name: "SIR OLADIPO GABRIEL", birthday: "21st November", award: "KJW", phone: "08034497314" },
      { name: "SIR BARR. ADESINA GBADEBO OLUSOLA", birthday: "7th June", award: "KJW", phone: "08037009033", whatsapp: "08023253754" },
      { name: "SIR OKUNOLA OLUSEGUN", birthday: "30th October", award: "KJW", phone: "08036952593" },
      { name: "SIR DR. OLADEJI KEHINDE", birthday: "19th September", award: "KJW", phone: "07083365897", whatsapp: "07065908479" },
      { name: "SIR OLADOYINBO OLUGBENGA", birthday: "25th May", award: "KJW", phone: "08033716250" },
      { name: "SIR AINA ADEGBITE", birthday: "9th December", award: "KJW", phone: "08023092050", whatsapp: "09035887868" },
      { name: "SIR BABALOLA IFEOLUWA", birthday: "13th March", award: "KCW", phone: "08139368135" },
      { name: "DAME ESAN ADEPEJU", birthday: "9th October", award: "KJW", phone: "08038013290", whatsapp: "09051500860" },
      { name: "SIR AARE OLANIPEKUN SAMUEL", birthday: "19th January", award: "KJW", phone: "07061015641" },
      { name: "SIR ADEBAYO AYODEJI", birthday: "20th April", award: "KJW", phone: "08033205134" },
      { name: "SIR ADESANYA ADEBIYI", birthday: "9th October", award: "KJW", phone: "08033243936" },
      { name: "SIR DR. FATOKUN OLUJIDE", birthday: "4th September", award: "KJW", phone: "08034782929", whatsapp: "08029436284" },
      { name: "SIR ENGR. AFONUA JULIUS", birthday: "4th December", award: "KCW", phone: "08033558678" },
      { name: "SIR OKE OLUMUYIWA AKINOLU", birthday: "7th October", award: "KJW", phone: "08036712285" },
      { name: "SIR DOSUNMU JOHN KAYODE", birthday: "29th May", award: "KJW", phone: "08062918638" },
      { name: "SIR HON. DR ADEYEMO OLALEKAN", birthday: "23rd September", award: "KJW", phone: "08030401878" },
      { name: "SIR OJO JOHN ADEMOLA", birthday: "1st June", award: "KJW", phone: "08032636636" },
      { name: "SIR AFOLABI JOHN OLANIYI", birthday: "13th June", award: "KJW", phone: "08034224057" },
      { name: "SIR OSUNBUNMI EBENEZER OLATUNDE", birthday: "10th November", award: "KJW", phone: "08056150030", whatsapp: "08038540388" },
      { name: "DAME IDOWU ADENIKE OLUYEMISI", birthday: "2nd July", award: "KJW", phone: "08062124101" },
      { name: "SIR IDOWU ADEMOLA ADESEYE", birthday: "26th September", award: "KJW", phone: "08034044220" },
      { name: "SIR AKANBI ADEBAYO EMMANUEL", birthday: "9th May", award: "KJW", phone: "08038373916" },
      { name: "SIR OJO ISAAC OYEYEMI", birthday: "22nd February", award: "KJW", phone: "09066058770", whatsapp: "08032491004" },
      { name: "SIR AKINTAYO JOHNSON", birthday: "2nd October", award: "KJW", phone: "08039244468" },
      { name: "DAME ADEBISI RUTH ARINOLA", birthday: "26th June", award: "KJW", phone: "08023365067" },
      { name: "SIR DADA MICHAEL", birthday: "8th September", award: "KJW", phone: "08023423911" },
      { name: "SIR PROF. KAYODE ADEDEJI OLUYEMI", birthday: "4th June", award: "KJW", phone: "08033857249", whatsapp: "08055951394" },
      { name: "DAME OLAYEYE TINUOLA OLUBUKOLA", birthday: "30th August", award: "KJW", phone: "08037173554" },
      { name: "DAME AKINWALE ABIMBOLA", birthday: "1st September", award: "KJW", phone: "08023859890" },
      { name: "SIR OGUNDELE AMOS", birthday: "29th March", award: "KJW", phone: "08023023270" },
      { name: "SIR ABODUNRIN GIDEON OLAYINKA", birthday: "3rd September", award: "KCW", phone: "08066492249" },
      { name: "SIR FAWOLE OLATUNDE", birthday: "29th November", award: "KJW", phone: "08033507430" },
      { name: "SIR ARIYIBI SAMSON OYEWALE", birthday: "29th November", award: "KJW", phone: "08035749424" },
      { name: "SIR OLANIPEKUN OLAYINKA MICHAEL", birthday: "14th February", award: "KJW", phone: "08033114395" },
      { name: "SIR FATEYE ADENIYI", birthday: "9th March", award: "KJW", phone: "08033550257" },
      { name: "SIR FAWOLE IYIOLA", birthday: "21st February", award: "KCW", phone: "08023382550" },
      { name: "SIR DR. AJAO MOTUNRAYO OLADELE", birthday: "16th January", award: "KJW", phone: "08033157799", whatsapp: "08089537900" },
      { name: "SIR KUJORE MODUPE", birthday: "26th September", award: "KJW", phone: "08033798398" },
      { name: "DAME OLAJULE ADETUTU OLUTOYIN", birthday: "28th February", award: "KJW", phone: "08037210159" },
      { name: "SIR OYEINO SIMEON OLUSEGUN", birthday: "15th September", award: "KJW", phone: "08034330791" },
      { name: "DAME PROF. ADEROUNMU ADEBOYIN FUNMI", birthday: "25th May", award: "KJW", phone: "08038076422", whatsapp: "08054293636" },
      { name: "SIR PRINCE OJO ISAAC OYEYEMI", birthday: "22nd February", award: "KJW", phone: "08032491004" },
      { name: "SIR PRINCE AGBOADE ORIMADEGUN JOSHUA", birthday: "5th March", award: "KJW", phone: "08033265151", whatsapp: "08120005151" },
      { name: "SIR AREMU FRANCIS FOLUSO", birthday: "7th July", award: "KJW", phone: "08067529696" },
    ],
  },
  portharcout: {
    name: "Portharcout",
    members: [
      { name: "SIR PROF. STEVE OGAMBA", birthday: "", award: "KJW", phone: "08022908427", position: "Chapter Chairman", image: portraits["portharcourt-steve-ogamba"] },
      { name: "SIR ABALUBU ABEL TORUE", birthday: "14th August, 1938", award: "KJW", phone: "08160746361", image: phAbalubuAbelTorueImg },
      { name: "SIR ABIIKOR JACKSON MONEY", birthday: "22nd July, 1954", award: "KJW", phone: "08037102097", image: phAbiikorJacksonMoneyImg },
      { name: "SIR PRINCE AIKU", birthday: "14th February, 1951", award: "KJW", phone: "08033427664", image: phPrinceAikuImg },
      { name: "HRH. EZE SIR ALATTA NDUBUISI NNAEDOZIE", birthday: "16th September, 1947", award: "KJW", phone: "08033126198", image: phAlattaNdubuisiImg },
      { name: "SIR APENU TORKA", birthday: "25th December, 1964", award: "KJW", phone: "08169771104", image: phApenuTorkaImg },
      { name: "SIR ATTIH EYO ASUQUO", birthday: "20th August, 1959", award: "KJW", phone: "08033011206", image: phAttihEyoAsuquoImg },
      { name: "SIR BADOM DUGDALE KPOOBARI", birthday: "20th June, 1945", award: "KJW", phone: "08035501332", image: phBadomDugdaleKpoobariImg },
      { name: "SIR BIIBALOO LEGBORSI", birthday: "5th January, 1977", award: "KJW", phone: "08036697493", image: phBiibalooLegborsiImg },
      { name: "SIR CHUKWU JAMES", birthday: "24th February, 1961", award: "KJW", phone: "08034493089", image: phChukwuJamesImg },
      { name: "SIR CHIEF COKER JIMMY NATHANIEL", birthday: "11th April, 1950", award: "KJW", phone: "08033395404", image: phCokerJimmyNathanielImg },
      { name: "SIR DADIOWEI AMAITARI THEOPHILUS", birthday: "8th August, 1938", award: "KJW", phone: "08035436900", image: phDadioweiAmaitariImg },
      { name: "SIR DEEKUE SAMUEL NAMENE", birthday: "21st August, 1956", award: "KJW", phone: "08036722332", image: phDeekueSamuelNameneImg },
      { name: "SIR DEKO NYIMA CONFIDENCE JOHN", birthday: "27th June, 1967", award: "KJW", phone: "08037245695", image: phDekoNyimaConfidenceImg },
      { name: "SIR DEKOR DUMNAMENE ROBINSON", birthday: "29th February, 1962", award: "KJW", phone: "08089880111", image: phDekorDumnameneRobinsonImg },
      { name: "SIR DICK TAMBARI", birthday: "25th October, 1963", award: "KJW", phone: "08037111613", image: phDickTambariImg },
      { name: "SIR ENGR. EKPENYONG OROK", birthday: "11th September, 1951", award: "KJW", phone: "07034171998", image: phEkpenyongOrokImg },
      { name: "SIR ELDER EKPO SAMUEL", birthday: "19th July, 1957", award: "KCW", phone: "09037065933", image: phEkpoSamuelImg },
      { name: "SIR EREBA PRECIOUS KPOOBARI", birthday: "12th May, 1956", award: "KCW", phone: "08036771384", image: phErebaPreciousKpoobariImg },
      { name: "SIR ETUKERE NUADAM", birthday: "15th August, 1971", award: "KJW", phone: "08037222412", image: phEtukereNuadamImg },
      { name: "SIR ENGR. EZE NWACHUKWU", birthday: "22nd September, 1958", award: "KJW", phone: "08136270088", image: phEzeNwachukwuImg },
      { name: "SIR EZERI CHUKWUEMEKA", birthday: "28th July, 1971", award: "KJW", phone: "08033080055", image: phEzeriChukwuemekaImg },
      { name: "SIR FRIDAY INYANG ETIOWO", birthday: "24th July, 1978", award: "KCW", phone: "08032651437", image: phFridayInyangEtiowoImg },
      { name: "SIR ENGR. GAAWA MOSES", birthday: "12th March, 1964", award: "KJW", phone: "08033424494", image: phGaawaMosesImg },
      { name: "SIR GBAFAH LEMABARI", birthday: "1st June, 1946", award: "KJW", phone: "08069308388", image: phGbafahLemabariImg },
      { name: "SIR BARR. GBARAGE LEGYO", birthday: "12th June, 1980", award: "KJW", phone: "08038831744", image: phGbarageLegyoImg },
      { name: "SIR PROF. GBARENEH LESI DIKE", birthday: "24th April, 1954", award: "KJW", phone: "08035519086", image: phGbarenehLesiDikeImg },
      { name: "SIR DR. GBOROGBOSI LESSI GABRIEL", birthday: "19th March, 1963", award: "KJW", phone: "07034604152", image: phGborogbosiLesiGabrielImg },
      { name: "SIR GIADOM LEADU SAMUEL", birthday: "11th June, 1960", award: "KJW", phone: "08066452727", image: phGiadomLeaduSamuelImg },
      { name: "SIR IBANGA EMMANUEL", birthday: "20th August, 1944", award: "KJW", phone: "08032715718", image: phIbangaEmmanuelImg },
      { name: "IDERIAH FELIX JOSEPH KIO", birthday: "20th October, 1947", award: "KJW", phone: "08033091400", image: phIderiahFelixJosephImg },
      { name: "SIR IHEOMA NELSON", birthday: "1st December, 1971", award: "KJW", phone: "08034954078", image: phIheomaNelsonImg },
      { name: "SIR IMA MARSHAL", birthday: "15th August, 1967", award: "KJW", phone: "08035125582", image: phImaMarshalImg },
      { name: "SIR JOSEPH LEBARI DUM", birthday: "25th April, 1965", award: "KJW", phone: "08033170722", image: phJosephLebariDumImg },
      { name: "SIR KANYONE GBARANEN KANYONE", birthday: "20th March, 1958", award: "KJW", phone: "08036694007", image: phKanyoneGbaranenImg },
      { name: "SIR KOKI MANILLA", birthday: "23rd June, 1950", award: "KJW", phone: "08033385900", image: phKokiManillaImg },
      { name: "DAME PROF. KONYA ROSELINE", birthday: "19th January", award: "KJW", phone: "07064401968", image: phKonyaRoselineImg },
      { name: "SIR KPONI BARINEM TENAADE", birthday: "21st December, 1958", award: "KJW", phone: "08033170063", image: phKponiBarinemTenaadeImg },
      { name: "SIR LEVI APOLLOS", birthday: "23rd February, 1972", award: "KJW", phone: "08038660597", image: phLeviApollosImg },
      { name: "SIR MADUKA HENRY", birthday: "15th October", award: "KJW", phone: "08056038164", image: phMadukaHenryImg },
      { name: "SIR MONSI GBODE NUBARI", birthday: "30th July, 1954", award: "KJW", phone: "08033403366", image: phMonsiGbodeNubariImg },
      { name: "SIR NENE CHINEDU", birthday: "3rd September, 1968", award: "KJW", phone: "08033250247", image: phNeneChineduImg },
      { name: "SIR NGBOR PRINCE", birthday: "3rd October, 1970", award: "KJW", phone: "08037064552", image: phNgborPrinceImg },
      { name: "SIR NJOKU ONYEKWERE", birthday: "29th October, 1948", award: "KJW", phone: "08037082834", image: phNjokuOnyekwereImg },
      { name: "SIR NKOR PHILIP KPENYUBARI KOKOO", birthday: "4th April, 1959", award: "KJW", phone: "08037387362", image: phNkorPhilipImg },
      { name: "SIR NNAH DUMBOR", birthday: "24th June, 1956", award: "KJW", phone: "08038812652", image: phNnahDumborImg },
      { name: "SIR PROF. NWANKPA ONYEE NNANNA", birthday: "26th January, 1958", award: "KCW", phone: "07033968140", image: phNwankpaOyeeImg },
      { name: "HRH EZE SIR NWANKWO NWANKWO", birthday: "14th July, 1952", award: "KJW", phone: "08035435889", image: phEzeNwankwoImg },
      { name: "SIR HON. NWIDADAH LEGBORSI", birthday: "25th December, 1960", award: "KJW", phone: "08036464472", image: phNwidadahLegborsiImg },
      { name: "SIR NWINANG SATURDAY BARIDA", birthday: "6th June, 1959", award: "KJW", phone: "08064205861", image: phNwinangSaturdayBaridaImg },
      { name: "SIR ENGR. NWOSUAGWU PETER", birthday: "21st August, 1944", award: "KJW", phone: "07032543634", image: phNwosuagwuPeterImg },
      { name: "SIR NZIDEE ADEBUE WILLIAMS", birthday: "10th October, 1969", award: "KJW", phone: "08037077629", image: phNzideeAdebueWilliamsImg },
      { name: "DAME NUNIEH GBENE JOI", birthday: "11th November, 1965", award: "KJW", phone: "08080444444", image: phNuniehGbeneJoiImg },
      { name: "VERY REV SIR OFOELUE NKEM", birthday: "15th May, 1966", award: "KCW", phone: "08023241451", image: phOfoelueNkemImg },
      { name: "EVANG. DR. SIR OGAMBA ADINDU", birthday: "12th September, 1960", award: "KJW", phone: "08022908427", image: phOgambaAdinduImg },
      { name: "SIR OGICHEN EMMANUEL POWER", birthday: "10th October, 1958", award: "KJW", phone: "08037057783", image: phOgichenEmmanuelPowerImg },
      { name: "SIR ARC. DR. OREREKE CHUKWUMA", birthday: "22nd February, 1963", award: "KJW", phone: "08033384725", image: phOkerekeChukwumaImg },
      { name: "DAME OMUNAKWE MILICENT", birthday: "18th July, 1967", award: "KJW", phone: "08034424878", image: phOmunakweMilicentImg },
      { name: "SIR ONONOGBU SUNNY", birthday: "16th August, 1960", award: "KJW", phone: "08099901406", image: phOnonogbuSunnyImg },
      { name: "SIR OSUNGWU ONYEMAECH", birthday: "5th November, 1962", award: "KJW", phone: "08033099926", image: phOsungwuOnyemaechiImg },
      { name: "SIR PUENE FINOR KEANIABARIDO", birthday: "18th September, 1938", award: "KJW", phone: "08037066421", image: phPueneFinorKeamiabaridoImg },
      { name: "SIR OTIKOR SAMUEL SANDERSON", birthday: "11th May, 1960", award: "KJW", phone: "08033396172", image: phOtikorSamuelSandersonImg },
      { name: "SIR CHIEF BARR. SAAGWE BRIGHTEN", birthday: "25th November, 1964", award: "KJW", phone: "08037879854", image: phSaagweBrightenImg },
      { name: "SIR CAPT. SMITH KEHINDE OLADAPO", birthday: "16th September, 1959", award: "KJW", phone: "08052365550", image: phSmithKehindeOladapoImg },
      { name: "SIR PROF. TORBIRA LEZAASI", birthday: "17th April, 1971", award: "KJW", phone: "08035464999", image: phTorbiraLezaasiImg },
      { name: "SIR PROF. UDEALA OLEKA", birthday: "28th September, 1939", award: "KJW", phone: "08035514488", image: phUdealaOlekaImg },
      { name: "SIR UDOH ELIJAH", birthday: "16th May, 1974", award: "KCW", phone: "08037058645", image: phUdohElijahImg },
      { name: "DAME UGOCHUKWU NGOZI NKECHINYERE", birthday: "8th June, 1962", award: "KJW", phone: "08033101138", image: phUgochukwuNgoziImg },
      { name: "SIR ENGR. UKPE AKPAN", birthday: "31st December, 1945", award: "KJW", phone: "08033596610", image: phUkpeAkpanImg },
      { name: "SIR ENGR. UMOREN UMOREN", birthday: "25th January, 1979", award: "KJW", phone: "08186886490", image: phUmorenUmorenImg },
      { name: "SIR SURV. UNO NDEKHEDEHE", birthday: "7th November, 1962", award: "KJW", phone: "08023288308", image: phUnoNdekhedeheImg },
      { name: "SIR DR. UWAGA UZOUKWU NELSON (MNI)", birthday: "2nd January, 1952", award: "KJW", phone: "08033089495", image: phUwagaUzoukwuNelsonImg },
      { name: "CHIEF SIR UWAKWE IKECHUKWU ISAIAH", birthday: "27th June, 1949", award: "KJW", phone: "08037711309", image: phUwakweIkechukwuImg },
      { name: "SIR VINCENT MICHAEL", birthday: "13th October, 1966", award: "KJW", phone: "08037902777", image: phVincentMichaelImg },
      { name: "SIR WICKLIFFE BANDELE", birthday: "31st October, 1958", award: "KJW", phone: "08033166610", image: phWickliffeBandeleImg },
    ],
  },
  kaduna: {
    name: "Kaduna",
    members: [
      { name: "SIR RASHEED OYESHOLA", birthday: "", award: "KJW", phone: "08173082851", position: "Chapter Chairman", image: portraits["kaduna-rasheed-oyeshola"] },
      { name: "SIR PROF. SODIPO OLUWOLE", birthday: "24th May, 1955", award: "KJW", phone: "08036000485" },
      { name: "DAME AYI NKESE", birthday: "17th January, 1952", award: "KJW", phone: "08036792785" },
      { name: "SIR DR. OKORONKWO SUNDAY NDUKA", birthday: "1962", award: "KJW", phone: "08033700533" },
      { name: "SIR CHIEF DR. ECHEONWU GEORGE-BEST", birthday: "12th July, 1953", award: "KJW", phone: "08033503715" },
      { name: "SIR OG WUCHE JOHN", birthday: "5th May, 1957", award: "KJW", phone: "08023740645", image: kadunaOgwucheImg },
      { name: "SIR OGILE SIMEON", birthday: "15th December, 1970", award: "KJW", phone: "08039272626", image: kadunaOgileImg },
      { name: "SIR OGBUKA OBIOHA", birthday: "20th November, 1966", award: "KJW", phone: "08036123309", image: kadunaOgbukaImg },
      { name: "SIR PHARM. ONOJA INNOCENT IDOKO", birthday: "5th September, 1966", award: "KJW", phone: "08036197750", image: kadunaOnojaImg },
      { name: "SIR OZOEMENA HYACINTH MADU", birthday: "25th February, 1964", award: "KJW", phone: "08036344934", image: kadunaOzoemenaImg },
      { name: "SIR DR ADEGBOYE RUFUS", birthday: "8th October, 1945", award: "KJW", phone: "08023355603", image: kadunaAdegboyeImg },
      { name: "DAME DEBORAH BOSAH OLUREMI", birthday: "8th February, 1957", award: "KJW", phone: "08028392151", image: kadunaBosahImg },
      { name: "SIR MBANASOR NNA MONDAY", birthday: "23rd September, 1945", award: "KJW", phone: "08034531691", image: kadunaMbanasorImg },
      { name: "DAME (BARR.) OSHUNTOYE OLUKEMI", birthday: "23rd January, 1963", award: "KJW", phone: "08037203730", image: kadunaOshuntoyeImg },
      { name: "SIR OGUNNAKE RECHARD ADENIYI", birthday: "15th June, 1939", award: "KJW", phone: "08034843572", image: kadunaOgunnakeImg },
      { name: "SIR OLANIYAN AKINTOYE JOSEPH", birthday: "12th June, 1975", award: "KJW", phone: "08036586379", image: kadunaOlaniyanImg },
      { name: "SIR (PROF.) UCHE OKORIE AUSTINE", birthday: "1st August, 1965", award: "KJW", phone: "08065416822", image: kadunaUcheImg },
      { name: "HRH. SIR EZE CHUKWUEMEKA SIMEON", birthday: "15th September, 1957", award: "KJW", phone: "08036240430", image: kadunaEzeImg },
    ],
  },
  benue: {
    name: "Benue",
    members: [
      { name: "SIR ELISHA YESUFU", birthday: "", award: "KJW", phone: "08022959833", position: "Chapter Chairman", image: portraits["benue-elisha-yesufu"] },
      { name: "DAME CAREW ENE VICTORIA", birthday: "22nd February, 1954", award: "KJW", phone: "08054178034" },
      { name: "DAME OBE STELLA", birthday: "20th February, 1950", award: "KJW", phone: "08060026026" },
      { name: "DAME AMARA DAVID", birthday: "14th October, 1955", award: "KJW", phone: "08053078151" },
      { name: "SIR ALACHI AKOR JOHN", birthday: "14th January, 1944", award: "KJW", phone: "08057430120" },
      { name: "SIR AMEH DANIEL ABAH, JP, FAG", birthday: "7th November, 1958", award: "KJW", phone: "07034675344" },
      { name: "SIR OCHELIYE AGBO BENSON", birthday: "24th October, 1949", award: "KJW", phone: "08039516948" },
      { name: "SIR LEORNARD LEONARD IDANTE", birthday: "21st September, 1981", award: "KCW", phone: "08063490321" },
      { name: "SIR AMEH JAMES", birthday: "20th August, 1974", award: "KJW", phone: "08076542925" },
      { name: "DAME ODOH COMFORT OJELA", birthday: "15th March, 1961", award: "KJW", phone: "08036249443" },
      { name: "DAME OMAFU JUDITH AWIDI, JP", birthday: "13th April, 1957", award: "KJW", phone: "07069229057" },
      { name: "DAME OTEIKWU VIVIAN, ANYOPE", birthday: "15th December, 1955", award: "KJW", phone: "08039559604" },
      { name: "SIR OIBIOKPA OMALE", birthday: "10th November, 1952", award: "KJW", phone: "07038159324" },
      { name: "SIR MADUBUIKE CHUKWUEMEKA O.", birthday: "2nd December, 1984", award: "KJW", phone: "08064048000" },
      { name: "SIR NGBEDE JOHN ILODU", birthday: "23rd October, 1962", award: "KJW", phone: "08034936906" },
      { name: "SIR UCHE SAMUEL", birthday: "14th January, 1979", award: "KJW", phone: "07038513877" },
      { name: "DAME OBE CAROLINE ALICE", birthday: "25th May, 1945", award: "KCW", phone: "07068186471" },
    ],
  },
  ifaki: {
    name: "Ifaki",
    members: [
      { name: "SIR CHIEF OSO BANKOLE FOLUSO", birthday: "20th October, 1951", award: "KJW", phone: "08035060755", position: "Chapter Chairman", image: portraits["ifaki-bankole-oso"] },
      { name: "SIR ORILOYE SUNDAY", birthday: "3rd September, 1948", award: "KCW", phone: "08062421641", image: ifakiOriloyeSundayImg },
      { name: "SIR OYATOYE PETER KAYODE", birthday: "3rd August, 1942", award: "KJW", phone: "08066497067", image: ifakiOyatoyePeterKayodeImg },
      { name: "SIR JOLAIYA ABRAHAM ADEMOLA", birthday: "17th May, 1957", award: "KJW", phone: "08060941881", image: ifakiJolaiyaAbrahamAdemolaImg },
      { name: "SIR PRINCE ESAN LANRE", birthday: "19th April, 1967", award: "KJW", phone: "08033157531", image: ifakiPrinceEsanLanreImg },
      { name: "SIR HON. AWODUMILA", birthday: "1949", award: "KJW", phone: "08038601707", image: ifakiHonAwodumilaImg },
      { name: "SIR FAKOREDE SAMSON", birthday: "9th November, 1959", award: "KJW", phone: "1-267-342", image: ifakiFakoredeSamsonImg },
      { name: "DAME ASIWAJU FAKOREDE COMFORT", birthday: "14th September, 1955", award: "KJW", phone: "267-250-1841", image: ifakiAsiwajuFakoredeComfortImg },
      { name: "DAME (EVANG) BABARINSA FLORENCE", birthday: "20th August, 1960", award: "KJW", phone: "08160387174", image: ifakiEvangBabarinsaFlorenceImg },
      { name: "SIR ENGR. DR BABARINSA FOLORUNSO", birthday: "21st October, 1950", award: "KJW", phone: "08033769653", image: ifakiEngrDrBabarinsaFolorunsoImg },
      { name: "SIR CHIEF OJO JOSEPH KAYODE", birthday: "12th July, 1947", award: "KJW", phone: "08034386761", image: ifakiChiefOjoJosephKayodeImg },
      { name: "SIR CHIEF AJIBEWA SAMUEL", birthday: "24th December, 1942", award: "KJW", phone: "08066036707", image: ifakiChiefAjibewaSamuelImg },
      { name: "SIR ALEMINU EMMANUEL OLUGBENGA", birthday: "", award: "KJW", phone: "", image: ifakiAleminuEmmanuelOlugbengaImg },
      { name: "SIR CHIEF MRS. AROGUNDADE CHRISTIANAH", birthday: "6th February, 1947", award: "KJW", phone: "08065259316", image: ifakiArogundadeChristianahOlayideImg },
      { name: "SIR FALANA EMMANUEL SUNDAY", birthday: "3rd March, 1963", award: "KJW", phone: "08033880410", image: ifakiFalanaEmmanuelSundayImg },
      { name: "SIR PRINCE FASIKU DAVID OMOLAYO", birthday: "17th September, 1959", award: "KJW", phone: "08033886808", image: ifakiPrinceFasikuDavidOmolayoImg },
      { name: "SIR CHIEF OLAJIDE AYODELE", birthday: "12th August, 1968", award: "KJW", phone: "08033869559", image: ifakiChiefOlajideAyodeleImg },
      { name: "DAME OGUNSHAKIN ADEBISI OLUBUKUNOLA", birthday: "11th February, 1953", award: "KJW", phone: "08033911481", image: ifakiOgunshakinAdebisiOlubukunolaImg },
      { name: "SIR CHIEF OSANYINLUSI OLASANMI", birthday: "15th September, 1936", award: "KJW", phone: "08138750544", image: ifakiChiefOsanyinlusiOlasanmiImg },
      { name: "SIR OJO ABIODUN", birthday: "24th March, 1964", award: "KJW", phone: "07032482116", image: ifakiOjoAbiodunImg },
      { name: "SIR STEPHEN JOHN", birthday: "1st August, 1944", award: "KJW", phone: "08056527631", image: ifakiStephenJohnImg },
      { name: "SIR GBADEOLA AYODEJI", birthday: "8th February, 1991", award: "KCW", phone: "08163707248", image: ifakiGbadeolaAyodejiImg },
      { name: "SIR OLALEYE GABRIEL OLUSHOLA", birthday: "12th January", award: "KJW", phone: "08033965739", image: ifakiOlaleyeGabrielOlusholaImg },
      { name: "SIR CHIEF OFERE ADEKANYE OLOTU", birthday: "21st August, 1947", award: "KJW", phone: "08034728252", image: ifakiChiefOfereAdekanyeOlotuImg },
      { name: "SIR JULIUS FEMI OLIYIDE", birthday: "8th January, 1952", award: "KJW", phone: "08033565921", image: ifakiJuliusFemiOliyideImg },
      { name: "SIR ADERINTO THOMAS ADEBOWALE", birthday: "24th October, 1944", award: "KJW", phone: "08035828637", image: ifakiAderintoThomasAdebowaleImg },
      { name: "SIR OLUBUMMO AKINBODE", birthday: "1st March, 1961", award: "KJW", phone: "08033354421", image: ifakiOlubummoAkinbodeImg },
      { name: "SIR OGUNTANA ALFRED TAIWO", birthday: "23rd August, 1947", award: "KJW", phone: "08058870036", image: ifakiOguntanaAlfredTaiwoImg },
      { name: "SIR FOLA BOLUMOLE OLAYINKA", birthday: "22nd December, 1953", award: "KJW", phone: "08037863296", image: ifakiFolaBolumoleOlayinkaImg },
      { name: "SIR CHIEF ONI OLUSEGUN", birthday: "5th September, 1954", award: "KJW", phone: "08075759105", image: ifakiChiefOniOlusegunImg },
      { name: "DAME BOLUMOLE MOPELOLA ADENIKE", birthday: "27th October, 1954", award: "KJW", phone: "08035849095", image: ifakiBolumoleMopelolaAdenikeImg },
      { name: "SIR ELDER OJO MOFIFOLUWASO", birthday: "10th April, 1961", award: "KJW", phone: "08033951362", image: ifakiElderOjoMofifoluwasoImg },
      { name: "SIR OMOLE AYODELE", birthday: "29th August, 1977", award: "KCW", phone: "08137766863", image: ifakiOmoleAyodeleImg },
      { name: "SIR ALUKO EMMANUEL OLUKAYODE", birthday: "1st October, 1960", award: "KJW", phone: "08032153087", image: ifakiAlukoEmmanuelOlukayodeImg },
      { name: "SIR CHIEF OJO GABRIEL AYODELE", birthday: "3rd February, 1933", award: "KJW", phone: "08067329843", image: ifakiChiefOjoGabrielAyodeleImg },
    ],
  },
  ilesa: {
    name: "Ilesa",
    members: [
      { name: "SIR ADEGBENGA ADEBUSUYI", birthday: "", award: "KJW", phone: "08034012560", position: "Chapter Chairman", image: portraits["ilesa-adegbenga-adebusuyi"] },
      { name: "SIR ADENIYI DEBORAH IYABOWALE APEKE", birthday: "24th May, 1947", award: "KJW", phone: "08037210586", image: ileshaAdeniyiDeborahIyabowaleApekeImg },
      { name: "DAME OBALEYE OLAYINKA EUNICE", birthday: "4th June, 1938", award: "KJW", phone: "08035015050", image: ileshaObaleyeOlayinkaEuniceImg },
      { name: "DAME ONI VICTORIA OREOLUWA", birthday: "15th April, 1956", award: "KJW", phone: "08033740176", image: ileshaOniVictoriaOreoluwaImg },
      { name: "DAME OYEDEJI MARY MODUPE", birthday: "1st November, 1941", award: "KJW", phone: "08036627459", image: ileshaOyedejiMaryModupeImg },
      { name: "DAME CHIEF ABIODUN STELLA EBUN", birthday: "4th August, 1949", award: "KJW", phone: "08033766744", image: ileshaChiefAbiodunStellaEbunImg },
      { name: "DAME EVANG. BABARINSA FLORENCE TITILAYO", birthday: "20th August, 1960", award: "KJW", phone: "08160387174", image: ileshaEvangBabarinsaFlorenceTitilayoImg },
      { name: "DAME CHIEF DR. FLORENCE FOLAMI-ADEOYE", birthday: "15th July, 1960", award: "KJW", phone: "07018988314", image: ileshaChiefDrFolamiAdeoyeFlorenceImg },
      { name: "DAME OMONIYI REBECCA OLUFUNKE", birthday: "26th April, 1945", award: "KJW", phone: "08033822238", image: ileshaOmoniyiRebeccaOlufunkeImg },
      { name: "DAME OSUNDARE OREOLUWA", birthday: "24th February, 1960", award: "KJW", phone: "08035852637", image: ileshaOsundareOreoluwaImg },
      { name: "DAME ASAOLU TOYIN ADETORERA FELICIA", birthday: "8th March", award: "KJW", phone: "08033791641", image: ileshaAsaoluToyinAdetoreraFeliciaImg },
      { name: "SIR ENGR. ONI DAVID", birthday: "7th June, 1955", award: "KJW", phone: "08025537892", image: ileshaEngrOniDavidImg },
      { name: "SIR DR. OPAKULE SUNDAY", birthday: "17th April, 1949", award: "KJW", phone: "08034006841", image: ileshaDrOpakuleSundayImg },
      { name: "SIR BABALOLA-OJO GBENGA, JP", birthday: "3rd August, 1957", award: "KJW", phone: "08025729838", image: ileshaBabalolaOjoGbengaImg },
      { name: "SIR CHIEF ALUKO OLATUNDE ISHOLA", birthday: "7th April, 1938", award: "KJW", phone: "08033036434", image: ileshaChiefAlukoOlatundeIsholaImg },
      { name: "SIR ADENIYI JOHNSON OBAFEMI", birthday: "1st January, 1942", award: "KJW", phone: "08037210586", image: ileshaAdeniyiJohnsonObafemiImg },
      { name: "SIR OLUWADAIRO OLABANJO", birthday: "23rd October, 1960", award: "KJW", phone: "08033274848", image: ileshaOluwadairoOlabanjoImg },
      { name: "SIR ENGR. OLAMIJULO BENJAMIN OLASUNKANMI", birthday: "16th February, 1962", award: "KJW", phone: "08033013336", image: ileshaEngrOlamijuloBenjaminOlasunkanmiImg },
      { name: "SIR AWOSULU EMMANUEL", birthday: "24th March, 1952", award: "KJW", phone: "08034717722", image: ileshaAwosuluEmmanuelImg },
      { name: "SIR FADAHUNSI OLADIPO", birthday: "8th January, 1934", award: "KCW", phone: "08067912102", image: ileshaFadahunsiOladipoImg },
      { name: "SIR HON. LONGE OLAOSEBIKAN", birthday: "18th January, 1945", award: "KJW", phone: "08034084656", image: ileshaHonLongeOlaosebikanImg },
      { name: "SIR FARODOYE OLUBUNMI", birthday: "4th July, 1961", award: "KJW", phone: "08066317611", image: ileshaFarodoyeOlubunmiImg },
      { name: "SIR PROF. ONAYADE ADEDEJI", birthday: "30th September, 1955", award: "KJW", phone: "08037184015", image: ileshaProfOnayadeAdedejiImg },
      { name: "SIR MORAKINYO FESTUS OLUSUJI", birthday: "23rd March, 1956", award: "KJW", phone: "07032042716", image: ileshaMorakinyoFestusOlusujiImg },
      { name: "SIR CHIEF BOLAJI OLATUNDE", birthday: "20th February, 1943", award: "KCW", phone: "07076300209", image: ileshaChiefBolajiOlatundeImg },
      { name: "SIR FADAIRO GABRIEL", birthday: "8th December, 1934", award: "KJW", phone: "08023518625", image: ileshaFadairoGabrielImg },
      { name: "SIR ENGR. OLOJO OLUFEMI", birthday: "28th November, 1936", award: "KJW", phone: "08037161518", image: ileshaEngrOlojoOlufemiImg },
      { name: "SIR PROF. BOLAJI OLOYEDE", birthday: "29th August, 1972", award: "KJW", phone: "0807900913", image: ileshaProfBolajiOloyedeImg },
      { name: "SIR OSEDAHUNSI JAMES ADEMOLA SUNDAY", birthday: "21st May, 1959", award: "KJW", phone: "08033916087", image: ileshaOsedahunsiJamesAdemolaSundayImg },
      { name: "SIR DR. SASEUN CLEMENT ADEREMI", birthday: "12th August, 1952", award: "KJW", phone: "+1909-376-1170", image: ileshaDrSaseunClementAderemiImg },
      { name: "SIR CHIEF AKINLEYE ISAAC", birthday: "8th December, 1959", award: "KJW", phone: "08033698138", image: ileshaChiefAkinleyeIsaacImg },
      { name: "SIR ENGR. FASHADE ADEBAYO", birthday: "5th July, 1946", award: "KJW", phone: "07057566055", image: ileshaEngrFashadeAdebayoImg },
      { name: "SIR AKINBADE OLUTAYO", birthday: "12th August, 1965", award: "KCW", phone: "08063479365", image: ileshaAkinbadeOlutayoImg },
      { name: "SIR ENGR. FARINRE ISAAC", birthday: "10th October, 1949", award: "KJW", phone: "08037170510", image: ileshaEngrFarinreIsaacImg },
    ],
  },
  enugu: {
    name: "Enugu",
    members: [
      { name: "SIR LAZARUS ANI", birthday: "4th July, 1958", award: "KCW", phone: "08052238127", position: "Chapter Chairman", image: portraits["enugu-lazarus-ani"] },
      { name: "SIR ELOM JOHN OKABE", birthday: "26th June, 1956", award: "KJW", phone: "08134287055", image: enuguElomJohnOkabeImg },
      { name: "SIR ANIAGU DAVID NGENE", birthday: "2nd January, 1945", award: "KJW", phone: "08066565418", image: enuguAniaguDavidNgeneImg },
      { name: "SIR (H.R.H. IGWE EZEUDO) NWOBODO ABEL OGBONNAYA", birthday: "29th November, 1932", award: "KJW", phone: "08033420022", image: enuguNwobodoAbelOgbonnayaImg },
      { name: "SIR DR. ONYEBUCHI AZUBUIKE KANARIO", birthday: "21st August, 1971", award: "KJW", phone: "08037227636", image: enuguOnyebuchiAzubuikeKanarioImg },
      { name: "SIR UCHE JAMES IFUNANYA CHUKWU", birthday: "29th March, 1976", award: "KJW", phone: "08034060575", image: enuguUcheJamesIfunanyaChukwuImg },
      { name: "SIR UKAOGO NWABUEZE", birthday: "22nd January, 1957", award: "KJW", phone: "08023264366" },
      { name: "DAME NNAMANI CHINENYE PATRICIA, JP", birthday: "31st December, 1959", award: "KCW", phone: "08033680442", image: enuguNnamaniChinenyePatriciaImg },
      { name: "SIR ENGR. OKORIE CHARLES", birthday: "20th October, 1958", award: "KJW", phone: "08033399594", image: enuguOkorieCharlesImg },
      { name: "SIR AGBO VICTOR OGUEJIOFO", birthday: "7th November, 1959", award: "KJW", phone: "08036871979", image: enuguAgboVictorOguejiofoImg },
      { name: "SIR AVAH STEPHEN", birthday: "29th September, 1957", award: "KJW", phone: "08035899780", image: enuguAvahStephenImg },
      { name: "SIR NWODO ONU", birthday: "8th February, 1969", award: "KJW", phone: "08033458677", image: enuguNwodoOnuImg },
      { name: "SIR ATUONWU NNANNA VICTOR", birthday: "22nd September, 1961", award: "KJW", phone: "08137554852", image: enuguAtuonwuNnannaVictorImg },
      { name: "SIR EDE OKAFOR", birthday: "22nd April, 1945", award: "KJW", phone: "08035909509", image: enuguEdeOkaforImg },
      { name: "SIR DR. HUMFREY EZUMA", birthday: "22nd November, 1939", award: "KJW", phone: "07080242866", image: enuguEzumahHumphreyImg },
      { name: "SIR DR. AGWU EMEKA EZEKIEL", birthday: "23rd August, 1957", award: "KJW", phone: "08032826932", image: enuguAgwuEmekaEzekielImg },
      { name: "SIR OGBONNA CHINONYEREM JOE", birthday: "22nd August, 1956", award: "KJW", phone: "08035792330", image: enuguOgbonnaChinonyeremJoeImg },
      { name: "SIR EJIMS DIEWAIT OKECHUKWU", birthday: "15th September, 1958", award: "KJW", phone: "08036759943", image: enuguEjimsDiewaitOkechukwuImg },
      { name: "SIR ENGR. OGBODO DONATUS OKEKE", birthday: "1st September, 1964", award: "KJW", phone: "08033388371", image: enuguOgbodoDonatusOkekeImg },
      { name: "SIR CHUKWUEMERIE EMMANUEL IKECHUKWU", birthday: "13th January, 1964", award: "KJW", phone: "08037001629", image: enuguChukwuemerieEmmanuelIkechukwuImg },
      { name: "SIR OSELEBE EZE", birthday: "1955", award: "KJW", phone: "08153552966", image: enuguOselebeEzeImg },
      { name: "SIR DR. ANINWENE EMMANUEL ODIONYENFE", birthday: "28th July", award: "KCW", phone: "07037822520", image: enuguAninweneEmmanuelOdionyenfeImg },
      { name: "SIR NWAULO ONYEKACHI PROMISE", birthday: "24th April, 1978", award: "KJW", phone: "08033422868", image: enuguNwauloOnyekachiPromiseImg },
      { name: "SIR ONU VINCENT UCHE", birthday: "14th December, 1958", award: "KJW", phone: "08039640493", image: enuguOnuVincentUcheImg },
      { name: "SIR NWATU GODWIN", birthday: "27th August, 1957", award: "KJW", phone: "08035505009", image: enuguNwatuGodwinImg },
      { name: "SIR AGBO EMMANUEL", birthday: "28th July, 1958", award: "KJW", phone: "08037049414", image: enuguAgboEmmanuelImg },
      { name: "SIR MBA DOUGLAS IFEANYI, JP", birthday: "24th October, 1956", award: "KJW", phone: "08033234623", image: enuguMbaDouglasIfeanyiImg },
      { name: "SIR ONAH IKECHUKWU", birthday: "3rd August, 1963", award: "KJW", phone: "08033392104", image: enuguOnahIkechukwuImg },
      { name: "SIR ONOH JOHN", birthday: "", award: "KJW", phone: "", image: enuguOnohJohnImg },
      { name: "SIR UBA OBASIKWE NGOZICHUKWU", birthday: "1st July, 1966", award: "KJW", phone: "08034717124", image: enuguUbaObasikweNgozichukwuImg },
      { name: "SIR ONWE CHUKWUKA", birthday: "14th May, 1959", award: "KCW", phone: "08037726986", image: enuguOnweChukwukaImg },
      { name: "SIR OGBONNACHUKWU OBI KENNETH", birthday: "7th September, 1970", award: "KJW", phone: "08033427942", image: enuguOgbonnachukwuObiKennethImg },
      { name: "SIR ASIEGBU UZOECHI WILLINGTON", birthday: "30th April, 1977", award: "KJW", phone: "08033133082", image: enuguAsiegbuUzoechiWillingtonImg },
      { name: "SIR IKPEGBU SUNDAY OKECHUKWU", birthday: "24th March, 1974", award: "KJW", phone: "07069306956", image: enuguIkpegbuSundayOkechukwuImg },
      { name: "SIR OKPEH SUNDAY", birthday: "16th March, 1963", award: "KJW", phone: "08036225121", image: enuguOkpehSundayImg },
      { name: "SIR OKENWA-ANI ANTHONY CHUKWUKA", birthday: "26th April, 1954", award: "KJW", phone: "08063581461", image: enuguOkenwaAniAnthonyChukwukaImg },
      { name: "SIR OHAA CHINYEAKA CHRISTIAN", birthday: "4th February, 1961", award: "KJW", phone: "08033166249", image: enuguOhaaChinyeakaImg },
      { name: "SIR NWABUEZE AMECHI AGAH C.", birthday: "22nd November, 1967", award: "KJW", phone: "08033048536", image: enuguNwabuezeAmechiAgahImg },
      { name: "SIR MBADUGHA EKWEBELLAM NWANKWO", birthday: "1946", award: "KJW", phone: "08122101298", image: enuguMbadughaEkwebellemNwankwoImg },
      { name: "SIR NWAFOR GODWIN OKECHUKWU", birthday: "24th June, 1962", award: "KJW", phone: "08034237239", image: enuguNwaforGodwinOkechukwuImg },
      { name: "SIR EGBO OGUEJI", birthday: "29th December, 1967", award: "KJW", phone: "08033215090", image: enuguEgboOguejiImg },
      { name: "SIR AKAEME IFEANYI CHRISTIAN", birthday: "3rd March, 1972", award: "KJW", phone: "08033270890", image: enuguAkaemeIfeanyiChristianImg },
      { name: "DAME ORURUO IFEOMA", birthday: "1967", award: "KJW", phone: "08063633278", image: enuguOruruoIfeomaImg },
      { name: "SIR OSITA HUMPHREY", birthday: "19th November, 1978", award: "KJW", phone: "08035590086", image: enuguOsitaHumphreyImg },
      { name: "SIR NWOKOCHA DICKSON", birthday: "15th March, 1953", award: "KJW", phone: "08064773909", image: enuguNwokochaDicksonImg },
      { name: "SIR ANI EMMANUEL", birthday: "9th November, 1940", award: "KJW", phone: "08033582643", image: enuguAniEmmanuelImg },
      { name: "SIR NNAMDI FIDELIS OGBU", birthday: "15th June, 1956", award: "KJW", phone: "08033655070", image: enuguNnamchiFidelisOgbuImg },
      { name: "SIR UKORO ONYEMAECHI BONIFACE", birthday: "3rd July, 1967", award: "KJW", phone: "08033972437", image: enuguUkoroOnyemaechiBonifaceImg },
      { name: "SIR CHUKWUKEZIRI UGOGBUZUO MELFORO ELIAS", birthday: "12th August, 1958", award: "KJW", phone: "08034065178", image: enuguChukwukeziriUgogbuzuoMelfordEliasImg },
      { name: "SIR UGWUEDO JOSEPH OKONKWO", birthday: "4th May, 1947", award: "KJW", phone: "08063855316", image: enuguUgwuodoJosephOkonkwoImg },
      { name: "SIR OGBONNA EDWIN", birthday: "25th August, 1949", award: "KJW", phone: "08033125243", image: enuguOgbonnaEdwinImg },
      { name: "SIR NNEJI JOHN", birthday: "3rd April, 1955", award: "KJW", phone: "08033359928", image: enuguNnejiJohnImg },
      { name: "SIR ANYA JOSEPH IDIKA", birthday: "15th September", award: "KJW", phone: "08036855428", image: enuguAnyaJosephIdikaImg },
      { name: "SIR NNAMANI SAMPSON CHIKWENDU", birthday: "3rd September, 1948", award: "KJW", phone: "08037421074", image: enuguNnamaniSampsonChikwenduImg },
      { name: "SIR EVANG. EZOH OGBAJIE E.", birthday: "8th April, 1955", award: "KJW", phone: "08037795853", image: enuguEzohEzonuOgbajieImg },
      { name: "SIR NNAMANI NWABUEZE", birthday: "22nd February, 1954", award: "KJW", phone: "08033066361", image: enuguNnamaniNwabuezeImg },
      { name: "SIR OGBODO DAVID", birthday: "13th October, 1950", award: "KJW", phone: "08033111743", image: enuguOgbodoDavidImg },
    ],
  },
  "ikot-ekpene": {
    name: "Ikot-Ekpene",
    members: [
      { name: "SIR PROF. IDOREYIN UMOH", birthday: "17th January, 1959", award: "KJW", phone: "08036743886", position: "Chapter Chairman", image: portraits["ikot-ekpene-idoreyin-umoh"] },
      { name: "SIR SURV. ESSIEN DAVID", birthday: "16th June, 1956", award: "KJW", phone: "08038750858", image: essienDavidImg },
      { name: "SIR HON. BARTEPEH", birthday: "16th January, 1954", award: "KJW", phone: "08033932788", image: bartepehGodfreyImg },
      { name: "SIR ENGR. UMOENANG AKPAN A.", birthday: "31st December, 1943", award: "KJW", phone: "08065160088", image: umoenangAkpanImg },
      { name: "SIR UMOESSIEN ANIEKAN JOHNSON", birthday: "31st December, 1981", award: "KJW", phone: "08036752663", image: umoessienAniekanImg },
      { name: "SIR AKPABIO UKEME-OBONG", birthday: "30th December, 1975", award: "KCW", phone: "08032440407", image: akpabioUkemeImg },
      { name: "SIR USEN EKERE JAMES", birthday: "19th February, 1950", award: "KJW", phone: "08027393628", image: usenEkereJamesImg },
      { name: "VERY REV SIR PROF. UDOH ISAAC", birthday: "17th December, 1962", award: "KCW", phone: "08037800907", image: udohIsaacImg },
      { name: "SIR PROF. EBONG VICTOR", birthday: "14th May, 1961", award: "KJW", phone: "08068416783", image: ebongVictorImg },
      { name: "SIR PROF. ESSIET ANIESUA", birthday: "29th July, 1963", award: "KJW", phone: "08068400039", image: essiettAniesuaImg },
      { name: "SIR TPL. EBONG SAMUEL", birthday: "13th May, 1964", award: "KCW", phone: "08023621793", image: ebongSamuelImg },
      { name: "SIR EKONG USORO", birthday: "31st December, 1958", award: "KJW", phone: "08035702365", image: ekongUsoroImg },
      { name: "SIR ESV. USORO USORO OKON", birthday: "22nd May, 1962", award: "KJW", phone: "08022910831", image: usoroOkonImg },
      { name: "SIR ENGR. USORO ERNEST", birthday: "29th April, 1954", award: "KJW", phone: "08037514064", image: usoroErnestImg },
      { name: "DAME OBONGAINAN ETTETE EDITH ENO", birthday: "27th April, 1949", award: "KJW", phone: "08023573794", image: obongawanEtteteImg },
      { name: "SIR DR. AKPAN EMMANUEL", birthday: "20th July, 1954", award: "KJW", phone: "07068672817", image: akpanEmmanuelImg },
      { name: "SIR AKPAN UDO KIERIAN", birthday: "4th May, 1962", award: "KJW", phone: "08037757931", image: akpanUdoKierianImg },
    ],
  },
  calabar: {
    name: "Calabar",
    members: [
      { name: "SIR ENGR. EKPENYONG EKPENYONG", birthday: "", award: "KJW", phone: "08037080960", position: "Chapter Chairman", image: portraits["calabar-ekpenyong-ekpenyong"] },
      { name: "SIR EWA ALDERTON", birthday: "29th September, 1954", award: "KJW", phone: "08037107850", image: ewaAldertonImg },
      { name: "DAME BASSEY IQUO", birthday: "23rd March, 1943", award: "KCW", phone: "08155730154", image: basseyIquoImg },
      { name: "DAME ESTHER EKANEM", birthday: "4th November, 1951", award: "KJW", phone: "08036004693", image: estherEkanemImg },
      { name: "SIR BASSEY OQUA", birthday: "2nd February, 1977", award: "KCW", phone: "08036744257", image: basseyOquaImg },
      { name: "SIR ASANGANSI EFFIONG", birthday: "20th July, 1949", award: "KJW", phone: "08025201394", image: asangansiEffiongImg },
    ],
  },
  okigwe: {
    name: "Okigwe",
    members: [
      { name: "SIR MONDAY UDEOGU", birthday: "18th November, 1948", award: "KJW", phone: "08038865956", position: "Chapter Chairman", image: portraits["okigwe-monday-udeogu"] },
      { name: "SIR OBI FRANCIS CHIJIOKE", birthday: "20th December, 1960", award: "KJW", phone: "08037364264", image: okigweObiFrancisImg },
      { name: "SIR HIGH CHIEF IROESOGBUSI ABEL", birthday: "25th March, 1944", award: "KJW", phone: "08037943003", image: okigweIroesogbusiAbelImg },
      { name: "SIR NWOKE EMMANUEL MADUAKOLAM", birthday: "12th April, 1958", award: "KJW", phone: "08037890543", image: okigweNwokeEmmanuelImg },
      { name: "SIR ONYEABO REUBEN NWABUIKWU", birthday: "24th October, 1942", award: "KJW", phone: "08035897930", image: okigweOnyeaboReubenImg },
      { name: "SIR MBA SUNDAY NWACHUKWU", birthday: "21st October, 1945", award: "KCW", phone: "08151231995", image: okigweMbaSundayImg },
      { name: "SIR ODOEMELEM CHINEDUM", birthday: "2nd February, 1954", award: "KCW", phone: "08038133540", image: okigweOdoemelemChinedumImg },
      { name: "SIR UCHE UCHE ALBERT", birthday: "9th January, 1948", award: "KJW", phone: "08124068269", image: okigweUcheAlbertImg },
      { name: "SIR KANU CHIDIEBERE N.", birthday: "15th November, 1974", award: "KCW", phone: "09036026395", image: okigweKanuChidiebereImg },
      { name: "SIR ELDER EKE STANLEY ONYEOGADIRIMMA", birthday: "13th March, 1958", award: "KJW", phone: "08037829728", image: okigweEkeStanleyImg },
      { name: "SIR DR. AGU CHIBUEZE", birthday: "17th March, 1949", award: "KJW", phone: "08032504446", image: okigweAguChibuezeImg },
      { name: "SIR PRINCE BARR. NWOKORO EBERE", birthday: "24th April, 1968", award: "KJW", phone: "08033000549", image: okigweNwokoroEbereImg },
      { name: "SIR NDUBUISI UKACHUKWU", birthday: "7th August, 1951", award: "KCW", phone: "08126831734", image: okigweNdubuisiUkachukwuImg },
      { name: "SIR IBEAJA EZE SUNDAY", birthday: "12th December, 1957", award: "KJW", phone: "08035941141", image: okigweIbeajaEzeSundayImg },
      { name: "SIR BARR. OBIGWE OKWUDIRI", birthday: "30th July, 1975", award: "KJW", phone: "08033121407", image: okigweObigweOkwudiriImg },
      { name: "SIR ELDER CHIBUEZEH LINUS OBIEREZIE", birthday: "9th June, 1960", award: "KJW", phone: "08136047118", image: okigweChibuezehLinusImg },
      { name: "SIR IKPO UCHE M.", birthday: "30th November, 1964", award: "KJW", phone: "08039379747", image: okigweIkpoUcheImg },
      { name: "SIR ONYECHERE UCHECHUKWU C.", birthday: "25th March, 1953", award: "KJW", phone: "08065243404", image: okigweOnyechereUchechukwuImg },
      { name: "SIR HON. ASIEGBU HENRY I.", birthday: "30th September, 1974", award: "KJW", phone: "08035815820", image: okigweAsiegbuHenryImg },
      { name: "SIR OBIAKA EZINWA AARON", birthday: "10th October, 1932", award: "KJW", phone: "07012214615", image: okigweObiakaEzinwaImg },
      { name: "SIR BLDR. EZE EUGENE", birthday: "25th June, 1959", award: "KJW", phone: "08035201861", image: okigweEzeEugeneImg },
      { name: "SIR ENGR. OBIJIAKU GODDY OKORIE", birthday: "31st August, 1968", award: "KJW", phone: "08037035571", image: okigweObijiakuGoddyImg },
      { name: "SIR ENGR. ONYEARUGHA IKEMEFULE CHUKWUONYE", birthday: "14th January, 1955", award: "KJW", phone: "08089118888", image: okigweOnyearughaIkemefuleImg },
      { name: "DAME (DR. MRS.) ONYEARUGHA IHUOMA", birthday: "25th March, 1959", award: "KJW", phone: "08126065913", image: okigweOnyearughaIhuomaImg },
      { name: "SIR EME AMARACHUKWU FRANK", birthday: "16th February, 1975", award: "KJW", phone: "08037768328", image: okigweEmeAmarachukwuImg },
      { name: "SIR OFOEGBU KENNETH", birthday: "October, 1946", award: "KJW", phone: "0803392786", image: okigweOfoegbuKennethImg },
      { name: "SIR UGWA DENNIS I.", birthday: "15th October, 1946", award: "KJW", phone: "08039626833", image: okigweUgwaDennisImg },
      { name: "SIR CHIEF IHERE GODWIN", birthday: "30th November, 1958", award: "KJW", phone: "08165193715", image: okigweIhereGodwinImg },
      { name: "SIR CHIEF AJALA VINCENT UCHE", birthday: "", award: "KJW", phone: "08083841442", image: okigweAjalaVincentImg },
      { name: "SIR ONWUCHEKWA GODSWILL OKOROAFOR", birthday: "15th June, 1949", award: "KJW", phone: "08037447850", image: okigweOnwuchekwaGodswillImg },
      { name: "SIR PROF. OJUKWU ERNEST", birthday: "", award: "KJW", phone: "08034028676", image: okigweOjukwuErnestImg },
      { name: "SIR ARC. ONWUCHEKWA SUNNY", birthday: "22nd August, 1949", award: "KJW", phone: "08033332318" },
      { name: "SIR H.R.H OYORO PRINCE NDUBUISI", birthday: "4th May, 1975", award: "KJW", phone: "", image: okigweOyoroNdubuisiImg },
      { name: "SIR PROF. UKEJE CHARLES UGOCHUKWU", birthday: "17th September, 1967", award: "KJW", phone: "08037304700", image: okigweUkejeCharlesImg },
      { name: "SIR H.R.H. EZE IKWULAGU CHIGBU", birthday: "27th November, 1950", award: "KJW", phone: "08036751337", image: okigweEzeIkwulaguImg },
      { name: "SIR NWEKE JOHNSON", birthday: "17th June, 1976", award: "KJW", phone: "08166447463" },
      { name: "SIR PROF. NWOKOCHA LEVI K.", birthday: "", award: "KJW", phone: "08068448440" },
      { name: "SIR ARC. CHIEF CHIBUIKE EXCELLENTIME", birthday: "2nd June, 1977", award: "KJW", phone: "08067070700", image: okigweChijiChibuikeImg },
      { name: "SIR DR. UWAEZUOKE AMOBI IFEANYICHUKWU", birthday: "20th January, 1956", award: "KJW", phone: "08068918811", image: okigweUwaezuokeAmobiImg },
      { name: "SIR BARR. NGWU CHUKWUEMEKA", birthday: "23rd November, 1962", award: "KJW", phone: "08036214444", image: okigweNgwuChukwuemekaImg },

    ],
  },
  riye: {
    name: "RIYE",
    members: [
      { name: "SIR OLANIYI OLATIDOYE", birthday: "30th July, 1949", award: "KJW", phone: "08033351744", position: "Chapter Chairman", image: portraits["riye-niyi-olatidoye"] },
      { name: "SIR SHOYEMI ABAYOMI FEMI", birthday: "25th September, 1943", award: "KJW", phone: "08065422373" },
      { name: "SIR SOYEBO STEVENSON BABATUNDE OLUFEMI", birthday: "10th July, 1927", award: "KJW", phone: "08023193726", image: riyeSoyeboStevensonImg },
      { name: "SIR OGUNSANWO ADEBOLA", birthday: "11th January, 1946", award: "KJW", phone: "08032417142", image: riyeOgunsanwoAdebolaImg },
      { name: "SIR OGUNGBE SAMUEL OLUGBEMI", birthday: "11th July, 1941", award: "KJW", phone: "08066998473", image: riyeOgungbeSamuelImg },
      { name: "DAME OGUNGBE MOJISOLA OLUYEMISI", birthday: "19th September, 1947", award: "KJW", phone: "08070438710", image: riyeOgungbeMojisolaImg },
      { name: "SIR ASHAYE ADEKOLA", birthday: "19th December, 1942", award: "KJW", phone: "08076869992", image: riyeAshayeAdekolaImg },
      { name: "DAME ADESEUN FEHINTOLA OLUYEMISI", birthday: "28th March, 1959", award: "KJW", phone: "08035631221", image: riyeAdeseunFehintolaImg },
      { name: "DAME OLAPADE OLATOKUNBO", birthday: "28th August, 1953", award: "KJW", phone: "08033189893", image: riyeOlapadeOlatokunboImg },
      { name: "SIR SONAIKE FESTUS", birthday: "10th June, 1933", award: "KJW", phone: "08037193201", image: riyeSonaikeFestusImg },
      { name: "SIR ODULATE IYABODE", birthday: "24th May, 1952", award: "KJW", phone: "080355507176", image: riyeOdulateIyabodeImg },
      { name: "SIR EPEGA OBARINSOLA", birthday: "13th November, 1957", award: "KJW", phone: "08023139526", image: riyeEpegaObarinsolaImg },
      { name: "DAME LEGUNSEN DORIS", birthday: "4th July, 1948", award: "KJW", phone: "08038289774", image: riyeLegunsenDorisImg },
      { name: "SIR OGUNYOLU ALBERT", birthday: "14th March, 1945", award: "KJW", phone: "08023328357", image: riyeOgunyoluAlbertImg },
      { name: "SIR SOYOMBO MOSES", birthday: "26th August, 1949", award: "KJW", phone: "08033798778", image: riyeSoyomboMosesImg },

      { name: "SIR SOYOMBO SOSINMI OLAJIDE", birthday: "31st March, 1980", award: "KCW", phone: "08139612565", image: riyeSoyomboSosinmiImg },
      { name: "SIR JACOBS CHARLES OLUREMI", birthday: "19th September, 1946", award: "KJW", phone: "08035550146", image: riyeJacobsCharlesImg },
      { name: "SIR SOMOYE OLALEYE ADIO", birthday: "16th November, 1939", award: "KJW", phone: "08033060678", image: riyeSomoyeOlaleyeImg },
      { name: "SIR SHOMOYE JOSEPH ADELANI", birthday: "1st July, 1953", award: "KJW", phone: "08033188614", image: riyeShomoyeJosephImg },
      { name: "SIR OGUNFOWORA OLUGBOYEGA", birthday: "6th February, 1966", award: "KJW", phone: "08037183875", image: riyeOgunfoworaOlugboyegaImg },
      { name: "SIR OREDIPE AYOTUNDE GBENGA", birthday: "27th November, 1954", award: "KJW", phone: "08033444306", image: riyeOredipeAyotundeImg },
      { name: "DAME ASHAYE JOSEPHINE OLABISI", birthday: "17th January, 1946", award: "KJW", phone: "08037331387", image: riyeAshayeJosephineImg },
      { name: "SIR EDUN TAIWO", birthday: "25th April, 1964", award: "KJW", phone: "08033428770", image: riyeEdunTaiwoImg },
      { name: "DAME ONAEKO FOLASADE, JP", birthday: "19th March, 1961", award: "KJW", phone: "08028331109", image: riyeOnaekoFolasadeImg },
      { name: "SIR ATINMO FASTOLA", birthday: "29th January, 1945", award: "KJW", phone: "08023245055", image: riyeAtinmoFastolaImg },
      { name: "SIR OYEGUNLE MUFTAU", birthday: "23rd June, 1960", award: "KJW", phone: "08022238653", image: riyeOyegunleMuftauImg },
      { name: "SIR CHIEF OYESOLA OLUJARE", birthday: "21st March, 1955", award: "KJW", phone: "08060060642", image: riyeOyesolaOlujareImg },
      { name: "SIR OGUNBO OLUMIDE", birthday: "21st July, 1974", award: "KJW", phone: "08035020870", image: riyeOgunboOlumideImg },
      { name: "DAME OLUGBEMI OMOLOLA OLUBUKOLA", birthday: "20th February, 1960", award: "KJW", phone: "08033263164", image: riyeOlugbemiOmololaImg },
      { name: "DAME DAWODU EBUNOLA", birthday: "22nd February, 1952", award: "KJW", phone: "08033585029", image: riyeDawoduEbunolaImg },
      { name: "SIR JEMIRI MOSES OLUSOLA", birthday: "17th July, 1936", award: "KJW", phone: "08034032215", image: riyeJemiriMosesImg },
      { name: "SIR SOYEWO FEYISAYO", birthday: "24th September, 1950", award: "KJW", phone: "08033075730", image: riyeSoyewoFeyisayoImg },
      { name: "SIR ADELUOLA CHARLES OLALEKAN", birthday: "7th February, 1955", award: "KJW", phone: "07089710978", image: riyeAdeluolaCharlesImg },
      { name: "DAME ODEDELE TITILOLA", birthday: "21st September, 1954", award: "KJW", phone: "08128780215", image: riyeOdedeleTitilolaImg },
      { name: "SIR ADEITAN ADEYEMI W.", birthday: "4th March, 1961", award: "KJW", phone: "08034732248", image: riyeAdeitanAdeyemiImg },
      { name: "SIR MARAIYE SA JACOB", birthday: "19th April, 1954", award: "KJW", phone: "09065006748", image: riyeMaraiyesaJacobImg },

      { name: "DAME OSHIN TITLAYO", birthday: "19th October, 1960", award: "KJW", phone: "08028374666", image: riyeOshinTitlayoImg },
      { name: "DAME OLORI ADESANYA ADEFOLARANMI OLUDAYO", birthday: "2nd November, 1934", award: "KJW", phone: "08023271685", image: riyeOloriAdesanyaImg },
      { name: "SIR SAMSON ADEKOYA ABASS", birthday: "7th July, 1931", award: "KJW", phone: "08037267738", image: riyeSamsonAdekoyaImg },
      { name: "SIR AWOFALA EMMANUEL", birthday: "16th July, 1932", award: "KJW", phone: "08037255846" },
      { name: "SIR BAIYEWU SUNDAY", birthday: "22nd July, 1956", award: "KJW", phone: "08080545656", image: riyeBaiyewuSundayImg },
      { name: "SIR BANJOKO OLUFEMI ADEMOLA", birthday: "26th March, 1943", award: "KJW", phone: "08023046055", image: riyeBanjokoOlufemiImg },
      { name: "SIR LEGUNSEN MACAULAY", birthday: "21st May, 1942", award: "KJW", phone: "08033373804", image: riyeLegunsenMacaulayImg },
      { name: "SIR ONABANJO OLADIPO", birthday: "10th October, 1944", award: "KJW", phone: "08033076880" },
      { name: "SIR OREMOSU MABAYOJE", birthday: "10th July, 1936", award: "KJW", phone: "08033803457" },
      { name: "SIR SONOIKI ALFRED OLADEJI", birthday: "6th March, 1941", award: "KJW", phone: "08023115261", image: riyeSonoikiAlfredImg },
      { name: "SIR OSINOIKI KOLA", birthday: "17th July, 1937", award: "KJW", phone: "08052073229", image: riyeOsinoikiKolaImg },
      { name: "SIR SHITU RICHARD ADEYEMI", birthday: "16th August, 1943", award: "KJW", phone: "08052400097", image: riyeShituRichardImg },
      { name: "SIR SHODA EMMA", birthday: "12th July, 1950", award: "KJW", phone: "08033433393", image: riyeShodaEmmaImg },
      { name: "SIR CHIEF DR. SOLESI DAVID KOLAWOLE", birthday: "16th July, 1930", award: "KJW", phone: "08037232215", image: riyeSolesiDavidImg },
      { name: "SIR SONOYA MICHAEL OLUSEGUN", birthday: "16th February, 1947", award: "KJW", phone: "08023050067", image: riyeSonoyaMichaelImg },
      { name: "DAME ODOFUWA OLUBUNMI", birthday: "15th May, 1966", award: "KJW", phone: "07064175787", image: riyeOdofuwaOlubunmiImg },
      { name: "SIR OSHIDEKO FESTUS OPEOLUWA", birthday: "22nd July, 1944", award: "KJW", phone: "08023106371", image: riyeOshidekoFestusImg },

    ],
  },
  igbobini: {
    name: "Igbobini",
    members: [
      { name: "SIR AKINMOJU MARTINS OYEWUNMI", birthday: "18th September, 1958", award: "KJW", phone: "08066504331", position: "Chapter Chairman", image: portraits["igbobini-oyewumi-akinmoju"] },
      { name: "SIR FALANA RUFUS", birthday: "25th September, 1951", award: "KJW", phone: "08034717286", image: falonaRufusImg },
      { name: "DAME AKINMOJU IYEWUMI", birthday: "3rd March, 1963", award: "KCW", phone: "07032988137", image: chapterPortraits["igbobini/akinmoju-iyewumi"] },
      { name: "SIR ADELAKUN FOLUSO AYODEJI", birthday: "10th March, 1953", award: "KJW", phone: "08038492556", image: adelakunAyodejiImg },
      { name: "DAME MESAGAN SUSANNAH DEBORAH", birthday: "24th April, 1957", award: "KJW", phone: "08053686720", image: mesaganDeborahImg },
      { name: "SIR (BARR.) ADETUYI SAMUEL", birthday: "9th September, 1947", award: "KJW", phone: "08263062299", image: chapterPortraits["igbobini/adetuyi-samuel"] },
      { name: "CHIEF SIR OMOGOROYE IGBEKELA", birthday: "2nd February, 1946", award: "KJW", phone: "08037252603", image: chapterPortraits["igbobini/omogoroye-igbekela"] },
      { name: "SIR CHIEF DR. OBIDEYI SAMUEL", birthday: "14th February, 1956", award: "KCW", phone: "08035639344", image: chapterPortraits["igbobini/obideyi-olu-samuel"] },
      { name: "SIR AROWOYE ROBERT AKINOLA", birthday: "20th October, 1935", award: "KCW", phone: "08074824935", image: arowoyeleRobertImg },
      { name: "SIR DR. OLAKUNDE MOSES OLUWOLE", birthday: "15th April, 1952", award: "KJW", phone: "080359559807", image: olakunleMosesImg },
      { name: "SIR OMOFIOYE OYEDELE ERNEST", birthday: "7th November, 1955", award: "KJW", phone: "08035904785", image: chapterPortraits["igbobini/omofioye-oyedele-ernest"] },
      { name: "DAME JUBA STELLA OLUREMI", birthday: "4th April, 1954", award: "KJW", phone: "08033109441", image: chapterPortraits["igbobini/juba-stella-oluremi"] },
      { name: "SIR AKINKUEHIN FRANCIS ADELAKUN", birthday: "13th March, 1936", award: "KCW", phone: "08082186536", image: chapterPortraits["igbobini/akinkuehin-francis-adelakun"] },
      { name: "SIR ADETUYI EMMANUEL ADELANKE", birthday: "24th August, 1931", award: "KJW", phone: "07037371721", image: chapterPortraits["igbobini/adetuyi-emmanuel-adelanke"] },
      { name: "SIR DR. ADEMUJIMI KOLA JONES", birthday: "30th June, 1953", award: "KJW", phone: "08037715800", image: chapterPortraits["igbobini/ademujimi-kola-jones"] },
      { name: "SIR ADEGBOYEGA JOSEPH OLUWOLE", birthday: "2nd January, 1955", award: "KJW", phone: "08033619413", image: chapterPortraits["igbobini/adegboyega-joseph-oluwole"] },
      { name: "SIR AGUDA SAMUEL SOJI", birthday: "2nd February, 1948", award: "KJW", phone: "08068713272", image: chapterPortraits["igbobini/aguda-samuel-soji"] },
      { name: "SIR OGUNSUSI ADEMOLA", birthday: "7th February, 1980", award: "KCW", phone: "08038079526", image: chapterPortraits["igbobini/ogunsusi-ademola"] },
      { name: "SIR DR. AKINYEDE AYODELE OLURANTI", birthday: "15th March, 1943", award: "KJW", phone: "", image: chapterPortraits["igbobini/akinyede-ayodele-oluranti"] },
      { name: "SIR AKINMADE MOSES", birthday: "13th November, 1945", award: "KJW", phone: "08054814446", image: chapterPortraits["igbobini/akinmade-moses"] },
      { name: "SIR DR. OMOTEHINSE IBUKUN", birthday: "6th August, 1952", award: "KJW", phone: "08033747996", image: chapterPortraits["igbobini/omotehinse-ibukun"] },
      { name: "SIR AKINDELE JACKSON", birthday: "20th October, 1935", award: "KJW", phone: "", image: chapterPortraits["igbobini/akindele-jackson"] },
      { name: "SIR OGUNKOYEDE OYEBANJI", birthday: "28th December, 1968", award: "KJW", phone: "08033605847", image: chapterPortraits["igbobini/ogunkoyede-oyebanji"] },
      { name: "SIR FADENI SEHINDE", birthday: "17th February, 1963", award: "KJW", phone: "", image: chapterPortraits["igbobini/fadeni-sehinde"] },
      { name: "SIR ESAN FOLURUNSO BEN", birthday: "24th October, 1963", award: "KJW", phone: "08037196030", image: chapterPortraits["igbobini/esan-folurunso-ben"] },
      { name: "DAME ODU OLADUNNI", birthday: "", award: "KJW", phone: "08033084848", image: chapterPortraits["igbobini/odu-oladunni"] },
      { name: "SIR ADEYOSOYE YINKA", birthday: "", award: "KJW", phone: "07032370332", image: chapterPortraits["igbobini/adeyosoye-yinka"] },
      { name: "SIR AKINRINWA JOHNSON BAYO", birthday: "12th December, 1954", award: "KJW", phone: "08033529598", image: chapterPortraits["igbobini/akinrinwa-johnson-bayo"] },
      { name: "SIR AKINDELE ROBERT", birthday: "12th August, 1954", award: "KJW", phone: "08068050221", image: chapterPortraits["igbobini/akindele-robert"] },
      { name: "SIR PROF. AKERE FUNSHO", birthday: "", award: "KJW", phone: "08033227041", image: chapterPortraits["igbobini/akere-funsho"] },
      { name: "SIR OBAYELU BENSON", birthday: "2nd June, 1964", award: "KJW", phone: "08037309007", image: chapterPortraits["igbobini/obayelu-benson"] },
      { name: "SIR OGUNMADE SOLOMON", birthday: "28th January, 1967", award: "KJW", phone: "08033276587", image: chapterPortraits["igbobini/ogunmade-solomon"] },
      { name: "SIR ADEGOKE SUNDAY", birthday: "", award: "KJW", phone: "08036323135", image: chapterPortraits["igbobini/adegoke-sunday"] },
      { name: "SIR OYEDELE IFE", birthday: "8th October, 1953", award: "KJW", phone: "08034030321", image: chapterPortraits["igbobini/oyedele-ife"] },
      { name: "SIR ENGR. OLAKUNDE DAISI", birthday: "26th December, 1974", award: "KJW", phone: "08033494114", image: chapterPortraits["igbobini/olakunde-daisi"] },
      { name: "SIR SOWORE AKINWUMI", birthday: "", award: "KJW", phone: "08139762674", image: chapterPortraits["igbobini/sowore-akinwumi"] },
      { name: "SIR AKINYEDE FRANCIS", birthday: "15th May, 1945", award: "KJW", phone: "08025909375" },
      { name: "SIR ADEYEMI JONATHAN", birthday: "", award: "KJW", phone: "", image: chapterPortraits["igbobini/adeyemi-jonathan"] },
      { name: "SIR AKINYELURE PIUS", birthday: "", award: "KJW", phone: "08087774444", image: chapterPortraits["igbobini/akinyelure-pius"] },
      { name: "SIR JEJELOLA OLA JAMES", birthday: "21st June, 1953", award: "KJW", phone: "08077991630", image: chapterPortraits["igbobini/jejelola-ola-james"] },
      { name: "SIR NWOSU DARLINGTON", birthday: "22nd December, 1953", award: "KJW", phone: "08033971206", image: chapterPortraits["igbobini/nwosu-darlington"] },
      { name: "DAME NWOSU EVELYN", birthday: "19th October, 1965", award: "KJW", phone: "08035427877", image: chapterPortraits["igbobini/nwosu-evelyn"] },
      { name: "SIR MADUABUCHI ORJI", birthday: "", award: "KJW", phone: "08023262465", image: chapterPortraits["igbobini/maduabuchi-orji"] },
      { name: "SIR OJOMO EDWARD", birthday: "17th June, 1950", award: "KJW", phone: "08033022304", image: chapterPortraits["igbobini/ojomo-edward"] },
      { name: "DAME YESUFU LAURA NWADIUTO", birthday: "21st October, 1953", award: "KCW", phone: "08035798772", image: chapterPortraits["igbobini/yesufu-laura-nwadiuto"] },
      { name: "DAME OMENI BEATRICE", birthday: "", award: "KJW", phone: "08056155701" },
      { name: "SIR OBALOGU FRIDAY", birthday: "", award: "KJW", phone: "08033889282" },
      { name: "SIR CH. UGO EPHRAIM AGBONMA", birthday: "24th May, 1938", award: "KJW", phone: "0802389776", image: chapterPortraits["igbobini/ugo-ephraim-agbonma"] },
      { name: "SIR NSAOKONEYO", birthday: "", award: "KJW", phone: "08034496611" },
      { name: "SIR ATOM OMORUGBE", birthday: "", award: "KJW", phone: "08056155701" },
    ],
  },
  anambra: {
    name: "Anambra",
    members: [
      { name: "SIR AKAEME IFEANYI CHRISTIAN", birthday: "", award: "KJW", phone: "08033270890", position: "Chapter Chairman", image: portraits["anambra-ifeanyi-akaeme"] },
    ],
  },
  ebonyi: {
    name: "Ebonyi",
    members: [
      { name: "SIR BARR. MONDAY ODOH", birthday: "", award: "KJW", phone: "08037727047", position: "Chapter Chairman", image: portraits["ebonyi-monday-odoh"] },
    ],
  },
  oron: {
    name: "Oron",
    members: [
      { name: "SIR ESANG NSA BASSEY", birthday: "", award: "KJW", phone: "07061827795", position: "Chapter Chairman", image: portraits["oron-esang-nsa-bassey"] },
    ],
  },
  "lagos-mainland": {
    name: "Lagos Mainland",
    members: [
      { name: "SIR AYORINDE THOMAS", birthday: "", award: "KJW", phone: "08033193623", position: "Chapter Chairman", image: portraits["lagos-mainland-ayorinde-thomas"] },
      { name: "DAME OYEFESO MODUPE OLUFUNLOLA", birthday: "8th October", award: "KJW", phone: "08027183705", image: chapterPortraits["lagos-mainland/dame-oyefeso-modupe-olufunlola"] },
      { name: "DAME TAYLOR BOLATUMI ABEBI FELICIA", birthday: "28th January", award: "KJW", phone: "08023348302", image: chapterPortraits["lagos-mainland/dame-taylor-bolatumi-abebi-felicia"] },
      { name: "DAME ADENUGBA TUNDE", birthday: "14th March", award: "KJW", phone: "08170022800", image: chapterPortraits["lagos-mainland/dame-adenugba-tunde"] },
      { name: "SIR ADU OLUSOLA", birthday: "1st December", award: "KJW", phone: "07062704271" },
      { name: "SIR DR. ILORI FRANCIS OLUBUNMI", birthday: "19th May", award: "KCW", phone: "08023048652", image: chapterPortraits["lagos-mainland/sir-dr-ilori-francis-olubunmi"] },
      { name: "SIR AGBEBI HERBERT ADEWOLE", birthday: "27th October", award: "KJW", phone: "08082568797, 08168917740", image: chapterPortraits["lagos-mainland/sir-agbebi-herbert-adewole"] },
      { name: "SIR AKINTAN EMMANUEL AFOLABI", birthday: "5th May", award: "KJW", phone: "08037166320, 08024866530", image: chapterPortraits["lagos-mainland/sir-akintan-emmanuel-afolabi"] },
      { name: "SIR BAIYEWU FIYAPE ABIODUN", birthday: "25th December", award: "KJW", phone: "08053132612, 08082752279", image: chapterPortraits["lagos-mainland/sir-baiyewu-fiyape-abiodun"] },
      { name: "SIR OSHADIYA BENJAMIN", birthday: "17th March", award: "KJW", phone: "08022901213, 08033041155", image: chapterPortraits["lagos-mainland/sir-oshadiya-benjamin"] },
      { name: "DAME ADEDAPO-AISIDA TAIWO", birthday: "9th October", award: "KJW", phone: "08023181451", image: chapterPortraits["lagos-mainland/dame-adedapo-aisida-taiwo"] },
      { name: "DAME ADELAKAN HELEN FOLASADE", birthday: "5th June", award: "KJW", phone: "08032055055", image: chapterPortraits["lagos-mainland/dame-adelakan-helen-folasade"] },
      { name: "DAME ADESINA FOLAJIMI", birthday: "16th March", award: "KJW", phone: "08033014338", image: chapterPortraits["lagos-mainland/dame-adesina-folajimi"] },
      { name: "DAME PROF. MAJEKODUNMI AJESOLA", birthday: "5th November", award: "KJW", phone: "08033152680", image: chapterPortraits["lagos-mainland/dame-prof-majekodunmi-ajesola"] },
      { name: "DAME AKINTOLA MARIAN", birthday: "19th December", award: "KJW", phone: "08023094625", image: chapterPortraits["lagos-mainland/dame-akintola-marian"] },
      { name: "DAME ABIGAIL OLUYEMISI FANDA", birthday: "22nd January", award: "KJW", phone: "08038336280", image: chapterPortraits["lagos-mainland/dame-abigail-oluyemisi-fanda"] },
      { name: "DAME DR. MACAULAY ABIMBOLA", birthday: "21st April", award: "KJW", phone: "08023060797", image: chapterPortraits["lagos-mainland/dame-dr-macaulay-abimbola"] },
      { name: "DAME OLAKU OLAYINKA", birthday: "14th January", award: "KJW", phone: "08098900462, 08022900462", image: chapterPortraits["lagos-mainland/dame-olaku-olayinka"] },
      { name: "DAME EVANG. MOYENI MATILDA OLU", birthday: "26th April", award: "KJW", phone: "08020868282", image: chapterPortraits["lagos-mainland/dame-evang-moyeni-matilda-olu"] },
      { name: "DAME MATILDA FOLORUNSO OSHIKOYA", birthday: "4th April", award: "KJW", phone: "08033032968" },
      { name: "DAME SODIPO MOJISOLA", birthday: "30th June", award: "KJW", phone: "08037228783", image: chapterPortraits["lagos-mainland/dame-sodipo-mojisola"] },
    ],
  },
};
