// Caption-matched member portraits from the supplied chapter sheets.
import igbobini_akinmoju_martins_oyewunmi from "@/assets/members/igbobini/akinmoju-martins-oyewunmi.jpg.asset.json";
import igbobini_akinmoju_iyewumi from "@/assets/members/igbobini/akinmoju-iyewumi.jpg.asset.json";
import igbobini_akinkuehin_francis_adelakun from "@/assets/members/igbobini/akinkuehin-francis-adelakun.jpg.asset.json";
import igbobini_adetuyi_emmanuel_adelanke from "@/assets/members/igbobini/adetuyi-emmanuel-adelanke.jpg.asset.json";
import igbobini_ademujimi_kola_jones from "@/assets/members/igbobini/ademujimi-kola-jones.jpg.asset.json";
import igbobini_adegboyega_joseph_oluwole from "@/assets/members/igbobini/adegboyega-joseph-oluwole.jpg.asset.json";
import igbobini_aguda_samuel_soji from "@/assets/members/igbobini/aguda-samuel-soji.jpg.asset.json";
import igbobini_ogunsusi_ademola from "@/assets/members/igbobini/ogunsusi-ademola.jpg.asset.json";
import igbobini_akinyede_ayodele_oluranti from "@/assets/members/igbobini/akinyede-ayodele-oluranti.jpg.asset.json";
import igbobini_akinmade_moses from "@/assets/members/igbobini/akinmade-moses.jpg.asset.json";
import igbobini_omotehinse_ibukun from "@/assets/members/igbobini/omotehinse-ibukun.jpg.asset.json";
import igbobini_akindele_jackson from "@/assets/members/igbobini/akindele-jackson.jpg.asset.json";
import igbobini_ogunkoyede_oyebanji from "@/assets/members/igbobini/ogunkoyede-oyebanji.jpg.asset.json";
import igbobini_fadeni_sehinde from "@/assets/members/igbobini/fadeni-sehinde.jpg.asset.json";
import igbobini_esan_folurunso_ben from "@/assets/members/igbobini/esan-folurunso-ben.jpg.asset.json";
import igbobini_odu_oladunni from "@/assets/members/igbobini/odu-oladunni.jpg.asset.json";
import igbobini_adeyosoye_yinka from "@/assets/members/igbobini/adeyosoye-yinka.jpg.asset.json";
import igbobini_akinrinwa_johnson_bayo from "@/assets/members/igbobini/akinrinwa-johnson-bayo.jpg.asset.json";
import igbobini_omofioye_oyedele_ernest from "@/assets/members/igbobini/omofioye-oyedele-ernest.jpg.asset.json";
import igbobini_akindele_robert from "@/assets/members/igbobini/akindele-robert.jpg.asset.json";
import igbobini_akere_funsho from "@/assets/members/igbobini/akere-funsho.jpg.asset.json";
import igbobini_omogoroye_igbekela from "@/assets/members/igbobini/omogoroye-igbekela.jpg.asset.json";
import igbobini_obideyi_olu_samuel from "@/assets/members/igbobini/obideyi-olu-samuel.jpg.asset.json";
import igbobini_obayelu_benson from "@/assets/members/igbobini/obayelu-benson.jpg.asset.json";
import igbobini_ogunmade_solomon from "@/assets/members/igbobini/ogunmade-solomon.jpg.asset.json";
import igbobini_adegoke_sunday from "@/assets/members/igbobini/adegoke-sunday.jpg.asset.json";
import igbobini_oyedele_ife from "@/assets/members/igbobini/oyedele-ife.jpg.asset.json";
import igbobini_olakunde_daisi from "@/assets/members/igbobini/olakunde-daisi.jpg.asset.json";
import igbobini_sowore_akinwumi from "@/assets/members/igbobini/sowore-akinwumi.jpg.asset.json";
import igbobini_juba_stella_oluremi from "@/assets/members/igbobini/juba-stella-oluremi.jpg.asset.json";
import igbobini_adetuyi_samuel from "@/assets/members/igbobini/adetuyi-samuel.jpg.asset.json";
import igbobini_adeyemi_jonathan from "@/assets/members/igbobini/adeyemi-jonathan.jpg.asset.json";
import igbobini_akinyelure_pius from "@/assets/members/igbobini/akinyelure-pius.jpg.asset.json";
import igbobini_jejelola_ola_james from "@/assets/members/igbobini/jejelola-ola-james.jpg.asset.json";
import igbobini_nwosu_darlington from "@/assets/members/igbobini/nwosu-darlington.jpg.asset.json";
import igbobini_nwosu_evelyn from "@/assets/members/igbobini/nwosu-evelyn.jpg.asset.json";
import igbobini_maduabuchi_orji from "@/assets/members/igbobini/maduabuchi-orji.jpg.asset.json";
import igbobini_ojomo_edward from "@/assets/members/igbobini/ojomo-edward.jpg.asset.json";
import igbobini_yesufu_laura_nwadiuto from "@/assets/members/igbobini/yesufu-laura-nwadiuto.jpg.asset.json";
import igbobini_ugo_ephraim_agbonma from "@/assets/members/igbobini/ugo-ephraim-agbonma.jpg.asset.json";
import umuahia_lucky_akabuike from "@/assets/members/umuahia/lucky-akabuike.jpg.asset.json";
import umuahia_agomoh_chukwuka from "@/assets/members/umuahia/agomoh-chukwuka.jpg.asset.json";
import umuahia_ozoemelam_joy from "@/assets/members/umuahia/ozoemelam-joy.jpg.asset.json";
import umuahia_ekwuribe_hope_okechi from "@/assets/members/umuahia/ekwuribe-hope-okechi.jpg.asset.json";
import umuahia_atulomah_anab from "@/assets/members/umuahia/atulomah-anab.jpg.asset.json";
import umuahia_igwe_emmanuel from "@/assets/members/umuahia/igwe-emmanuel.jpg.asset.json";
import umuahia_mba_paul_chikezie from "@/assets/members/umuahia/mba-paul-chikezie.jpg.asset.json";
import umuahia_nwakanma_emerson from "@/assets/members/umuahia/nwakanma-emerson.jpg.asset.json";
import umuahia_abarikwu_onyema from "@/assets/members/umuahia/abarikwu-onyema.jpg.asset.json";
import umuahia_achilefu_okeahialam from "@/assets/members/umuahia/achilefu-okeahialam.jpg.asset.json";
import umuahia_alighili_onyekachi_princely from "@/assets/members/umuahia/alighili-onyekachi-princely.jpg.asset.json";
import umuahia_ndukwe_okechi from "@/assets/members/umuahia/ndukwe-okechi.jpg.asset.json";
import umuahia_ugoze_onuigbo_eunice from "@/assets/members/umuahia/ugoze-onuigbo-eunice.jpg.asset.json";
import umuahia_uzohuo_ndubuisi from "@/assets/members/umuahia/uzohuo-ndubuisi.jpg.asset.json";
import umuahia_oji_obisike from "@/assets/members/umuahia/oji-obisike.jpg.asset.json";
import umuahia_ezuruike_iheanacho from "@/assets/members/umuahia/ezuruike-iheanacho.jpg.asset.json";
import umuahia_eze_okpokiri_allan_onyenaucheya from "@/assets/members/umuahia/eze-okpokiri-allan-onyenaucheya.jpg.asset.json";
import umuahia_amajoh_samuel_bryant_chimereze from "@/assets/members/umuahia/amajoh-samuel-bryant-chimereze.jpg.asset.json";
import umuahia_ukaegbu_obinna from "@/assets/members/umuahia/ukaegbu-obinna.jpg.asset.json";
import umuahia_nzeako_sunday_uchechukwu from "@/assets/members/umuahia/nzeako-sunday-uchechukwu.jpg.asset.json";
import umuahia_nwokocha_udo from "@/assets/members/umuahia/nwokocha-udo.jpg.asset.json";
import umuahia_mbakwe_humphrey from "@/assets/members/umuahia/mbakwe-humphrey.jpg.asset.json";
import umuahia_ibebunjoh_chinedum from "@/assets/members/umuahia/ibebunjoh-chinedum.jpg.asset.json";
import lagos_sir_falola_olakunle_olaoluwa from "@/assets/members/lagos/sir-falola-olakunle-olaoluwa.jpg.asset.json";
import lagos_dame_george_yewande from "@/assets/members/lagos/dame-george-yewande.jpg.asset.json";
import lagos_dame_williams_adebola from "@/assets/members/lagos/dame-williams-adebola.jpg.asset.json";
import lagos_dame_solanke_susan_isoken from "@/assets/members/lagos/dame-solanke-susan-isoken.jpg.asset.json";
import lagos_sir_sunmoni_david from "@/assets/members/lagos/sir-sunmoni-david.jpg.asset.json";
import lagos_dame_barr_fadipe_ethel_olamide from "@/assets/members/lagos/dame-barr-fadipe-ethel-olamide.jpg.asset.json";
import lagos_dame_sagoe_aba_omotunde from "@/assets/members/lagos/dame-sagoe-aba-omotunde.jpg.asset.json";
import lagos_dame_simplice_gladys_olajumoke from "@/assets/members/lagos/dame-simplice-gladys-olajumoke.jpg.asset.json";
import lagos_sir_ogunlana_ebenezer_olanrewaju from "@/assets/members/lagos/sir-ogunlana-ebenezer-olanrewaju.jpg.asset.json";
import lagos_dame_oshinowo_modupe from "@/assets/members/lagos/dame-oshinowo-modupe.jpg.asset.json";
import lagos_sir_kamson_olayinka_olusoga from "@/assets/members/lagos/sir-kamson-olayinka-olusoga.jpg.asset.json";
import lagos_sir_ogunkoya_abiodun from "@/assets/members/lagos/sir-ogunkoya-abiodun.jpg.asset.json";
import lagos_dame_awosanya_stella from "@/assets/members/lagos/dame-awosanya-stella.jpg.asset.json";
import lagos_sir_opelusi_albert_ranti from "@/assets/members/lagos/sir-opelusi-albert-ranti.jpg.asset.json";
import lagos_dame_ayoola_olulanu_adebisi from "@/assets/members/lagos/dame-ayoola-olulanu-adebisi.jpg.asset.json";
import lagos_dame_carzim_shola_iyabo from "@/assets/members/lagos/dame-carzim-shola-iyabo.jpg.asset.json";
import lagos_sir_carzim_abimbola_sylvester from "@/assets/members/lagos/sir-carzim-abimbola-sylvester.jpg.asset.json";
import lagos_sir_oyenusi_ezekiel_akinola from "@/assets/members/lagos/sir-oyenusi-ezekiel-akinola.jpg.asset.json";
import lagos_dame_chief_anjous_grace_oritsejolomi from "@/assets/members/lagos/dame-chief-anjous-grace-oritsejolomi.jpg.asset.json";
import lagos_sir_dr_coker_festus_olumuyiwa from "@/assets/members/lagos/sir-dr-coker-festus-olumuyiwa.jpg.asset.json";
import lagos_dame_osunneye_olabisi_olufunmilola from "@/assets/members/lagos/dame-osunneye-olabisi-olufunmilola.jpg.asset.json";
import lagos_dame_ikulala_allen_stella_olusola from "@/assets/members/lagos/dame-ikulala-allen-stella-olusola.jpg.asset.json";
import lagos_dame_okunrinboye_frances_olufunmilayo from "@/assets/members/lagos/dame-okunrinboye-frances-olufunmilayo.jpg.asset.json";
import lagos_onafowokah_ademola from "@/assets/members/lagos/onafowokah-ademola.jpg.asset.json";
import lagos_sir_sobamowo_babatunde_emmanuel from "@/assets/members/lagos/sir-sobamowo-babatunde-emmanuel.jpg.asset.json";
import lagos_dame_soyannwo_taiwo_onikepe from "@/assets/members/lagos/dame-soyannwo-taiwo-onikepe.jpg.asset.json";
import lagos_sir_ogunjuboun_frederick_iluyomade from "@/assets/members/lagos/sir-ogunjuboun-frederick-iluyomade.jpg.asset.json";
import lagos_dame_osilesi_adeyinka from "@/assets/members/lagos/dame-osilesi-adeyinka.jpg.asset.json";
import lagos_sir_oyedipe_adekunle from "@/assets/members/lagos/sir-oyedipe-adekunle.jpg.asset.json";
import lagos_sir_akinsanya_emmanuel_akinwale from "@/assets/members/lagos/sir-akinsanya-emmanuel-akinwale.jpg.asset.json";
import lagos_sir_akintayo_adetayo from "@/assets/members/lagos/sir-akintayo-adetayo.jpg.asset.json";
import lagos_sir_benson_olabisi from "@/assets/members/lagos/sir-benson-olabisi.jpg.asset.json";
import lagos_sir_shoderu_omokayode from "@/assets/members/lagos/sir-shoderu-omokayode.jpg.asset.json";
import lagos_sir_onyeukwu_ogueri_temple from "@/assets/members/lagos/sir-onyeukwu-ogueri-temple.jpg.asset.json";
import lagos_dame_kalejaiye_adeola_idowu from "@/assets/members/lagos/dame-kalejaiye-adeola-idowu.jpg.asset.json";
import lagos_sir_ogunjimi_teju from "@/assets/members/lagos/sir-ogunjimi-teju.jpg.asset.json";
import lagos_dame_akinyemi_dorcas from "@/assets/members/lagos/dame-akinyemi-dorcas.jpg.asset.json";
import lagos_sir_esan_aderemi from "@/assets/members/lagos/sir-esan-aderemi.jpg.asset.json";
import lagos_sir_anofowakan_ayokunle_salako from "@/assets/members/lagos/sir-anofowakan-ayokunle-salako.jpg.asset.json";
import lagos_sir_ajayi_ayodele from "@/assets/members/lagos/sir-ajayi-ayodele.jpg.asset.json";
import lagos_sir_odunsi_j_alex_oluwatoyin from "@/assets/members/lagos/sir-odunsi-j-alex-oluwatoyin.jpg.asset.json";
import lagos_dame_latunde_lawal_olajumoke_abiodun from "@/assets/members/lagos/dame-latunde-lawal-olajumoke-abiodun.jpg.asset.json";
import lagos_dame_banjoko_adeola from "@/assets/members/lagos/dame-banjoko-adeola.jpg.asset.json";
import lagos_sir_omooba_onafowakan_olusoji_alfred from "@/assets/members/lagos/sir-omooba-onafowakan-olusoji-alfred.jpg.asset.json";
import lagos_sir_engr_chief_oshinowo_oladimeji from "@/assets/members/lagos/sir-engr-chief-oshinowo-oladimeji.jpg.asset.json";
import lagos_sir_elesho_ayodele_oluwole from "@/assets/members/lagos/sir-elesho-ayodele-oluwole.jpg.asset.json";
import lagos_sir_akintola_sunday_olakunle from "@/assets/members/lagos/sir-akintola-sunday-olakunle.jpg.asset.json";
import lagos_sir_chief_onakoya_olatunde from "@/assets/members/lagos/sir-chief-onakoya-olatunde.jpg.asset.json";
import lagos_sir_thorpe_isaac_olusina from "@/assets/members/lagos/sir-thorpe-isaac-olusina.jpg.asset.json";
import lagos_sir_dr_austen_peters_adegboyega_oluwarotimi from "@/assets/members/lagos/sir-dr-austen-peters-adegboyega-oluwarotimi.jpg.asset.json";
import lagos_dame_dr_akintola_osho_olufunbi from "@/assets/members/lagos/dame-dr-akintola-osho-olufunbi.jpg.asset.json";
import lagos_sir_williams_abayomi from "@/assets/members/lagos/sir-williams-abayomi.jpg.asset.json";
import lagos_sir_brig_gen_rtd_bossman_charles from "@/assets/members/lagos/sir-brig-gen-rtd-bossman-charles.jpg.asset.json";
import lagos_sir_chief_ariyo_oluwole from "@/assets/members/lagos/sir-chief-ariyo-oluwole.jpg.asset.json";
import lagos_dame_awosedo_comfort_modupefoluwa_olubunmi from "@/assets/members/lagos/dame-awosedo-comfort-modupefoluwa-olubunmi.jpg.asset.json";
import lagos_sir_engr_frazier_samuel_babashola from "@/assets/members/lagos/sir-engr-frazier-samuel-babashola.jpg.asset.json";
import lagos_sir_rear_admiral_rtd_joseph_oladeinde from "@/assets/members/lagos/sir-rear-admiral-rtd-joseph-oladeinde.jpg.asset.json";
import lagos_sir_ogunsanya_dada_olutayo from "@/assets/members/lagos/sir-ogunsanya-dada-olutayo.jpg.asset.json";
import lagos_sir_dr_inuikim_asuquo from "@/assets/members/lagos/sir-dr-inuikim-asuquo.jpg.asset.json";
import lagos_sir_lamidi_ambrose_sanni from "@/assets/members/lagos/sir-lamidi-ambrose-sanni.jpg.asset.json";
import lagos_sir_ogunniran_olufemi from "@/assets/members/lagos/sir-ogunniran-olufemi.jpg.asset.json";
import lagos_sir_ajanaku_adesegun from "@/assets/members/lagos/sir-ajanaku-adesegun.jpg.asset.json";
import lagos_sir_awobona_olaniyi from "@/assets/members/lagos/sir-awobona-olaniyi.jpg.asset.json";
import lagos_sir_olaniyan_oluwatosin from "@/assets/members/lagos/sir-olaniyan-oluwatosin.jpg.asset.json";
import lagos_sir_a_i_g_cole_charles_akande from "@/assets/members/lagos/sir-a-i-g-cole-charles-akande.jpg.asset.json";
import lagos_dame_george_iyabode from "@/assets/members/lagos/dame-george-iyabode.jpg.asset.json";
import lagos_sir_george_olusegun from "@/assets/members/lagos/sir-george-olusegun.jpg.asset.json";
import lagos_sir_cole_anthony_bola from "@/assets/members/lagos/sir-cole-anthony-bola.jpg.asset.json";
import lagos_dame_olufon_adebisi_adebola from "@/assets/members/lagos/dame-olufon-adebisi-adebola.jpg.asset.json";
import lagos_dame_akapo_judith_yewande from "@/assets/members/lagos/dame-akapo-judith-yewande.jpg.asset.json";
import lagos_dame_omotayo_mojirade_asabi from "@/assets/members/lagos/dame-omotayo-mojirade-asabi.jpg.asset.json";
import lagos_sir_inuekim_eyo from "@/assets/members/lagos/sir-inuekim-eyo.jpg.asset.json";
import lagos_dame_ige_sylvia_taiwo from "@/assets/members/lagos/dame-ige-sylvia-taiwo.jpg.asset.json";
import lagos_sir_odojukan_abiodun from "@/assets/members/lagos/sir-odojukan-abiodun.jpg.asset.json";
import lagos_sir_coker_feyiseton from "@/assets/members/lagos/sir-coker-feyiseton.jpg.asset.json";
import lagos_dame_odeka_olatomi_ibiyemi from "@/assets/members/lagos/dame-odeka-olatomi-ibiyemi.jpg.asset.json";
import lagos_dame_princess_asim_ita_geraldine from "@/assets/members/lagos/dame-princess-asim-ita-geraldine.jpg.asset.json";
import lagos_sir_otoki_joseph_abiodun from "@/assets/members/lagos/sir-otoki-joseph-abiodun.jpg.asset.json";
import lagos_sir_dr_iketubosin_fayeofori from "@/assets/members/lagos/sir-dr-iketubosin-fayeofori.jpg.asset.json";
import lagos_sir_prince_olateru_olagbegi_adeyemi from "@/assets/members/lagos/sir-prince-olateru-olagbegi-adeyemi.jpg.asset.json";
import lagos_dame_odukale_matilda_i from "@/assets/members/lagos/dame-odukale-matilda-i.jpg.asset.json";
import lm_dame_oyefeso_modupe_olufunlola from "@/assets/members/lagos-mainland/dame-oyefeso-modupe-olufunlola.jpg.asset.json";
import lm_dame_taylor_bolatumi_abebi_felicia from "@/assets/members/lagos-mainland/dame-taylor-bolatumi-abebi-felicia.jpg.asset.json";
import lm_dame_adenugba_tunde from "@/assets/members/lagos-mainland/dame-adenugba-tunde.jpg.asset.json";
import lm_sir_dr_ilori_francis_olubunmi from "@/assets/members/lagos-mainland/sir-dr-ilori-francis-olubunmi.jpg.asset.json";
import lm_sir_agbebi_herbert_adewole from "@/assets/members/lagos-mainland/sir-agbebi-herbert-adewole.jpg.asset.json";
import lm_sir_akintan_emmanuel_afolabi from "@/assets/members/lagos-mainland/sir-akintan-emmanuel-afolabi.jpg.asset.json";
import lm_sir_baiyewu_fiyape_abiodun from "@/assets/members/lagos-mainland/sir-baiyewu-fiyape-abiodun.jpg.asset.json";
import lm_sir_oshadiya_benjamin from "@/assets/members/lagos-mainland/sir-oshadiya-benjamin.jpg.asset.json";
import lm_dame_adedapo_aisida_taiwo from "@/assets/members/lagos-mainland/dame-adedapo-aisida-taiwo.jpg.asset.json";
import lm_dame_adelakan_helen_folasade from "@/assets/members/lagos-mainland/dame-adelakan-helen-folasade.jpg.asset.json";
import lm_dame_adesina_folajimi from "@/assets/members/lagos-mainland/dame-adesina-folajimi.jpg.asset.json";
import lm_dame_prof_majekodunmi_ajesola from "@/assets/members/lagos-mainland/dame-prof-majekodunmi-ajesola.jpg.asset.json";
import lm_dame_akintola_marian from "@/assets/members/lagos-mainland/dame-akintola-marian.jpg.asset.json";
import lm_dame_abigail_oluyemisi_fanda from "@/assets/members/lagos-mainland/dame-abigail-oluyemisi-fanda.jpg.asset.json";
import lm_dame_dr_macaulay_abimbola from "@/assets/members/lagos-mainland/dame-dr-macaulay-abimbola.jpg.asset.json";
import lm_dame_olaku_olayinka from "@/assets/members/lagos-mainland/dame-olaku-olayinka.jpg.asset.json";
import lm_dame_evang_moyeni_matilda_olu from "@/assets/members/lagos-mainland/dame-evang-moyeni-matilda-olu.jpg.asset.json";
import lm_dame_sodipo_mojisola from "@/assets/members/lagos-mainland/dame-sodipo-mojisola.jpg.asset.json";

export const chapterPortraits: Record<string, string> = {
  "igbobini/akinmoju-martins-oyewunmi": igbobini_akinmoju_martins_oyewunmi.url,
  "igbobini/akinmoju-iyewumi": igbobini_akinmoju_iyewumi.url,
  "igbobini/akinkuehin-francis-adelakun": igbobini_akinkuehin_francis_adelakun.url,
  "igbobini/adetuyi-emmanuel-adelanke": igbobini_adetuyi_emmanuel_adelanke.url,
  "igbobini/ademujimi-kola-jones": igbobini_ademujimi_kola_jones.url,
  "igbobini/adegboyega-joseph-oluwole": igbobini_adegboyega_joseph_oluwole.url,
  "igbobini/aguda-samuel-soji": igbobini_aguda_samuel_soji.url,
  "igbobini/ogunsusi-ademola": igbobini_ogunsusi_ademola.url,
  "igbobini/akinyede-ayodele-oluranti": igbobini_akinyede_ayodele_oluranti.url,
  "igbobini/akinmade-moses": igbobini_akinmade_moses.url,
  "igbobini/omotehinse-ibukun": igbobini_omotehinse_ibukun.url,
  "igbobini/akindele-jackson": igbobini_akindele_jackson.url,
  "igbobini/ogunkoyede-oyebanji": igbobini_ogunkoyede_oyebanji.url,
  "igbobini/fadeni-sehinde": igbobini_fadeni_sehinde.url,
  "igbobini/esan-folurunso-ben": igbobini_esan_folurunso_ben.url,
  "igbobini/odu-oladunni": igbobini_odu_oladunni.url,
  "igbobini/adeyosoye-yinka": igbobini_adeyosoye_yinka.url,
  "igbobini/akinrinwa-johnson-bayo": igbobini_akinrinwa_johnson_bayo.url,
  "igbobini/omofioye-oyedele-ernest": igbobini_omofioye_oyedele_ernest.url,
  "igbobini/akindele-robert": igbobini_akindele_robert.url,
  "igbobini/akere-funsho": igbobini_akere_funsho.url,
  "igbobini/omogoroye-igbekela": igbobini_omogoroye_igbekela.url,
  "igbobini/obideyi-olu-samuel": igbobini_obideyi_olu_samuel.url,
  "igbobini/obayelu-benson": igbobini_obayelu_benson.url,
  "igbobini/ogunmade-solomon": igbobini_ogunmade_solomon.url,
  "igbobini/adegoke-sunday": igbobini_adegoke_sunday.url,
  "igbobini/oyedele-ife": igbobini_oyedele_ife.url,
  "igbobini/olakunde-daisi": igbobini_olakunde_daisi.url,
  "igbobini/sowore-akinwumi": igbobini_sowore_akinwumi.url,
  "igbobini/juba-stella-oluremi": igbobini_juba_stella_oluremi.url,
  "igbobini/adetuyi-samuel": igbobini_adetuyi_samuel.url,
  "igbobini/adeyemi-jonathan": igbobini_adeyemi_jonathan.url,
  "igbobini/akinyelure-pius": igbobini_akinyelure_pius.url,
  "igbobini/jejelola-ola-james": igbobini_jejelola_ola_james.url,
  "igbobini/nwosu-darlington": igbobini_nwosu_darlington.url,
  "igbobini/nwosu-evelyn": igbobini_nwosu_evelyn.url,
  "igbobini/maduabuchi-orji": igbobini_maduabuchi_orji.url,
  "igbobini/ojomo-edward": igbobini_ojomo_edward.url,
  "igbobini/yesufu-laura-nwadiuto": igbobini_yesufu_laura_nwadiuto.url,
  "igbobini/ugo-ephraim-agbonma": igbobini_ugo_ephraim_agbonma.url,
  "umuahia/lucky-akabuike": umuahia_lucky_akabuike.url,
  "umuahia/agomoh-chukwuka": umuahia_agomoh_chukwuka.url,
  "umuahia/ozoemelam-joy": umuahia_ozoemelam_joy.url,
  "umuahia/ekwuribe-hope-okechi": umuahia_ekwuribe_hope_okechi.url,
  "umuahia/atulomah-anab": umuahia_atulomah_anab.url,
  "umuahia/igwe-emmanuel": umuahia_igwe_emmanuel.url,
  "umuahia/mba-paul-chikezie": umuahia_mba_paul_chikezie.url,
  "umuahia/nwakanma-emerson": umuahia_nwakanma_emerson.url,
  "umuahia/abarikwu-onyema": umuahia_abarikwu_onyema.url,
  "umuahia/achilefu-okeahialam": umuahia_achilefu_okeahialam.url,
  "umuahia/alighili-onyekachi-princely": umuahia_alighili_onyekachi_princely.url,
  "umuahia/ndukwe-okechi": umuahia_ndukwe_okechi.url,
  "umuahia/ugoze-onuigbo-eunice": umuahia_ugoze_onuigbo_eunice.url,
  "umuahia/uzohuo-ndubuisi": umuahia_uzohuo_ndubuisi.url,
  "umuahia/oji-obisike": umuahia_oji_obisike.url,
  "umuahia/ezuruike-iheanacho": umuahia_ezuruike_iheanacho.url,
  "umuahia/eze-okpokiri-allan-onyenaucheya": umuahia_eze_okpokiri_allan_onyenaucheya.url,
  "umuahia/amajoh-samuel-bryant-chimereze": umuahia_amajoh_samuel_bryant_chimereze.url,
  "umuahia/ukaegbu-obinna": umuahia_ukaegbu_obinna.url,
  "umuahia/nzeako-sunday-uchechukwu": umuahia_nzeako_sunday_uchechukwu.url,
  "umuahia/nwokocha-udo": umuahia_nwokocha_udo.url,
  "umuahia/mbakwe-humphrey": umuahia_mbakwe_humphrey.url,
  "umuahia/ibebunjoh-chinedum": umuahia_ibebunjoh_chinedum.url,
  "lagos/sir-falola-olakunle-olaoluwa": lagos_sir_falola_olakunle_olaoluwa.url,
  "lagos/dame-george-yewande": lagos_dame_george_yewande.url,
  "lagos/dame-williams-adebola": lagos_dame_williams_adebola.url,
  "lagos/dame-solanke-susan-isoken": lagos_dame_solanke_susan_isoken.url,
  "lagos/sir-sunmoni-david": lagos_sir_sunmoni_david.url,
  "lagos/dame-barr-fadipe-ethel-olamide": lagos_dame_barr_fadipe_ethel_olamide.url,
  "lagos/dame-sagoe-aba-omotunde": lagos_dame_sagoe_aba_omotunde.url,
  "lagos/dame-simplice-gladys-olajumoke": lagos_dame_simplice_gladys_olajumoke.url,
  "lagos/sir-ogunlana-ebenezer-olanrewaju": lagos_sir_ogunlana_ebenezer_olanrewaju.url,
  "lagos/dame-oshinowo-modupe": lagos_dame_oshinowo_modupe.url,
  "lagos/sir-kamson-olayinka-olusoga": lagos_sir_kamson_olayinka_olusoga.url,
  "lagos/sir-ogunkoya-abiodun": lagos_sir_ogunkoya_abiodun.url,
  "lagos/dame-awosanya-stella": lagos_dame_awosanya_stella.url,
  "lagos/sir-opelusi-albert-ranti": lagos_sir_opelusi_albert_ranti.url,
  "lagos/dame-ayoola-olulanu-adebisi": lagos_dame_ayoola_olulanu_adebisi.url,
  "lagos/dame-carzim-shola-iyabo": lagos_dame_carzim_shola_iyabo.url,
  "lagos/sir-carzim-abimbola-sylvester": lagos_sir_carzim_abimbola_sylvester.url,
  "lagos/sir-oyenusi-ezekiel-akinola": lagos_sir_oyenusi_ezekiel_akinola.url,
  "lagos/dame-chief-anjous-grace-oritsejolomi": lagos_dame_chief_anjous_grace_oritsejolomi.url,
  "lagos/sir-dr-coker-festus-olumuyiwa": lagos_sir_dr_coker_festus_olumuyiwa.url,
  "lagos/dame-osunneye-olabisi-olufunmilola": lagos_dame_osunneye_olabisi_olufunmilola.url,
  "lagos/dame-ikulala-allen-stella-olusola": lagos_dame_ikulala_allen_stella_olusola.url,
  "lagos/dame-okunrinboye-frances-olufunmilayo": lagos_dame_okunrinboye_frances_olufunmilayo.url,
  "lagos/onafowokah-ademola": lagos_onafowokah_ademola.url,
  "lagos/sir-sobamowo-babatunde-emmanuel": lagos_sir_sobamowo_babatunde_emmanuel.url,
  "lagos/dame-soyannwo-taiwo-onikepe": lagos_dame_soyannwo_taiwo_onikepe.url,
  "lagos/sir-ogunjuboun-frederick-iluyomade": lagos_sir_ogunjuboun_frederick_iluyomade.url,
  "lagos/dame-osilesi-adeyinka": lagos_dame_osilesi_adeyinka.url,
  "lagos/sir-oyedipe-adekunle": lagos_sir_oyedipe_adekunle.url,
  "lagos/sir-akinsanya-emmanuel-akinwale": lagos_sir_akinsanya_emmanuel_akinwale.url,
  "lagos/sir-akintayo-adetayo": lagos_sir_akintayo_adetayo.url,
  "lagos/sir-benson-olabisi": lagos_sir_benson_olabisi.url,
  "lagos/sir-shoderu-omokayode": lagos_sir_shoderu_omokayode.url,
  "lagos/sir-onyeukwu-ogueri-temple": lagos_sir_onyeukwu_ogueri_temple.url,
  "lagos/dame-kalejaiye-adeola-idowu": lagos_dame_kalejaiye_adeola_idowu.url,
  "lagos/sir-ogunjimi-teju": lagos_sir_ogunjimi_teju.url,
  "lagos/dame-akinyemi-dorcas": lagos_dame_akinyemi_dorcas.url,
  "lagos/sir-esan-aderemi": lagos_sir_esan_aderemi.url,
  "lagos/sir-anofowakan-ayokunle-salako": lagos_sir_anofowakan_ayokunle_salako.url,
  "lagos/sir-ajayi-ayodele": lagos_sir_ajayi_ayodele.url,
  "lagos/sir-odunsi-j-alex-oluwatoyin": lagos_sir_odunsi_j_alex_oluwatoyin.url,
  "lagos/dame-latunde-lawal-olajumoke-abiodun": lagos_dame_latunde_lawal_olajumoke_abiodun.url,
  "lagos/dame-banjoko-adeola": lagos_dame_banjoko_adeola.url,
  "lagos/sir-omooba-onafowakan-olusoji-alfred": lagos_sir_omooba_onafowakan_olusoji_alfred.url,
  "lagos/sir-engr-chief-oshinowo-oladimeji": lagos_sir_engr_chief_oshinowo_oladimeji.url,
  "lagos/sir-elesho-ayodele-oluwole": lagos_sir_elesho_ayodele_oluwole.url,
  "lagos/sir-akintola-sunday-olakunle": lagos_sir_akintola_sunday_olakunle.url,
  "lagos/sir-chief-onakoya-olatunde": lagos_sir_chief_onakoya_olatunde.url,
  "lagos/sir-thorpe-isaac-olusina": lagos_sir_thorpe_isaac_olusina.url,
  "lagos/sir-dr-austen-peters-adegboyega-oluwarotimi": lagos_sir_dr_austen_peters_adegboyega_oluwarotimi.url,
  "lagos/dame-dr-akintola-osho-olufunbi": lagos_dame_dr_akintola_osho_olufunbi.url,
  "lagos/sir-williams-abayomi": lagos_sir_williams_abayomi.url,
  "lagos/sir-brig-gen-rtd-bossman-charles": lagos_sir_brig_gen_rtd_bossman_charles.url,
  "lagos/sir-chief-ariyo-oluwole": lagos_sir_chief_ariyo_oluwole.url,
  "lagos/dame-awosedo-comfort-modupefoluwa-olubunmi": lagos_dame_awosedo_comfort_modupefoluwa_olubunmi.url,
  "lagos/sir-engr-frazier-samuel-babashola": lagos_sir_engr_frazier_samuel_babashola.url,
  "lagos/sir-rear-admiral-rtd-joseph-oladeinde": lagos_sir_rear_admiral_rtd_joseph_oladeinde.url,
  "lagos/sir-ogunsanya-dada-olutayo": lagos_sir_ogunsanya_dada_olutayo.url,
  "lagos/sir-dr-inuikim-asuquo": lagos_sir_dr_inuikim_asuquo.url,
  "lagos/sir-lamidi-ambrose-sanni": lagos_sir_lamidi_ambrose_sanni.url,
  "lagos/sir-ogunniran-olufemi": lagos_sir_ogunniran_olufemi.url,
  "lagos/sir-ajanaku-adesegun": lagos_sir_ajanaku_adesegun.url,
  "lagos/sir-awobona-olaniyi": lagos_sir_awobona_olaniyi.url,
  "lagos/sir-olaniyan-oluwatosin": lagos_sir_olaniyan_oluwatosin.url,
  "lagos/sir-a-i-g-cole-charles-akande": lagos_sir_a_i_g_cole_charles_akande.url,
  "lagos/dame-george-iyabode": lagos_dame_george_iyabode.url,
  "lagos/sir-george-olusegun": lagos_sir_george_olusegun.url,
  "lagos/sir-cole-anthony-bola": lagos_sir_cole_anthony_bola.url,
  "lagos/dame-olufon-adebisi-adebola": lagos_dame_olufon_adebisi_adebola.url,
  "lagos/dame-akapo-judith-yewande": lagos_dame_akapo_judith_yewande.url,
  "lagos/dame-omotayo-mojirade-asabi": lagos_dame_omotayo_mojirade_asabi.url,
  "lagos/sir-inuekim-eyo": lagos_sir_inuekim_eyo.url,
  "lagos/dame-ige-sylvia-taiwo": lagos_dame_ige_sylvia_taiwo.url,
  "lagos/sir-odojukan-abiodun": lagos_sir_odojukan_abiodun.url,
  "lagos/sir-coker-feyiseton": lagos_sir_coker_feyiseton.url,
  "lagos/dame-odeka-olatomi-ibiyemi": lagos_dame_odeka_olatomi_ibiyemi.url,
  "lagos/dame-princess-asim-ita-geraldine": lagos_dame_princess_asim_ita_geraldine.url,
  "lagos/sir-otoki-joseph-abiodun": lagos_sir_otoki_joseph_abiodun.url,
  "lagos/sir-dr-iketubosin-fayeofori": lagos_sir_dr_iketubosin_fayeofori.url,
  "lagos/sir-prince-olateru-olagbegi-adeyemi": lagos_sir_prince_olateru_olagbegi_adeyemi.url,
  "lagos/dame-odukale-matilda-i": lagos_dame_odukale_matilda_i.url,
  "lagos-mainland/dame-oyefeso-modupe-olufunlola": lm_dame_oyefeso_modupe_olufunlola.url,
  "lagos-mainland/dame-taylor-bolatumi-abebi-felicia": lm_dame_taylor_bolatumi_abebi_felicia.url,
  "lagos-mainland/dame-adenugba-tunde": lm_dame_adenugba_tunde.url,
  "lagos-mainland/sir-dr-ilori-francis-olubunmi": lm_sir_dr_ilori_francis_olubunmi.url,
  "lagos-mainland/sir-agbebi-herbert-adewole": lm_sir_agbebi_herbert_adewole.url,
  "lagos-mainland/sir-akintan-emmanuel-afolabi": lm_sir_akintan_emmanuel_afolabi.url,
  "lagos-mainland/sir-baiyewu-fiyape-abiodun": lm_sir_baiyewu_fiyape_abiodun.url,
  "lagos-mainland/sir-oshadiya-benjamin": lm_sir_oshadiya_benjamin.url,
  "lagos-mainland/dame-adedapo-aisida-taiwo": lm_dame_adedapo_aisida_taiwo.url,
  "lagos-mainland/dame-adelakan-helen-folasade": lm_dame_adelakan_helen_folasade.url,
  "lagos-mainland/dame-adesina-folajimi": lm_dame_adesina_folajimi.url,
  "lagos-mainland/dame-prof-majekodunmi-ajesola": lm_dame_prof_majekodunmi_ajesola.url,
  "lagos-mainland/dame-akintola-marian": lm_dame_akintola_marian.url,
  "lagos-mainland/dame-abigail-oluyemisi-fanda": lm_dame_abigail_oluyemisi_fanda.url,
  "lagos-mainland/dame-dr-macaulay-abimbola": lm_dame_dr_macaulay_abimbola.url,
  "lagos-mainland/dame-olaku-olayinka": lm_dame_olaku_olayinka.url,
  "lagos-mainland/dame-evang-moyeni-matilda-olu": lm_dame_evang_moyeni_matilda_olu.url,
  "lagos-mainland/dame-sodipo-mojisola": lm_dame_sodipo_mojisola.url,
};
